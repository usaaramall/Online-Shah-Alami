/* Online Shah Alami - no-Firebase mode (Cloudflare static hosting).
   Products come from DEFAULTS in config.js. Orders are sent to your WhatsApp.
   "Buy Now" / "Proceed to checkout" open the WhatsApp order form instead of the login page. */
(function () {
  "use strict";
  var noFB = !CONFIG.firebase || String(CONFIG.firebase.apiKey || "").indexOf("YOUR_") === 0;
  var wa = String((CONFIG.shop && CONFIG.shop.whatsapp) || "").replace(/\D/g, "");
  var f = document.querySelector("[data-wa-float]");
  if (f) { if (wa) f.href = "https://wa.me/" + wa; else f.style.display = "none"; }
  if (!noFB) return;

  var pushed = {};
  function cart() { try { return JSON.parse(localStorage.getItem("am_cart") || "[]"); } catch (e) { return []; } }
  function findP(id) { for (var i = 0; i < DEFAULTS.length; i++) if (String(DEFAULTS[i].id) === String(id)) return DEFAULTS[i]; return null; }

  function openCheckout() {
    if (!window.AnasMartCheckout) return;
    var box = document.getElementById("amCart");
    if (box && !box.children.length) pushed = {};
    var list = cart(), any = false;
    list.forEach(function (c) {
      var p = findP(c.pid); if (!p) return;
      var v = null; (p.variants || []).forEach(function (x) { if (x.size === c.size) v = x; });
      if (!v) return;
      var key = c.pid + "|" + c.size, add = (Number(c.qty) || 1) - (pushed[key] || 0);
      if (add > 0) { pushed[key] = (pushed[key] || 0) + add; any = true;
        AnasMartCheckout.add({ name: p.name, price: Number(v.price), img: p.image || "", variant: v.size, qty: add, pid: p.id }); }
    });
    if (!any) { var fab = document.getElementById("amFab"); if (fab && fab.classList.contains("on")) fab.click(); }
  }

  function route() {
    if (location.hash.replace(/\?.*$/, "") !== "#/checkout") return;
    history.replaceState(null, "", "#/cart");
    window.dispatchEvent(new HashChangeEvent("hashchange"));
    setTimeout(openCheckout, 60);
  }
  window.addEventListener("hashchange", route);
  route();
})();
