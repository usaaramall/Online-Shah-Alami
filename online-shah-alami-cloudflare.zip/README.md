# Online Shah Alami - Cloudflare version (no Firebase)
Edit assets/js/config.js: shop.whatsapp (92xxxxxxxxxx, digits only), phone, JazzCash/Easypaisa/bank details, and the DEFAULTS product list.
Upload this folder to Cloudflare Pages (Direct Upload), then attach onlineshahalami.com under Custom domains.
