/* =====================================================================
   APPLICATION CODE
   ===================================================================== */
(function(){
"use strict";
document.title = "Online Shah Alami | Online Shopping for Everything";
var SH = CONFIG.shop;
var FB_OK = typeof firebase !== "undefined" && CONFIG.firebase.apiKey.indexOf("YOUR_") !== 0;
var EJ_OK = typeof emailjs !== "undefined" && CONFIG.emailjs.publicKey.indexOf("YOUR_") !== 0;
var auth = null, db = null, storage = null;
if (FB_OK) {
  try {
    firebase.initializeApp(CONFIG.firebase);
    auth = firebase.auth(); db = firebase.firestore();
    if (CONFIG.useStorage) storage = firebase.storage();
  } catch (e) { FB_OK = false; console.error("Firebase init failed", e); }
}
if (EJ_OK) { try { emailjs.init({ publicKey: CONFIG.emailjs.publicKey }); } catch (e) { EJ_OK = false; } }

/* ---------- helpers ---------- */
function $(s, r) { return (r || document).querySelector(s); }
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]; }); }
function fmt(n) { return "PKR " + Number(n || 0).toLocaleString("en-PK"); }
function load(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
var tt;
function toast(m) { var t = $("#toast"); t.textContent = m; t.className = "show"; clearTimeout(tt); tt = setTimeout(function () { t.className = ""; }, 3200); }
function needFB() { toast("Firebase is not configured yet. Add your keys in the CONFIG block."); }

var S = { all: DEFAULTS.slice(), products: DEFAULTS.slice(), stored: false, cart: load("am_cart", []), wish: load("am_wish", []),
  user: null, isAdmin: false, profile: null, redirect: null, tab: "dashboard", authTab: "login", hook: null, last: null, resellerSettings: JSON.parse(JSON.stringify(CONFIG.resellerDefaults || {})),
  adm: { loaded: false, coupons: [], orders: [], messages: [], users: [], reviews: [], filter: "all" }, newImg: null, sort: "default", cat: "All", q: "" };
var raf = 0, JID = 0;
var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ---------- product tile ---------- */
function jar(hue) { var E = { "-12": "👕", "14": "🎧" }; return '<div class="ptile">' + (E[String(hue)] || "🛍️") + '</div>'; }
function hexLogo() { return '<svg viewBox="0 0 40 40"><rect x="6" y="14" width="28" height="23" rx="5" fill="#D4AF37"/><path d="M13 14v-2a7 7 0 0 1 14 0v2" fill="none" stroke="#F6EBC8" stroke-width="3"/></svg>'; }
(function(){var st=document.createElement("style");st.textContent=".ptile{display:grid;place-items:center;width:100%;height:100%;min-height:170px;font-size:4.5rem;background:linear-gradient(135deg,#EEF2F6,#DCE4EC);border-radius:16px}.cats{margin:0 0 20px;display:flex;flex-wrap:wrap;gap:8px}.cattiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:14px}.ctile{background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px 10px;font:700 .95rem inherit;font-family:inherit;color:var(--ink);cursor:pointer;transition:transform .15s,border-color .15s}.ctile:hover{transform:translateY(-3px);border-color:var(--gold)}.ctile span{display:block;font-size:2.2rem;margin-bottom:6px}.pcat{color:var(--mut);font-size:.78rem;font-weight:700}";document.head.appendChild(st);})();
function pimg(p, hue) {
  var vid = p.video ? '<video class="hv" muted loop playsinline preload="metadata" src="' + esc(p.video) + '"></video>' : "";
  var imgs = (p.images && p.images.length ? p.images : [p.image, p.image2]).filter(function(x,i,a){return x && a.indexOf(x)===i;});
  var gallery = imgs.map(function(src,i){return '<img class="' + (i ? 'am-extra-image' : '') + '" src="' + esc(src) + '" alt="' + esc(p.name) + (i ? ' image ' + (i+1) : '') + '" loading="lazy" decoding="async"/>';}).join("");
  var vimgs = (p.variants || []).filter(function(v){return v.image;}).map(function(v){return '<img class="am-variant-image" src="' + esc(v.image) + '" alt="' + esc(p.name + ' ' + v.size) + '" loading="lazy" decoding="async"/>';}).join("");
  if (gallery || vimgs) return '<div class="am-product-gallery">' + gallery + vimgs + vid + '</div>';
  return '<div class="ptile" role="img" aria-label="' + esc(p.name) + '">' + ((CONFIG.catEmoji || {})[p.cat] || "📦") + '</div>' + vid;
}
function hueOf(p) { var i = S.all.indexOf(p); return [0, -10, 12, -22, 20][(i < 0 ? 0 : i) % 5]; }

/* ---------- data ---------- */
function oos(p) { return p && p.stock != null && p.stock !== "" && Number(p.stock) <= 0; }
function getP(id) { for (var i = 0; i < S.all.length; i++) if (S.all[i].id === id) return S.all[i]; return null; }
function sortP(a) { return a.sort(function (x, y) { return (x.order || 0) - (y.order || 0); }); }
function loadProducts() {
  if (!FB_OK) return Promise.resolve();
  return db.collection("products").get().then(function (s) {
    var a = []; s.forEach(function (d) { var p = d.data(); p.id = d.id; if (!p.variants || !p.variants.length) return; a.push(p); });
    if (a.length) { S.stored = true; S.all = sortP(a); try { localStorage.setItem("am_pc", JSON.stringify(S.all)); } catch (e) { try { localStorage.removeItem("am_pc"); } catch (e2) {} } S.products = S.all.filter(function (p) { return p.active !== false; }); }
    else { S.stored = false; S.all = DEFAULTS.slice(); S.products = DEFAULTS.slice(); }
  }).catch(function (e) { console.warn("Products load failed", e); });
}

/* ---------- cart / wishlist ---------- */
function lines() {
  var out = [];
  S.cart.forEach(function (c) {
    var p = getP(c.pid); if (!p) return;
    var v = null; p.variants.forEach(function (x) { if (x.size === c.size) v = x; }); if (!v && c.size === "Wholesale" && p.ws && (S.isAdmin || (S.profile && S.profile.wholesale))) v = { size: "Wholesale", price: p.ws };
    if (!v) return;
    var q = Math.max(1, Math.floor(Number(c.qty)) || 1); if (p.stock != null && p.stock !== "" && Number(p.stock) > 0) q = Math.min(q, Math.floor(Number(p.stock))); out.push({ p: p, v: v, qty: q, price: slabPrice(c.size, q, Number(v.price)), key: c.pid + "|" + c.size, size: c.size });
  });
  return out;
}
var PK_CITIES = ["Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta", "Gujranwala", "Sialkot", "Hyderabad", "Sargodha", "Bahawalpur", "Sukkur", "Larkana", "Sheikhupura", "Gujrat", "Jhang", "Sahiwal", "Okara", "Kasur", "Mardan", "Abbottabad", "Rahim Yar Khan", "Dera Ghazi Khan", "Mirpur Khas", "Chiniot", "Jhelum", "Attock", "Wah Cantt", "Mingora", "Nawabshah", "Muzaffarabad", "Gilgit", "Sheikhupura", "Hafizabad", "Mandi Bahauddin", "Narowal", "Khanewal", "Vehari"];
function weightOf(size) {
  var m = String(size || "").toLowerCase().match(/([\d.]+)\s*(kg|kilo|gm|grams|gram|g)\b/);
  if (!m) return 0.5; var n = parseFloat(m[1]) || 0; return m[2].charAt(0) === "k" ? n : n / 1000;
}
function cartKg() { var kg = 0; lines().forEach(function (l) { kg += weightOf(l.size === "Wholesale" ? l.p.variants[0].size : l.size) * l.qty; }); return kg; }
function kgText(kg) { return (Math.round(kg * 100) / 100) + " kg"; }
function deliveryFor(sub) {
  if (!sub) return 0;
  var D = S.delivery || {}, fee = D.fee != null ? Number(D.fee) : (Number(CONFIG.deliveryFee) || 0);
  var c = String(S.city || "").trim().toLowerCase(); if (D.cities && c && D.cities[c] != null) fee = Number(D.cities[c]);
  if (D.auto) fee += Math.max(0, Math.ceil(cartKg() - 1e-9) - 1) * (Number(D.perKg) || 0);
  var wholesaleCart = lines().some(function(l){return l.size === "Wholesale";});
  var W = CONFIG.wholesale || {}, _wth = Number(D.wholesaleThreshold != null ? D.wholesaleThreshold : W.threshold), _wfee = Number(D.wholesaleFee != null ? D.wholesaleFee : W.fee), wholesaleThreshold = isFinite(_wth) && _wth >= 0 ? _wth : 50000, wholesaleMinFee = isFinite(_wfee) && _wfee >= 0 ? _wfee : 200;
  if (!wholesaleCart && Number(D.freeAbove) > 0 && sub >= Number(D.freeAbove)) fee = 0;
  if (wholesaleCart && W.enabled !== false && sub >= wholesaleThreshold) fee = Math.max(fee, wholesaleMinFee);
  return fee || 0;
}
function deliveryHint(sub) {
  var D = S.delivery || {}, h = [];
  if (Number(D.freeAbove) > 0) h.push(sub >= D.freeAbove ? "🎉 You get FREE delivery!" : "Add " + fmt(D.freeAbove - sub) + " more for FREE delivery.");
  if (D.auto) h.push("Delivery is worked out automatically from the weight of your order and your city."); else if (D.cities && Object.keys(D.cities).length) h.push("Delivery charge depends on your city and is shown at checkout.");
  return h.length ? '<p style="display:block;font-size:.88rem;color:var(--mut);margin-top:12px">' + h.join("<br/>") + '</p>' : "";
}
function promoTiles() {
  var fa = Number((S.delivery || {}).freeAbove) || 0;
  var T = [
    ["🚚", fa ? "Free delivery above " + fmt(fa) : "Fast delivery", "Order more, pay no delivery charges.", "#/shop", "Shop now"],
    ["🏭", "Wholesale prices", "Buy in bulk and save. Create a Business account.", "#/login", "Get access"],
  ];
  return '<section class="sec first"><div class="wrap"><div class="promo">' + T.map(function (t) { return '<a class="pr" href="' + t[3] + '" onclick="' + (t[3] === "#/login" ? "PH.atab(\'register\')" : "") + '"><i>' + t[0] + '</i><div><b>' + esc(t[1]) + '</b><span>' + esc(t[2]) + '</span></div><em>' + t[4] + ' →</em></a>'; }).join("") + '</div></div></section>';
}
function catTiles() {
  var cs = CONFIG.categories || []; if (cs.length < 2) return "";
  return '<section class="sec first"><div class="wrap"><div class="stitle"><h2>Shop by category</h2><p>Find what you need faster.</p></div><div class="cattiles">' + cs.map(function (c) { return '<button class="ctile" data-c="' + esc(c) + '" onclick="PH.goCat(this.dataset.c)"><span>' + ((CONFIG.catEmoji || {})[c] || "🛍️") + '</span>' + esc(c) + '</button>'; }).join("") + '</div></div></section>';
}
function saveCats() {
  return db.collection("settings").doc("categories").set({ list: CONFIG.categories.map(function (n) { return { name: n, emoji: (CONFIG.catEmoji || {})[n] || "" }; }) });
}
function loadSettings() {
  S.delivery = JSON.parse(JSON.stringify(CONFIG.deliveryDefaults || {}));
  if (typeof db === "undefined" || !db) return Promise.resolve();
  return db.collection("settings").doc("site").get().then(function (d) { S.site = d.exists ? d.data() : {}; }).catch(function () { S.site = {}; }).then(function () { return db.collection("settings").doc("pages").get().then(function (d) { S.pagesList = d.exists ? (d.data().list || []) : []; }).catch(function () { S.pagesList = []; }); }).then(function () { return db.collection("settings").doc("delivery").get(); }).then(function (d) { if (d.exists) S.delivery = d.data(); if (!(Number(S.delivery.freeAbove) > 0) && !S.delivery.freeOff) S.delivery.freeAbove = 5000; }).catch(function () {}).then(function () {
    return db.collection("settings").doc("categories").get().then(function (d) {
      var L = d.exists && d.data().list; if (!L || !L.length) return;
      CONFIG.categories = L.map(function (x) { return x.name; }); CONFIG.catEmoji = CONFIG.catEmoji || {};
      L.forEach(function (x) { if (x.emoji) CONFIG.catEmoji[x.name] = x.emoji; });
    }).catch(function () {});
  });
}
function calcDisc(sub) {
  var c = S.coupon; if (!c || !sub) return 0; if (c.minOrder && sub < c.minOrder) return 0;
  var d = c.type === "percent" ? Math.round(sub * Number(c.value) / 100) : Number(c.value);
  return Math.max(0, Math.min(d || 0, sub));
}
function totals() { var sub = 0; lines().forEach(function (l) { sub += l.price * l.qty; }); var del = deliveryFor(sub), disc = calcDisc(sub), pf = $("#chk"), codFee = pf && pf.pay && pf.pay.value === "Cash on Delivery" ? Number(CONFIG.codFee == null ? 80 : CONFIG.codFee) : 0; return { sub: sub, del: del, disc: disc, codFee: codFee, total: sub - disc + del + codFee }; }
function sumHTML() {
  var L = lines(), t = totals(), c = S.coupon;
  return '<h3 style="margin-bottom:10px">Your order</h3>' + L.map(function (l) { return '<div><span>' + esc(l.p.name) + ' (' + esc(l.size) + ') × ' + l.qty + '</span><b>' + fmt(l.price * l.qty) + '</b></div>'; }).join("") +
    '<div><span>Delivery' + ((S.delivery && S.delivery.auto) ? ' <small style="color:var(--mut)">(' + kgText(cartKg()) + ')</small>' : "") + '</span><b>' + (t.del ? fmt(t.del) : "Free") + '</b></div>' +
    (t.codFee ? '<div><span>Cash on Delivery fee</span><b>' + fmt(t.codFee) + '</b></div>' : "") +
    (t.disc ? '<div style="color:#1b5e2e"><span>Discount (' + esc(c.code) + ')</span><b>- ' + fmt(t.disc) + '</b></div>' : "") +
    '<div class="tot"><span>Total</span><span>' + fmt(t.total) + '</span></div>' +
    deliveryHint(t.sub) + '<div style="display:block;padding:0;margin-top:16px">' + (c ? '<div class="msg ok" style="align-items:center;margin:0">🎟 ' + esc(c.code) + ' applied<button class="rm" type="button" style="margin:0" onclick="PH.rmCoupon()">Remove</button></div>'
      : '<label style="font-weight:700;font-size:.9rem">Discount code</label><div style="padding:6px 0 0;gap:8px"><input class="inp" id="cpn" placeholder="Enter code" style="text-transform:uppercase"/><button class="btn dk sm" type="button" onclick="PH.applyCoupon()">Apply</button></div>') + '<div id="cpmsg" style="display:block;padding:0"></div></div>';
}
function refreshSum() { var b = $("#sumcard"); if (b) b.innerHTML = sumHTML(); var p = $("#pbtn"); if (p) p.textContent = "Place order · " + fmt(totals().total); var pa = $("#payamt"); if (pa) pa.textContent = fmt(totals().total); }
function saveCart() { save("am_cart", S.cart); hdr(); }
function addItem(pid, i, q) {
  var p = getP(pid); if (!p) return; if (oos(p)) return toast("Sorry, this product is out of stock."); var v = p.variants[i] || p.variants[0]; q = Math.max(1, q || 1);
  var f = null; S.cart.forEach(function (c) { if (c.pid === pid && c.size === v.size) f = c; });
  if (f) f.qty += q; else S.cart.push({ pid: pid, size: v.size, qty: q });
  saveCart(); toast("Added to cart: " + p.name + " (" + v.size + ")");
}
function cartCount() { var n = 0; S.cart.forEach(function (c) { n += c.qty; }); return n; }

/* ---------- mail ---------- */
function sendMail(to, subject, message, name, extra, tpl) {
  if (!EJ_OK || !to) return Promise.resolve();
  var p = { to_email: to, email: to, to_name: name || "", subject: subject, message: message, reply_to: SH.email };
  if (extra) for (var k in extra) p[k] = extra[k];
  return emailjs.send(CONFIG.emailjs.serviceId, tpl || CONFIG.emailjs.templateId, p)
    .catch(function (e) { console.warn("EmailJS error", e); });
}
function itemsHtml(o) {
  return o.items.map(function (i) {
    return '<tr><td style="padding:10px 0;border-bottom:1px solid #E8ECF1;font-size:14px;color:#0F2540">' + esc(i.name) + '<br/><span style="color:#5B6B7C;font-size:12px">' + esc(i.size) + ' x ' + i.qty + '</span></td><td align="right" style="padding:10px 0;border-bottom:1px solid #E8ECF1;font-size:14px;color:#0F2540;white-space:nowrap">' + fmt(i.price * i.qty) + '</td></tr>';
  }).join("");
}
function mailVars(o, heading, intro) {
  var colors = { Pending: "#D95F00", Confirmed: "#2e7d32", Shipped: "#1565c0", Delivered: "#2e7d32", Cancelled: "#c62828" };
  return { heading: heading, intro: intro, status: o.status, status_color: colors[o.status] || "#D95F00", order_no: o.orderNo,
    order_date: new Date(o.createdMs).toLocaleString(), order_total: fmt(o.total), subtotal: fmt(o.subtotal), delivery: fmt(o.delivery),
    payment_method: o.paymentMethod, customer_name: o.customer.name, customer_phone: o.customer.phone,
    customer_address: o.customer.address + ", " + o.customer.city, orders: o.items.map(function (i) { return { name: i.name + " (" + i.size + ")", units: i.qty, price: fmt(i.price * i.qty) }; }), order_id: o.orderNo, has_discount: o.discount ? "yes" : "", discount: "- " + fmt(o.discount || 0),
    shop_name: SH.name, shop_phone: SH.phone, shop_email: SH.email, track_url: location.href.split("#")[0] + "#/account" };
}
var STATUS_MAIL = {
  Pending: ["Order received", "we have received your order and are checking it."],
  Confirmed: ["Your order is confirmed", "great news! Your order has been confirmed and is being packed."],
  Shipped: ["Your order is on the way", "your parcel has been handed to our delivery partner."],
  Delivered: ["Your order was delivered", "your order has been delivered. We hope you enjoy your purchase!"],
  Cancelled: ["Your order was cancelled", "your order has been cancelled. If this is a mistake, please contact us."]
};
function orderText(o) {
  var L = o.items.map(function (i) { return "- " + i.name + " (" + i.size + ") x " + i.qty + " = " + fmt(i.price * i.qty); }).join("\n");
  return "Order No: " + o.orderNo + "\nDate: " + new Date(o.createdMs).toLocaleString() + "\n\nCustomer: " + o.customer.name + "\nPhone: " + o.customer.phone + "\nEmail: " + o.customer.email +
    "\nCity: " + o.customer.city + "\nAddress: " + o.customer.address + "\nNotes: " + (o.customer.notes || "-") + "\n\nItems:\n" + L +
    "\n\nSubtotal: " + fmt(o.subtotal) + "\nDelivery: " + fmt(o.delivery) + (o.discount ? "\nDiscount (" + o.coupon + "): -" + fmt(o.discount) : "") + "\nTOTAL: " + fmt(o.total) +
    "\nPayment: " + o.paymentMethod + (o.txnId ? " (Transaction ID: " + o.txnId + ")" : "") + "\nPayment status: " + (o.paymentStatus || "-") + "\nStatus: " + o.status;
}

/* ---------- images ---------- */
function compress(file, max, q) {
  return new Promise(function (res, rej) {
    var r = new FileReader(); r.onerror = rej;
    r.onload = function () {
      var im = new Image(); im.onerror = rej;
      im.onload = function () {
        var k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        var x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
        res(c.toDataURL("image/jpeg", q));
      };
      im.src = r.result;
    };
    r.readAsDataURL(file);
  });
}
function storeImg(dataUrl, folder) {
  if (storage) { return storage.ref(folder + "/" + Date.now() + ".jpg").putString(dataUrl, "data_url").then(function (s) { return s.ref.getDownloadURL(); }); }
  if (dataUrl.length > 900000) return Promise.reject(new Error("Image is too large. Use a smaller image."));
  return Promise.resolve(dataUrl);
}

/* ---------- shell ---------- */
function shell() {
  $("#app").innerHTML =
  '<div class="topbar"><span id="tbfree">Cash on Delivery · JazzCash · EasyPaisa</span><span>WhatsApp support: ' + SH.phone + '</span></div>' +
  '<header class="nav"><a class="logo" href="#/home">' + hexLogo() + '<span>Online <b>Shah Alami</b></span></a>' +
  '<button class="burger" id="burger" aria-label="Open menu" onclick="PH.menu()"><i></i><i></i><i></i></button>' +
  '<nav id="nav"><a href="#/home" data-r="home">Home</a><a href="#/shop" data-r="shop">Shop</a><a href="#/about" data-r="about">About Us</a><a href="#/contact" data-r="contact">Contact Us</a><a href="#/policies" data-r="policies">Policies</a><a href="#/faq" data-r="faq">FAQs</a><a href="#/account" data-r="track">Track Order</a>' +
  '<a href="#/cart" data-r="cart">Cart<em id="cc">0</em></a><a href="#/wishlist" data-r="wishlist">Wishlist<em id="wc">0</em></a>' +
  '<a href="#/login" data-r="login" id="lg">Login</a></nav></header>' +
  '<div class="am-search-row"><form class="hsearch" onsubmit="PH.hsearch(event)"><input name="q" placeholder="Search products by name or related words" aria-label="Search products"/><button type="submit">Search</button></form></div>' +
  '<nav class="catbar" aria-label="Categories"><a href="#/shop" onclick="PH.goCat(\'All\')">All products</a>' + (CONFIG.categories || []).map(function (c) { return '<a href="#/shop" data-c="' + esc(c) + '" onclick="PH.goCat(this.dataset.c);return false">' + esc(c) + '</a>'; }).join("") + '</nav>' +
  '<main id="view"></main>' +
  '<footer class="amf"><div class="wrap">' +
  '<div class="amf-trust"><div><span>🚚</span><b>Delivery across Pakistan</b><small>Fast and tracked orders</small></div><div><span>💵</span><b>Cash on Delivery</b><small>Pay when you receive</small></div><div><span>🔄</span><b>Return &amp; refund</b><small>Clear store policy</small></div><div><span>💬</span><b>Friendly support</b><small>' + esc(SH.hours) + '</small></div></div>' +
  '<div class="amf-grid">' +
  '<div class="amf-brand"><a class="logo" href="#/home">' + hexLogo() + '<span>Online <b>Shah Alami</b></span></a><p>Your one-stop online shop for everything. Quality products, honest prices and doorstep delivery.</p><div class="amf-cta"><a class="amf-btn wa-btn" href="https://wa.me/' + SH.whatsapp + '" target="_blank" rel="noopener">💬 Chat on WhatsApp</a><a class="amf-btn" href="tel:' + SH.phone + '">📞 Call us</a></div></div>' +
  '<div><h4>Shop</h4><a href="#/shop">All products</a><a href="#/deals">Deals &amp; offers</a><a href="#/stores">Stores &amp; brands</a><a href="#/vouchers">Vouchers</a><a href="#/cart">Cart</a><a href="#/wishlist">Wishlist</a></div>' +
  '<div><h4>Business</h4><a href="#/wholesale-center">Wholesale portal</a><a href="#/reseller-center">Reseller portal</a><a href="#/seller-center">Business centre</a><a href="#/account">My account</a></div>' +
  '<div><h4>Help &amp; policies</h4><a href="#/about">About us</a><a href="#/contact">Contact us</a><a href="#/faq">FAQs</a><a href="#/help-center">Help centre</a><a href="#/policies/delivery">Delivery policy</a><a href="#/policies/returns">Return &amp; refund</a><a href="#/policies/privacy">Privacy policy</a><a href="#/policies/terms">Terms &amp; conditions</a></div>' +
  '<div><h4>Contact</h4><a href="tel:' + SH.phone + '">📞 ' + SH.phone + '</a><a href="https://wa.me/' + SH.whatsapp + '" target="_blank" rel="noopener">💬 WhatsApp ' + SH.phone + '</a><a href="mailto:' + SH.email + '">✉️ ' + SH.email + '</a><span class="amf-row">🕒 ' + SH.hours + '</span></div>' +
  '</div>' +
  '<div class="amf-pay"><b>We accept</b><span>💵 Cash on Delivery</span><span>JazzCash: ' + SH.jazzcash + '</span><span>EasyPaisa: ' + SH.easypaisa + '</span><span>Account: ' + SH.accountName + '</span></div>' +
  '<div class="amf-bottom"><span>© ' + new Date().getFullYear() + ' Online Shah Alami. All rights reserved.</span><a href="#" onclick="window.scrollTo({top:0,behavior:\'smooth\'});return false">↑ Back to top</a></div>' +
  '</div></footer>' +
  '<a class="wa" href="https://wa.me/' + SH.whatsapp + '" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">💬</a>';
}
function hdr() {
  var c = $("#cc"), w = $("#wc"), l = $("#lg"); if (!c) return;
  chatInit(); var nv = $("#nav"); if (nv) { nv.querySelectorAll(".cp").forEach(function (a) { a.remove(); }); (S.pagesList || []).forEach(function (g) { var a = document.createElement("a"); a.className = "cp"; a.href = "#/page/" + g.id; a.textContent = g.title; nv.appendChild(a); }); }
  c.textContent = cartCount(); w.textContent = S.wish.length;
  var tf = $("#tbfree"); if (tf) { var fa = Number((S.delivery || {}).freeAbove) || 0; tf.textContent = "Cash on Delivery · JazzCash · EasyPaisa" + (fa ? " · 🚚 Free delivery above " + fmt(fa) : ""); }
  l.textContent = S.user ? (S.isAdmin ? "Admin Panel" : "Account") : "Login";
  l.setAttribute("href", (S.user && !S.user.isAnonymous) ? (S.isAdmin ? "#/admin" : "#/account") : "#/login"); l.setAttribute("data-r", (S.user && !S.user.isAnonymous) ? (S.isAdmin ? "admin" : "account") : "login");
}

/* ---------- page parts ---------- */
function banner(t, s) { return '<section class="phead"><div class="wrap"><button class="back" onclick="PH.back()">← Back</button><h1>' + t + '</h1>' + (s ? '<p>' + s + '</p>' : "") + '</div></section>'; }
function chips(p) { return p.variants.map(function (v, i) { return '<button class="chip' + (i ? "" : " on") + '" data-i="' + i + '" data-p="' + v.price + '" onclick="PH.pick(this)">' + esc(v.size) + '</button>'; }).join(""); }
function pcard(p, wl) {
  var w = S.wish.indexOf(p.id) > -1;
  return '<article class="pcard rv" data-tilt data-pid="' + p.id + '">' +
    '<button class="heart' + (w ? " on" : "") + '" onclick="PH.wish(\'' + p.id + '\',this)" aria-label="Wishlist">♥</button>' +
    (oos(p) ? '<span class="badge" style="background:#b3261e;color:#fff">Out of stock</span>' : (p.badge ? '<span class="badge">' + esc(p.badge) + '</span>' : "")) +
    '<a class="pimg" href="#/product/' + p.id + '">' + pimg(p, hueOf(p)) + '</a>' +
    '<div class="pbody"><span class="pcat">' + esc(p.cat || "") + '</span><h3><a href="#/product/' + p.id + '">' + esc(p.name) + '</a></h3><div class="chips">' + chips(p) + '</div>' +
    '<div class="price" data-price>' + fmt(p.variants[0].price) + '</div>' + (p.oldPrice > p.variants[0].price ? '<div style="text-decoration:line-through;color:var(--mut);font-size:.9rem;margin-top:-10px;margin-bottom:10px">' + fmt(p.oldPrice) + '</div>' : "") + (p.ws ? '<div class="wsl">Wholesale: ' + fmt(p.ws) + ' (min ' + (p.wsMin || 10) + ')</div>' : "") + (oos(p) ? '<button class="btn sm" disabled="disabled">Out of stock</button>' : '<div class="pbtns"><button class="btn sm" onclick="PH.add(this)">Add to Cart</button><button class="btn dk sm" onclick="PH.buy(this)">Buy Now</button></div>') + (wl === true ? ' <button class="btn red sm" onclick="PH.wish(\'' + p.id + '\')">✕ Remove</button>' : "") + '</div></article>';
}

/* ---------- pages ---------- */
function pHome() {
  S.hook = drawHomeReviews;
  var d = "";
  for (var i = 0; i < 16; i++) { d += '<span class="drip" style="left:' + (i * 6.4 + (i % 3) * 1.2) + '%;--w:' + (12 + (i * 7) % 12) + 'px;--h:' + (38 + (i * 23) % 70) + 'px;--d:' + (2.4 + (i % 5) * .7) + 's;animation-delay:-' + (i % 4) * .6 + 's"></span>'; }
  return '<section class="hero"><canvas id="parts"></canvas><div class="wrap hero-grid"><div>' +
    '<span class="tag">🛍️ Everything in one place</span><h1>Shop Everything.<span class="gold">Pay Easy.</span></h1>' +
    '<p class="sub">Fashion, electronics, home, beauty and more. Delivered across Pakistan.</p>' +
    '<div class="btns"><a class="btn" href="#/shop">Shop Now</a><a class="btn ghost" href="#/about">Learn More</a></div>' +
    '<div class="stats"><div><b>All</b>Categories</div><div><b>24/7</b>Open</div><div><b>COD</b>JazzCash &amp; EasyPaisa</div></div></div>' +
    '<div class="hero-visual" aria-hidden="true"><div class="hero-orbit"></div><div class="hero-orbit orbit-b"></div><div class="hero-cube"><div class="cube-face cf1"><b>ANAS</b><small>MART</small></div><div class="cube-face cf2"><b>ANAS</b><small>MART</small></div><div class="cube-face cf3">👑</div><div class="cube-face cf4">👑</div><div class="cube-face cf5">★</div><div class="cube-face cf6"></div></div><div class="float-card fc1"><span>🚚</span><b>Fast delivery</b><small>Across Pakistan</small></div><div class="float-card fc2"><span>💳</span><b>COD · JazzCash · EasyPaisa</b><small>Easy payment</small></div></div></div>' +
    '</section><section class="trust"><div class="wrap"><div><i>🚚</i><p><b>Fast delivery</b><span>In ' + esc(CONFIG.policy.deliveryTime) + '</span></p></div><div><i>💳</i><p><b>Easy payment</b><span>COD, JazzCash, EasyPaisa</span></p></div><div><i>💬</i><p><b>WhatsApp support</b><span>' + SH.phone + '</span></p></div><div><i>🔄</i><p><b>Easy returns</b><span>Within ' + esc(CONFIG.policy.returnWindow) + '</span></p></div></div></section>' +
    siteBar() + secProd('🆕 New Arrivals', 'isNew') + secProd('🔥 Most Demanded', 'hot') + promoTiles() + '<section class="sec"><div class="wrap"><div class="stitle"><h2>Featured Products</h2><p>Our best-selling and newest products.</p></div><div class="grid">' +
    homeProducts().map(function (p) { return pcard(p); }).join("") + '</div><div style="text-align:center;margin-top:40px"><a class="btn dk" href="#/shop">View all products</a></div></div></section>' +
    '<section class="sec white"><div class="wrap"><div class="stitle"><h2>Why shop with us</h2><p>Simple, safe and fast shopping.</p></div><div class="ben">' + BEN.map(function (b) { return '<div class="bcard rv" data-tilt><div class="bi">' + b[0] + '</div><h3>' + b[1] + '</h3><p>' + b[2] + '</p></div>'; }).join("") + '</div><p class="fine">Always read product labels and instructions before use.</p></div></section>' +
    '<section class="sec dark"><div class="wrap"><div class="stitle"><h2>Why choose Online Shah Alami</h2><p>Everything you need, delivered to your door.</p></div><div class="feat">' +
    '<div class="glass"><div class="ic">🌿</div><h3>Wide choice</h3><p>Products for every need, all in one store.</p></div>' +
    '<div class="glass"><div class="ic">🏷️</div><h3>Fair prices</h3><p>Clear prices with no hidden charges.</p></div>' +
    '<div class="glass"><div class="ic">💳</div><h3>Easy payment</h3><p>Pay by Cash on Delivery, JazzCash or EasyPaisa.</p></div>' +
    '<div class="glass"><div class="ic">💬</div><h3>Support any time</h3><p>Call or WhatsApp us 24/7 on ' + SH.phone + '.</p></div></div></div></section>' +
    '<section class="sec white"><div class="wrap cta"><h2 style="color:var(--ink)">Ready to shop?</h2><p style="color:var(--mut)">Order now, or message us on WhatsApp and we will help you choose.</p><div class="btns" style="justify-content:center"><a class="btn" href="#/shop">Order now</a><a class="btn dk" href="https://wa.me/' + SH.whatsapp + '" target="_blank" rel="noopener">WhatsApp us</a></div></div></section>' +
    '<section class="sec dark" id="reviews"><div class="wrap"><div class="stitle"><h2>What our customers say</h2><p>Real reviews from Online Shah Alami customers.</p></div><div class="rgrid" id="hrev"><p>Loading reviews...</p></div></div></section>';
}
function homeProducts() { var h = S.products.filter(function (p) { return p.home; }); return h.length ? h : S.products.slice(0, 8); }
function secProd(t, k) { var a = S.products.filter(function (p) { return p[k]; }).slice(0, 8); return a.length ? '<section class="sec"><div class="wrap"><div class="stitle"><h2>' + t + '</h2></div><div class="grid">' + a.map(function (p) { return pcard(p); }).join("") + '</div></div></section>' : ""; }
var NT = 0;
function noticeList() {
  var raw = String((S.site && S.site.notice) || "Hi! Welcome to Online Shah Alami"), a = raw.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean);
  if (!a.length) a = ["Hi! Welcome to Online Shah Alami"];
  if (a.length < 2) { var fa = Number((S.delivery || {}).freeAbove) || 0; a.push(fa ? "🚚 Free delivery on orders above " + fmt(fa) : "🛍️ Shop fashion, electronics, home and more"); }
  return a;
}
function startNotice() {
  clearInterval(NT); var el = $("#noticeTxt"); if (!el) return; var a = noticeList(), i = 0; if (a.length < 2) return;
  NT = setInterval(function () { var e = $("#noticeTxt"); if (!e) { clearInterval(NT); return; } e.classList.add("out"); setTimeout(function () { i = (i + 1) % a.length; e.textContent = a[i]; e.classList.remove("out"); }, 400); }, 5000);
}
function siteBar() { var x = S.site || {}; return (x.banner ? '<div class="wrap" style="padding:20px 20px 0"><img src="' + esc(x.banner) + '" alt="" style="width:100%;border-radius:26px;max-height:320px;object-fit:cover"/></div>' : "") + '<div class="wrap" style="padding:16px 20px 0"><div class="note">📢 <span id="noticeTxt">' + esc(noticeList()[0]) + '</span></div></div>'; }
function bubble(x, me) { return '<div style="margin:4px 0;text-align:' + (x.f === me ? "right" : "left") + '"><span style="display:inline-block;padding:6px 10px;border-radius:12px;background:' + (x.f === me ? "#FFD2A8" : "#E9EEF3") + '">' + esc(x.t) + '</span></div>'; }
function chatInit() { if ($("#cw")) return; var d = document.createElement("div"); d.id = "cw"; d.innerHTML = '<button id="cb" class="btn sm" onclick="PH.chatTog()" style="position:fixed;left:16px;bottom:16px;z-index:50">💬 Chat with us</button><div id="cp" style="display:none;position:fixed;left:16px;bottom:70px;z-index:50;width:320px;max-width:calc(100vw - 32px);background:#fff;border-radius:18px;box-shadow:0 12px 30px rgba(15,37,64,.25);padding:12px"><b>Customer support</b><div id="cm" style="height:170px;overflow:auto;margin:8px 0;font-size:.9rem"></div><div id="cq"></div><form onsubmit="PH.chatSend(event)" style="display:flex;gap:6px"><input name="m" class="inp" placeholder="Type a message" required="required"/><button class="btn sm" type="submit">Send</button></form></div>'; document.body.appendChild(d); }
function startAdminChat() { if (S.chatA || !db) return; S.chatA = db.collection("chats").onSnapshot(function (q) { S.chatList = []; q.forEach(function (d) { var x = d.data(); x.id = d.id; S.chatList.push(x); }); S.chatList.sort(function (a, b) { return (b.updatedMs || 0) - (a.updatedMs || 0); }); if (S.tab === "chat") drawAdmin(); }); }
function savePages() { db.collection("settings").doc("pages").set({ list: S.pagesList }).then(function () { toast("Pages saved"); drawAdmin(); hdr(); }).catch(function (x) { toast(x.message); }); }
function pCustom(id) { var g = (S.pagesList || []).filter(function (x) { return x.id === id; })[0]; if (!g) return banner("Page not found"); return banner(esc(g.title)) + '<section class="sec" style="padding-top:50px"><div class="wrap">' + (g.img ? '<img src="' + esc(g.img) + '" alt="" style="width:100%;border-radius:26px;margin-bottom:20px;max-height:380px;object-fit:cover"/>' : "") + '<div class="card">' + g.body + '</div></div></section>'; }
function pendingCard(t, msg) { return '<div class="card"><h3>' + t + '</h3><p style="color:var(--mut);margin:6px 0 12px">' + msg + '</p><a class="btn sm" target="_blank" rel="noopener" href="https://wa.me/' + SH.whatsapp + '?text=' + encodeURIComponent("Hello " + SH.name + ", please approve my account. Email: " + (S.user ? S.user.email : "")) + '">Message us on WhatsApp</a></div>'; }
function drawWholesale() {
  var b = $("#acc"), pr = S.profile || {};
  if (!pr.wholesale) {
    b.innerHTML = pr.requestedType === "business" ? pendingCard("🏭 Wholesale request received", "Your wholesale account is waiting for approval. This page updates by itself when we approve it.") :
      '<div class="card"><h3>🏭 Wholesale access</h3><p style="color:var(--mut);margin:6px 0">Buy in bulk at wholesale prices. Send a request and we approve your account after checking it.</p><ul style="margin:10px 0 0 22px"><li>Special wholesale prices on products</li><li>Bulk orders with a minimum quantity per product</li><li>Custom quote requests</li><li>Downloadable wholesale price list</li><li>One-tap re-order of past wholesale orders</li></ul><button class="btn" style="margin-top:14px" onclick="PH.reqAccess(\'business\')">Request wholesale access</button></div>';
    return;
  }
  var items = S.products.filter(function (p) { return p.ws; });
  b.innerHTML = '<div class="stat-grid" id="wsstat"><div class="stat"><b>…</b>Wholesale orders</div><div class="stat"><b>…</b>Total spent</div><div class="stat"><b>…</b>Estimated savings</div></div>' +
    '<div class="card" style="margin-bottom:20px"><div class="bar" style="margin:0 0 12px"><h3>Bulk order <span class="st">Approved</span></h3><div class="row" style="gap:8px;flex-wrap:wrap"><input class="inp" placeholder="Search products..." oninput="PH.wsFilter(this.value)" style="max-width:220px;padding:8px 12px"/><button class="btn sm" onclick="PH.wsAll()">Add all to cart</button><button class="btn dk sm" onclick="PH.wsExport()">⬇ Price list</button><a class="btn dk sm" href="#/cart">View cart</a></div></div>' +
    (items.length ? '<div class="tw"><table id="wst"><tr><th>Product</th><th>Retail</th><th>Wholesale</th><th>You save</th><th>Min qty</th><th>Quantity</th><th></th></tr>' + items.map(function (p) {
      var r = minP(p), sv = r > p.ws ? Math.round((r - p.ws) * 100 / r) : 0, mn = p.wsMin || 10;
      return '<tr data-n="' + esc(p.name.toLowerCase()) + '"><td><a href="#/product/' + p.id + '"><b>' + esc(p.name) + '</b></a></td><td>' + fmt(r) + '</td><td><b>' + fmt(p.ws) + '</b></td><td>' + (sv ? sv + "%" : "-") + '</td><td>' + mn + '</td><td><input class="inp" id="wq_' + p.id + '" type="number" min="' + mn + '" value="' + mn + '" style="max-width:100px;padding:6px 10px"/></td><td>' + (oos(p) ? "Out of stock" : '<button class="btn sm" onclick="PH.wsAdd(\'' + p.id + '\')">Add bulk</button>') + '</td></tr>'; }).join("") + '</table></div>' : '<p>No wholesale products yet. Please check back soon.</p>') + '</div>' +
    '<div class="two"><form class="card" onsubmit="PH.wsQuote(event)"><h3 style="margin-bottom:6px">Request a custom quote</h3><p style="color:var(--mut);margin-bottom:12px">Need a product or quantity that is not listed? Tell us and we will reply.</p><div class="fld"><label>Product / item</label><input name="item" required="required"/></div><div class="fld"><label>Quantity</label><input name="qty" type="number" min="1" required="required"/></div><div class="fld"><label>Notes (optional)</label><textarea name="note" rows="2"></textarea></div><button class="btn" type="submit">Send quote request</button></form>' +
    '<div class="card"><h3 style="margin-bottom:10px">How wholesale works</h3><ul style="margin-left:22px"><li>Pick a quantity at or above the minimum and press Add bulk.</li><li>Wholesale prices apply to Wholesale lines in your cart.</li><li>Pay by COD, JazzCash, EasyPaisa or bank.</li><li>Delivery is free above ' + fmt((S.delivery || {}).freeAbove || 5000) + '.</li></ul></div></div>' +
    '<h3 style="margin:24px 0 12px">My wholesale orders</h3><div id="wsord"><p>Loading...</p></div>';
  loadMyOrders().then(function (a) {
    var n = 0, tot = 0, sv = 0, rows = [];
    a.forEach(function (o) { if (o.status === "Cancelled") return; var w = (o.items || []).filter(function (i) { return i.size === "Wholesale"; }); if (!w.length) return; n++; tot += o.total || 0; w.forEach(function (i) { var p = getP(i.pid); if (p) sv += Math.max(0, minP(p) - i.price) * i.qty; }); rows.push(o); });
    var s = $("#wsstat"); if (s) { s.children[0].innerHTML = '<b>' + n + '</b>Wholesale orders'; s.children[1].innerHTML = '<b>' + fmt(tot) + '</b>Total spent'; s.children[2].innerHTML = '<b>' + fmt(sv) + '</b>Estimated savings'; }
    var w = $("#wsord"); if (w) w.innerHTML = rows.length ? '<div class="tw"><table><tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th></th></tr>' + rows.map(function (o) { return '<tr><td><b>' + o.orderNo + '</b></td><td>' + new Date(o.createdMs).toLocaleDateString() + '</td><td>' + o.items.map(function (i) { return esc(i.name) + " (" + esc(i.size) + ") × " + i.qty; }).join("<br/>") + '</td><td>' + fmt(o.total) + '</td><td><span class="st">' + esc(o.status) + '</span></td><td class="row"><button class="btn dk sm" onclick="PH.track(\'' + o.id + '\')">Track</button><button class="btn sm" onclick="PH.reorder(\'' + o.id + '\')">Order again</button></td></tr>'; }).join("") + '</table></div>' : '<p>No wholesale orders yet.</p>';
  }).catch(function (e) { var w = $("#wsord"); if (w) w.innerHTML = '<p class="msg err">Could not load orders: ' + esc(e.message) + '</p>'; });
}
function rprods(sold) {
  var t = $("#rprod"); if (!t) return; var mine = S.all.filter(function (p) { return p.owner === S.user.uid; });
  t.innerHTML = mine.length ? '<div class="tw"><table><tr><th>Image</th><th>Name</th><th>Price</th><th>Sold</th><th>Status</th><th></th></tr>' + mine.map(function (p) { var live = p.active !== false, s = sold[p.id]; return '<tr><td>' + (p.image ? '<img src="' + esc(p.image) + '" alt="" style="width:46px;height:46px;object-fit:cover;border-radius:8px"/>' : "📦") + '</td><td><b>' + esc(p.name) + '</b></td><td>' + fmt(minP(p)) + '</td><td>' + (s ? s.units + " pcs · " + fmt(s.comm) : "-") + '</td><td><span class="st">' + (live ? "Live" : "Waiting for approval") + '</span></td><td class="row"><button class="btn dk sm" onclick="PH.pform(\'' + p.id + '\')">Edit</button>' + (live ? '<button class="btn dk sm" onclick="PH.rcopy(\'' + p.id + '\')">Copy link</button><button class="btn sm" onclick="PH.rwa(\'' + p.id + '\')">Share</button>' : "") + '<button class="btn red sm" onclick="PH.pdel(\'' + p.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>' : '<p>You have not added any products yet. Press "+ Add my product".</p>';
}
function drawReseller() {
  if (FB_OK && db && !S.resellerSettingsLoaded) { S.resellerSettingsLoaded = true; db.collection("settings").doc("reseller").get().then(function(d){ if(d.exists) { S.resellerSettings=d.data(); CONFIG.commissionPct=Number(d.data().commissionPct==null?CONFIG.commissionPct:d.data().commissionPct); } if(location.hash.indexOf("#/account")===0 && S.accTab==="reseller") drawReseller(); }).catch(function(){}); }
  var b = $("#acc"), pr = S.profile || {}, cp = Number((S.resellerSettings || {}).commissionPct == null ? CONFIG.commissionPct : S.resellerSettings.commissionPct);
  if (pr.type !== "reseller") {
    b.innerHTML = pr.requestedType === "reseller" ? pendingCard("🤝 Reseller request received", "Your reseller account is waiting for approval. This page updates by itself when we approve it.") :
      '<div class="card"><h3>🤝 Become a reseller</h3><p style="color:var(--mut);margin:6px 0">Sell your own products on Online Shah Alami and earn ' + cp + '% commission on every delivered sale.</p><ul style="margin:10px 0 0 22px"><li>Add and manage your own products</li><li>Share product links on WhatsApp</li><li>Track orders, sales and commission</li><li>Request payouts and download statements</li></ul><button class="btn" style="margin-top:14px" onclick="PH.reqAccess(\'reseller\')">Request reseller access</button></div>';
    return;
  }
  b.innerHTML = '<div class="card" style="margin-bottom:20px"><div class="bar" style="margin:0 0 10px"><h3>🤝 Reseller dashboard <span class="st">Approved</span></h3><div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn sm" onclick="PH.pform()">+ Add my product</button><button class="btn dk sm" onclick="PH.rexport()">⬇ Statement (Excel)</button></div></div><p style="color:var(--mut)">Products go live after admin approval (edits need approval again). You earn ' + cp + '% commission on each sale, paid for delivered orders.' + (pr.refCode ? ' Your reseller ID: <b>' + esc(pr.refCode) + '</b>' : "") + '</p></div>' +
    '<div class="stat-grid" id="rstat"></div><h3 style="margin:20px 0 10px">My products</h3><div id="rprod"></div>' +
    '<div class="two" style="margin-top:24px"><form class="card" onsubmit="PH.payout(event)"><h3 style="margin-bottom:6px">Request a payout</h3><p style="color:var(--mut);margin-bottom:12px" id="ravail">Available: calculating...</p><div class="fld"><label>Payment method</label><select name="method" class="inp"><option>JazzCash</option><option>EasyPaisa</option><option>Bank Account</option></select></div><div class="fld"><label>Account number</label><input name="acct" required="required"/></div><div class="fld"><label>Amount (PKR)</label><input name="amt" type="number" min="1" required="required"/></div><button class="btn" type="submit">Send payout request</button></form>' +
    '<div class="card"><h3 style="margin-bottom:10px">Rules</h3><div id="resellerRulesText" style="white-space:pre-line;line-height:1.75">' + esc((S.resellerSettings && S.resellerSettings.rules) || (CONFIG.resellerDefaults && CONFIG.resellerDefaults.rules) || "Follow the rules set by Online Shah Alami admin.") + '</div></div></div>' +
    '<h3 style="margin:24px 0 12px">Orders with my products</h3><div id="rord"><p>Loading...</p></div>';
  rprods({});
  db.collection("orders").where("owners", "array-contains", S.user.uid).get().then(function (q) {
    var tot = 0, pend = 0, sales = 0, rows = [], sold = {};
    q.forEach(function (d) { var o = d.data(), mi = (o.items || []).filter(function (i) { return i.owner === S.user.uid; }); if (!mi.length) return;
      mi.forEach(function (i) { if (o.status === "Cancelled") return; sales += (i.price || 0) * (i.qty || 0); if (o.status === "Delivered") tot += i.comm || 0; else pend += i.comm || 0; var s = sold[i.pid] || (sold[i.pid] = { units: 0, comm: 0 }); s.units += i.qty || 0; s.comm += i.comm || 0; });
      rows.push({ o: o, items: mi }); });
    rows.sort(function (x, y) { return y.o.createdMs - x.o.createdMs; }); S.rrows = rows; S.rAvail = tot;
    var live = S.all.filter(function (p) { return p.owner === S.user.uid && p.active !== false; }).length, all = S.all.filter(function (p) { return p.owner === S.user.uid; }).length;
    var st = $("#rstat"); if (st) st.innerHTML = '<div class="stat"><b>' + live + '</b>Live products</div><div class="stat"><b>' + (all - live) + '</b>Waiting approval</div><div class="stat"><b>' + rows.length + '</b>Orders</div><div class="stat"><b>' + fmt(sales) + '</b>Total sales</div><div class="stat"><b>' + fmt(tot) + '</b>Commission earned</div><div class="stat"><b>' + fmt(pend) + '</b>Commission pending</div>';
    var av = $("#ravail"); if (av) av.innerHTML = 'Available (delivered orders): <b>' + fmt(tot) + '</b>';
    rprods(sold);
    var r = $("#rord"); if (r) r.innerHTML = rows.length ? '<div class="tw"><table><tr><th>Order</th><th>Date</th><th>My items</th><th>Commission</th><th>Status</th></tr>' + rows.slice(0, 30).map(function (x) { var cm = 0; x.items.forEach(function (i) { cm += i.comm || 0; }); return '<tr><td><b>' + esc(x.o.orderNo) + '</b></td><td>' + new Date(x.o.createdMs).toLocaleDateString() + '</td><td>' + x.items.map(function (i) { return esc(i.name) + " (" + esc(i.size) + ") × " + i.qty; }).join("<br/>") + '</td><td>' + fmt(cm) + '</td><td><span class="st">' + esc(x.o.status) + '</span></td></tr>'; }).join("") + '</table></div>' : '<p>No orders yet.</p>';
  }).catch(function (e) { var r = $("#rord"); if (r) r.innerHTML = '<p class="msg err">Could not load orders: ' + esc(e.message) + '</p>'; var av = $("#ravail"); if (av) av.textContent = ""; });
}
function fxImg(src, mode) {
  function load(u) { return new Promise(function (res, rej) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = rej; i.src = u; }); }
  function draw(i, white, enh) { var n = white ? 800 : 0, c = document.createElement("canvas"), w = i.width, h = i.height, k = n ? Math.min(n * .9 / w, n * .9 / h) : 1; c.width = n || w; c.height = n || h; var x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); if (enh) x.filter = "contrast(1.12) saturate(1.15) brightness(1.04)"; x.drawImage(i, (c.width - w * k) / 2, (c.height - h * k) / 2, w * k, h * k); return c.toDataURL("image/jpeg", .85); }
  if (mode === "bg") { if (!CONFIG.removeBgKey) return Promise.reject(new Error("Add your remove.bg key in CONFIG (removeBgKey)")); var fd = new FormData(); fd.append("image_file_b64", src.split(",")[1]); fd.append("size", "auto");
    return fetch("https://api.remove.bg/v1.0/removebg", { method: "POST", headers: { "X-Api-Key": CONFIG.removeBgKey }, body: fd }).then(function (r) { if (!r.ok) throw new Error("remove.bg error " + r.status); return r.blob(); }).then(function (b) { return new Promise(function (res) { var fr = new FileReader(); fr.onload = function () { res(fr.result); }; fr.readAsDataURL(b); }); }).then(load).then(function (i) { return draw(i, true, false); }); }
  return load(src).then(function (i) { return draw(i, mode === "white", mode === "enh"); });
}
function pShop() {
  S.hook = drawShop;
  return banner("Shop", "Browse every category.") +
    '<section class="sec first" style="padding-top:50px"><div class="wrap"><div class="bar"><input class="inp" style="max-width:320px" placeholder="Search products..." value="' + esc(S.q) + '" oninput="PH.search(this.value)"/>' +
    '<select class="inp" style="max-width:220px" onchange="PH.sort(this.value)"><option value="default">Sort: Featured</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></div><div class="chips cats" id="cats"></div><div class="grid" id="grid"></div></div></section>';
}
function minP(p) { return Math.min.apply(null, p.variants.map(function (v) { return Number(v.price); })); }
function drawShop() {
  var g = $("#grid"); if (!g) return;
  var cs = $("#cats");
  if (cs) {
    var names = ["All"]; S.products.forEach(function (p) { var c = p.cat || "General"; if (names.indexOf(c) < 0) names.push(c); });
    cs.innerHTML = names.length > 2 ? names.map(function (c) { return '<button class="chip' + (c === S.cat ? " on" : "") + '" data-c="' + esc(c) + '" onclick="PH.setcat(this.dataset.c)">' + esc(c) + '</button>'; }).join("") : "";
  }
  var a = S.products.filter(function (p) { return (S.cat === "All" || (p.cat || "General") === S.cat) && (!S.q || matchQ(p, S.q)); });
  if (S.sort === "low") a.sort(function (x, y) { return minP(x) - minP(y); });
  if (S.sort === "high") a.sort(function (x, y) { return minP(y) - minP(x); });
  var sig = S.cat + "|" + S.q + "|" + S.sort; if (S.sig !== sig) { S.sig = sig; S.shown = 12; } S.shown = S.shown || 12; var tot = a.length; a = a.slice(0, S.shown);
  g.innerHTML = a.length ? a.map(function (p) { return pcard(p); }).join("") + (tot > a.length ? '<div class="morebar"><p>Showing ' + a.length + " of " + tot + '</p><button class="btn dk" onclick="PH.more()">Load more products</button></div>' : "") : '<div class="empty" style="grid-column:1/-1"><div class="big">🔍</div><p>No products found. Try another search.</p></div>';
  after();
}
function stars(n) { var t = ""; for (var i = 1; i <= 5; i++) t += i <= Math.round(n) ? "★" : "☆"; return '<span class="stars">' + t + '</span>'; }
function rcard(r, showProd) {
  return '<div class="rcard"><div class="rtop"><div class="av">' + esc(String(r.name || "C").charAt(0).toUpperCase()) + '</div><div><b>' + esc(r.name) + '</b><div>' + stars(r.rating) + '</div></div></div><p>“' + esc(r.text) + '”</p>' + (r.photo ? '<img class="am-review-photo" src="' + esc(r.photo) + '" alt="Customer review photo" loading="lazy"/>' : '') + '<small>' +
    (showProd ? 'About <a href="#/product/' + esc(r.productId) + '" style="color:var(--amber);font-weight:700">' + esc(r.productName) + '</a> · ' : "") + new Date(r.createdMs).toLocaleDateString() + '</small></div>';
}
function revSummary(a) {
  if (!a.length) return '<span class="stars">☆☆☆☆☆</span> No reviews yet';
  var t = 0; a.forEach(function (r) { t += r.rating; }); var av = t / a.length;
  return stars(av) + ' <b>' + av.toFixed(1) + '</b> (' + a.length + ' review' + (a.length > 1 ? "s" : "") + ')';
}
function loadReviews(filterPid) {
  var q = db.collection("reviews").where("approved", "==", true);
  if (filterPid) q = q.where("productId", "==", filterPid);
  return q.get().then(function (s) { var a = []; s.forEach(function (d) { var r = d.data(); r.id = d.id; a.push(r); }); return a.sort(function (x, y) { return y.createdMs - x.createdMs; }); });
}
function drawHomeReviews() {
  var b = $("#hrev"); if (!b) return;
  var none = '<div class="empty" style="grid-column:1/-1"><div class="big">⭐</div><p>No reviews yet. Buy a product and be the first to tell us what you think.</p><a class="btn" href="#/shop" style="margin-top:14px">Shop now</a></div>';
  if (!FB_OK) { b.innerHTML = none; return; }
  loadReviews().then(function (a) { if ($("#hrev")) $("#hrev").innerHTML = a.length ? a.slice(0, 6).map(function (r) { return rcard(r, true); }).join("") : none; })
    .catch(function () { if ($("#hrev")) $("#hrev").innerHTML = none; });
}
function drawProdReviews(id) {
  var L = $("#plist"); if (!L) return;
  if (!FB_OK) { L.innerHTML = '<p>Reviews will appear here once the shop is connected.</p>'; return; }
  loadReviews(id).then(function (a) {
    if (!$("#plist")) return;
    $("#plist").innerHTML = a.length ? a.map(function (r) { return rcard(r, false); }).join("") : '<div class="empty" style="grid-column:1/-1;padding:20px"><p>No reviews yet. Be the first to review this product.</p></div>';
    var rs = $("#rsum"); if (rs) rs.innerHTML = revSummary(a);
  }).catch(function () { if ($("#plist")) $("#plist").innerHTML = '<p>Reviews could not be loaded.</p>'; });
}
function sizeCards(p) { return p.variants.map(function (v, i) { return '<button class="chip sz' + (i ? "" : " on") + '" data-i="' + i + '" data-p="' + v.price + '" onclick="PH.pick(this)"><b>' + esc(v.size) + '</b><small>' + fmt(v.price) + '</small></button>'; }).join(""); }
function nextTwo(p) {
  var L = S.products, i = L.indexOf(p), out = [], k;
  if (i < 0) return L.slice(0, 2);
  for (k = 1; k < L.length && out.length < 2; k++) out.push(L[(i + k) % L.length]);
  return out;
}
function pProduct(id) {
  var p = getP(id);
  if (!p) return banner("Product not found") + '<div class="sec"><div class="empty"><div class="big">📦</div><p>This product is not available.</p><a class="btn" href="#/shop">Go to Shop</a></div></div>';
  var P = CONFIG.policy, w = S.wish.indexOf(p.id) > -1, more = nextTwo(p);
  var pts = p.details ? p.details.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean) : [];
  if (!pts.length) pts = ["Quality product from " + SH.name, "Available in " + p.variants.map(function (v) { return v.size; }).join(", "), "Cash on Delivery, JazzCash and EasyPaisa accepted", "Fast delivery across Pakistan"];
  S.hook = function () { drawProdReviews(id); if (S.user) checkBuyer(id); };
  S.rvform = '<form onsubmit="PH.review(event,\'' + p.id + '\')"><div id="rmsg"></div><div class="fld"><label>Your rating</label><div class="rate" id="rate">' + [1, 2, 3, 4, 5].map(function (n) { return '<button type="button" onclick="PH.rate(' + n + ')" aria-label="' + n + ' stars">★</button>'; }).join("") + '</div><input type="hidden" name="rating" value="0"/></div>' +
      '<div class="fld"><label>Your review</label><textarea name="text" rows="4" maxlength="600" required="required" placeholder="How was the product?"></textarea></div><div class="fld"><label>Add a product photo (optional)</label><input name="reviewPhoto" type="file" accept="image/*"/><small>One image, compressed before upload.</small></div><button class="btn" type="submit">Submit review</button><p class="fine" style="text-align:left">Your review appears after approval by our team.</p></form>';
  var form = S.user ? '<div id="rvbox"><p>Checking your orders...</p></div>' : '<p style="margin-bottom:14px">Please log in to write a review.</p><a class="btn" href="#/login" onclick="PH.rvlogin(\'' + p.id + '\')">Login to review</a>';
  return banner(esc(p.name), "Full product details") +
    '<section class="sec" style="padding-top:50px"><div class="wrap pd" data-pid="' + p.id + '"><div class="pimg">' + pimg(p, hueOf(p)) + (p.image2 ? '<img src="' + esc(p.image2) + '" alt="" style="margin-top:12px;border-radius:20px"/>' : "") + (p.video ? '<video class="pv" controls preload="metadata" src="' + esc(p.video) + '"></video>' : "") + '</div><div>' +
    (p.badge ? '<span class="st">' + esc(p.badge) + '</span>' : "") + '<h2 style="margin-top:10px">' + esc(p.name) + '</h2><div class="rsum" id="rsum"><span class="stars">☆☆☆☆☆</span> Loading reviews...</div>' +
    '<div class="price" data-price style="font-size:2rem;margin-top:10px">' + fmt(p.variants[0].price) + '</div>' + (p.ws ? '<div class="wsl" style="font-size:1.05rem">Wholesale price: ' + fmt(p.ws) + ' per piece (minimum ' + (p.wsMin || 10) + ' pcs)</div>' : "") + '<p class="d">' + esc(p.desc) + '</p>' +
    '<h4 style="margin-bottom:8px">Choose size</h4><div class="chips">' + sizeCards(p) + '</div>' +
    '<div class="row" style="margin:18px 0 18px"><div class="qty"><button onclick="PH.q(-1)" aria-label="Less">−</button><input data-qty value="1" readonly="readonly"/><button onclick="PH.q(1)" aria-label="More">+</button></div>' +
    (oos(p) ? '<button class="btn" disabled="disabled">Out of stock</button>' : '<button class="btn" onclick="PH.add(this)">Add to Cart</button><button class="btn dk" onclick="PH.buy(this)">Buy Now</button>') + (p.ws ? '<button class="btn" onclick="PH.bulk(this)">Bulk Order</button>' : "") + '<button class="btn ghost" onclick="PH.wish(\'' + p.id + '\',this)">' + (w ? "♥ In Wishlist" : "♡ Wishlist") + '</button></div>' +
    '<div class="note">Pay by Cash on Delivery, JazzCash or EasyPaisa. Delivery in ' + esc(P.deliveryTime) + '. Questions? WhatsApp ' + SH.phone + '.</div></div></div></section>' +
    '<section class="sec white" style="padding-top:70px"><div class="wrap"><div class="stitle"><h2>Product details</h2></div><div class="two"><div class="card"><h3 style="margin-bottom:10px">About this product</h3><p>' + esc(p.desc) + '</p>' +
    '<h3 style="margin:18px 0 8px">Highlights</h3><ul style="margin-left:22px">' + pts.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join("") + '</ul>' +
    '<h3 style="margin:18px 0 8px">Delivery</h3><p>We deliver across Pakistan. See the Delivery policy for time and charges.</p></div>' +
    '<div class="card"><h3 style="margin-bottom:10px">Product information</h3><table class="info"><tr><th>Product</th><td>' + esc(p.name) + '</td></tr><tr><th>Sizes and prices</th><td>' + p.variants.map(function (v) { return esc(v.size) + ": <b>" + fmt(v.price) + "</b>"; }).join("<br/>") + '</td></tr>' +
    '<tr><th>Payment</th><td>Cash on Delivery, JazzCash, EasyPaisa</td></tr><tr><th>Delivery</th><td>' + esc(P.deliveryTime) + '</td></tr><tr><th>Returns</th><td>Damaged or wrong item: report within ' + esc(P.returnWindow) + '. <a href="#/policies/returns" style="color:var(--amber);font-weight:700">Read policy</a></td></tr>' +
    '<tr><th>Support</th><td>Call or WhatsApp ' + SH.phone + ', open 24/7</td></tr></table></div></div></div></section>' +
    '<section class="sec dark" id="reviews"><div class="wrap" style="max-width:980px"><div class="stitle"><h2>Customer reviews</h2><p>What customers say about ' + esc(p.name) + '</p></div><div class="rgrid" id="plist"><p>Loading reviews...</p></div>' +
    '<div class="card" style="margin-top:30px"><h3 style="margin-bottom:12px">Write a review</h3>' + form + '</div></div></section>' +
    (more.length ? '<section class="sec"><div class="wrap"><div class="stitle"><h2>You may also like</h2><p>More Online Shah Alami products.</p></div><div class="grid2">' + more.map(function (x) { return pcard(x); }).join("") + '</div></div></section>' : "");
}
function defaultFaq() {
  var P = CONFIG.policy, c = Number((S.resellerSettings || {}).commissionPct == null ? CONFIG.commissionPct : S.resellerSettings.commissionPct);
  return [
    { id: "f1", q: "How do I place an order?", a: "Add products to your cart, press Proceed to checkout, log in or create a free account, enter your delivery details and choose a payment method.", faq: true, chat: true },
    { id: "f2", q: "Which payment methods do you accept?", a: "Cash on Delivery, JazzCash (" + SH.jazzcash + "), EasyPaisa (" + SH.easypaisa + ") and bank transfer. Account name: " + SH.accountName + ". For JazzCash, EasyPaisa and bank transfer, enter the Transaction ID at checkout. We ship after we verify the payment.", faq: true, chat: true },
    { id: "f3", q: "How long does delivery take?", a: "Usually " + P.deliveryTime + " after confirmation. Delivery charges are shown at checkout and depend on your city and the weight of your order.", faq: true, chat: true },
    { id: "f4", q: "Is delivery free?", a: "Yes, delivery is free on orders above " + fmt((S.delivery && S.delivery.freeAbove) || 5000) + ".", faq: true, chat: true },
    { id: "f5", q: "How can I track my order?", a: "Log in, open Account and enter your order number (it starts with AM-), or press Track next to the order in your list.", faq: true, chat: true },
    { id: "f6", q: "What if my item is damaged or wrong?", a: "Contact us within " + P.returnWindow + " of delivery with your order number and photos. See the Return & Refund policy for details.", faq: true, chat: false },
    { id: "f7", q: "How do I get wholesale prices?", a: "Create an account and choose Business (or request access from your Account page). After we approve your account, you can see wholesale prices and order in bulk. Each product has its own minimum quantity.", faq: true, chat: false },
    { id: "f8", q: "How does the reseller program work?", a: "Create an account and choose Reseller. After approval you can add your own products (they go live after admin approval) and earn " + c + "% commission on each delivered sale.", faq: true, chat: false },
    { id: "f9", q: "Can I use a discount code?", a: "Yes. Enter the code in the Discount code box on the order summary at checkout.", faq: true, chat: false },
    { id: "f10", q: "How do I contact you?", a: "Call or WhatsApp " + SH.phone + " any time (" + SH.hours + "), or email " + SH.email + ".", faq: true, chat: true }
  ];
}
function faqList() { return S.faqs ? S.faqs : defaultFaq(); }
function loadFaq() {
  if (!db) return Promise.resolve();
  return db.collection("settings").doc("faq").get().then(function (d) { S.faqs = d.exists && d.data().list ? d.data().list : null; }).catch(function () { S.faqs = null; });
}
function saveFaq(list) { return db.collection("settings").doc("faq").set({ list: list, updatedMs: Date.now() }).then(function () { S.faqs = list; S.cql = null; drawAdmin(); toast("Saved"); }).catch(function (x) { toast(x.message); }); }
function pFaq() {
  var Q = faqList().filter(function (f) { return f.faq !== false; });
  return banner("FAQs", "Quick answers to common questions") + '<section class="sec" style="padding-top:40px"><div class="wrap" style="max-width:860px">' +
    (Q.length ? Q.map(function (x, i) { return '<details class="card am-faq" style="margin-bottom:12px;padding:18px 22px;animation-delay:' + Math.min(i * 55, 440) + 'ms"><summary style="cursor:pointer;font-weight:700;color:var(--ink)">' + esc(x.q) + '</summary><p style="margin-top:10px;color:var(--text)">' + esc(x.a) + '</p></details>'; }).join("") : '<p>No questions yet.</p>') + '</div></section>';
}
function pAbout() {
  return banner("About Us", "The story behind Online Shah Alami") + '<section class="sec" style="padding-top:50px"><div class="wrap two"><div><h2 style="margin-bottom:16px">Everything you need, kept simple</h2>' +
    '<p style="margin-bottom:14px">Online Shah Alami is an online shopping and online wholesale store. Our idea is simple: bring quality products from every category to your door at fair prices.</p>' +
    '<p style="margin-bottom:14px">For every order we pack, we focus on honest quality, fair prices and fast, friendly service. You can order online at any hour, because we are open 24/7.</p>' +
    '<p>Pay the way that suits you: Cash on Delivery, JazzCash or EasyPaisa.</p><div class="btns" style="margin-top:26px"><a class="btn" href="#/shop">Shop now</a><a class="btn dk" href="#/contact">Contact us</a></div></div>' +
    '<div class="stage" style="padding:30px;background:var(--hex),linear-gradient(135deg,#EEF2F6,#DCE4EC);border-radius:30px"><div class="glow"></div><div class="tilt"><div class="floatw">' + jar(0) + '</div></div></div></div></section>' +
    '<section class="sec dark"><div class="wrap"><div class="feat"><div class="glass"><div class="ic">🌿</div><h3>Quality</h3><p>Products you can trust.</p></div><div class="glass"><div class="ic">🤝</div><h3>Trust</h3><p>Clear prices and honest service.</p></div><div class="glass"><div class="ic">🏷️</div><h3>Value</h3><p>Fair prices on every product.</p></div></div></div></section>';
}
function pContact() {
  return banner("Contact Us", "We are here 24/7") + '<section class="sec" style="padding-top:50px"><div class="wrap two"><div class="cinfo">' +
    '<a href="tel:' + SH.phone + '"><span class="i">📞</span><span><small>Phone</small><b>' + SH.phone + '</b></span></a>' +
    '<a href="https://wa.me/' + SH.whatsapp + '" target="_blank" rel="noopener"><span class="i">💬</span><span><small>WhatsApp</small><b>' + SH.phone + '</b></span></a>' +
    '<a href="mailto:' + SH.email + '"><span class="i">✉️</span><span><small>Email</small><b>' + SH.email + '</b></span></a>' +
    '<div class="ci"><span class="i">🕒</span><span><small>Working hours</small><b>Open 24/7</b></span></div></div>' +
    '<form class="card" onsubmit="PH.contact(event)"><h3 style="margin-bottom:16px">Send us a message</h3><div id="cmsg"></div>' +
    '<div class="g2"><div class="fld"><label>Your name</label><input name="name" required="required"/></div><div class="fld"><label>Phone</label><input name="phone"/></div></div>' +
    '<div class="fld"><label>Email <small style="color:var(--mut);font-weight:400">(needed only for the Email option)</small></label><input name="email" type="email"/></div><div class="fld"><label>Message</label><textarea name="message" rows="5" required="required"></textarea></div>' +
    '<p style="font-weight:600;margin:4px 0 10px">How do you want to contact us?</p><div class="row" style="gap:10px;flex-wrap:wrap"><button class="btn" type="submit" style="flex:1;min-width:160px">✉️ Send by Email</button><button class="btn" type="button" onclick="PH.contactWA(this.form)" style="flex:1;min-width:160px;background:#25d366;color:#fff;border-color:#25d366">💬 Send on WhatsApp</button></div></form></div></section>';
}
function thumb(p) { return p.image ? '<img src="' + esc(p.image) + '" alt="' + esc(p.name) + '"/>' : '<div class="ptile" style="min-height:0;font-size:2.4rem;background:transparent">' + ((CONFIG.catEmoji || {})[p.cat] || "📦") + '</div>'; }
function pCart() {
  var L = lines(), t = totals();
  if (!L.length) return banner("Your Cart") + '<section class="sec"><div class="empty"><div class="big">🛒</div><h3>Your cart is empty</h3><p style="margin:8px 0 20px">Add a product to get started.</p><a class="btn" href="#/shop">Go to Shop</a></div></section>';
  return banner("Your Cart", cartCount() + " item(s)") + '<section class="sec" style="padding-top:50px"><div class="wrap cart"><div class="card">' +
    L.map(function (l) { return '<div class="line"><div class="th">' + thumb(l.p) + '</div><div><h4>' + esc(l.p.name) + '</h4><small>' + esc(l.size) + ' · ' + fmt(l.price) + '</small><br/><button class="rm" onclick="PH.rm(\'' + l.p.id + '\',' + l.p.variants.indexOf(l.v) + ')">Remove</button></div>' +
      '<div class="row"><div class="qty"><button onclick="PH.cq(\'' + l.p.id + '\',' + l.p.variants.indexOf(l.v) + ',-1)">−</button><input value="' + l.qty + '" readonly="readonly"/><button onclick="PH.cq(\'' + l.p.id + '\',' + l.p.variants.indexOf(l.v) + ',1)">+</button></div><b>' + fmt(l.price * l.qty) + '</b></div></div>'; }).join("") +
    '</div><div class="card sum"><h3 style="margin-bottom:10px">Order summary</h3><div><span>Subtotal</span><b>' + fmt(t.sub) + '</b></div><div><span>Delivery</span><b>' + (t.del ? fmt(t.del) : "Free") + '</b></div><div class="tot"><span>Total</span><span>' + fmt(t.total) + '</span></div>' +
    deliveryHint(t.sub) + '<a class="btn" style="width:100%;margin-top:14px" href="#/checkout">Proceed to checkout</a><a class="btn dk" style="width:100%;margin-top:10px" href="#/shop">Continue shopping</a></div></div></section>';
}
function pCheckout() {
  S.city = (S.profile && S.profile.city) || "";
  var L = lines(), t = totals();
  if (!L.length) { location.hash = "#/cart"; return ""; }
  if (!S.user || S.user.isAnonymous) {
    S.redirect = "checkout";
    if (S.user && S.user.isAnonymous && auth) auth.signOut().catch(function () {});
    location.hash = "#/login";
    return banner("Login / Register", "Sign in or create an account before checkout") + '<section class="sec"><div class="wrap" style="max-width:620px"><div class="card" style="text-align:center"><h3>Login or create an account to continue</h3><p style="margin:12px 0 18px;color:var(--mut)">Your cart will be saved. After signing in, you will return to checkout.</p><div class="row" style="justify-content:center;gap:10px;flex-wrap:wrap"><a class="btn" href="#/login" onclick="PH.atab(&quot;login&quot;)">Login</a><a class="btn dk" href="#/login" onclick="PH.atab(&quot;register&quot;)">Create account / Sign up</a></div></div></div></section>';
  }
  var pr = S.profile || {};
  S.hook = payUI;
  return banner("Checkout", "Delivery details and payment") + '<section class="sec" style="padding-top:50px"><div class="wrap cart"><form class="card" onsubmit="PH.place(event)" id="chk"><div id="cmsg"></div><h3 style="margin-bottom:16px">Delivery details</h3>' +
    '<div class="g2"><div class="fld"><label>Full name</label><input name="name" required="required" value="' + esc(pr.name || (S.user && S.user.displayName) || "") + '"/></div><div class="fld"><label>Phone / WhatsApp</label><input name="phone" required="required" placeholder="03XXXXXXXXX" value="' + esc(pr.phone || "") + '"/></div></div>' +
    '<div class="g2"><div class="fld"><label>Email</label><input name="email" type="email" required="required" value="' + esc((S.user && S.user.email) || "") + '"/></div><div class="fld"><label>City</label><input name="city" required="required" list="pkcities" autocomplete="off" value="' + esc(pr.city || "") + '" oninput="PH.setCity(this.value)"/><datalist id="pkcities">' + PK_CITIES.map(function (c) { return '<option value="' + c + '"></option>'; }).join("") + '</datalist></div></div>' +
    '<div class="fld"><label>Full address</label><textarea name="address" rows="3" required="required">' + esc(pr.address || "") + '</textarea></div><div class="fld"><label>Order notes (optional)</label><input name="notes"/></div>' +
    '<h3 style="margin:8px 0 12px">Payment method</h3><div class="pay"><label><input type="radio" name="pay" value="Cash on Delivery" checked="checked" onchange="PH.payUI()"/>Cash on Delivery</label>' +
    '<label><input type="radio" name="pay" value="JazzCash" onchange="PH.payUI()"/>JazzCash</label><label><input type="radio" name="pay" value="EasyPaisa" onchange="PH.payUI()"/>EasyPaisa</label><label><input type="radio" name="pay" value="Bank Account" onchange="PH.payUI()"/>Bank Account</label></div>' +
    '<div id="payinfo"></div><p style="font-size:.88rem;color:var(--mut);margin-bottom:12px">By placing your order you agree to our <a href="#/policies/delivery" style="color:var(--amber);font-weight:700">Delivery</a>, <a href="#/policies/returns" style="color:var(--amber);font-weight:700">Return</a> and <a href="#/policies/privacy" style="color:var(--amber);font-weight:700">Privacy</a> policies and <a href="#/policies/terms" style="color:var(--amber);font-weight:700">Terms</a>.</p><button class="btn" type="submit" id="pbtn" style="width:100%">Place order · ' + fmt(t.total) + '</button></form>' +
    '<div class="card sum" id="sumcard">' + sumHTML() + '</div></div></section>';
}
function payUI() {
  var f = $("#chk"), box = $("#payinfo"); if (!f || !box) return;
  var m = f.pay.value;
  if (m === "Cash on Delivery") { box.innerHTML = '<div class="note">Pay in cash when your order arrives. Cash on Delivery fee: <b>Rs. 80</b>.</div>'; refreshSum(); return; }
  var num = m === "JazzCash" ? SH.jazzcash : m === "EasyPaisa" ? SH.easypaisa : "(Account No " + SH.bankNo + ")";
  box.innerHTML = '<div class="note">Send <b id="payamt">' + fmt(totals().total) + '</b> to <b>' + m + ' ' + num + '</b><br/>Account name: <b>' + esc(SH.accountName) + '</b><br/>Then enter the Transaction ID below and attach a screenshot.</div>' +
    '<div class="fld"><label>Transaction ID</label><input name="txn" required="required"/></div><div class="fld"><label>Payment screenshot (optional)</label><input name="shot" type="file" accept="image/*"/></div>'; refreshSum();
}
function pSuccess() {
  var o = S.last; if (!o) return banner("Order") + '<section class="sec"><div class="empty"><p>No recent order found.</p><a class="btn" href="#/account">My orders</a></div></section>';
  var itemHTML = (o.items || []).map(function (i) { var p = getP(i.pid), image = i.image || (p && p.image) || "", im = image ? '<img src="' + esc(image) + '" alt="' + esc(i.name) + '" style="width:84px;height:84px;flex:0 0 84px;object-fit:cover;border-radius:12px;background:#f1faf4;border:1px solid var(--line)"/>' : '<span style="width:84px;height:84px;flex:0 0 84px;display:grid;place-items:center;border-radius:12px;background:#f1faf4;font-size:1.8rem">📦</span>'; return '<div style="display:flex;gap:14px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line);text-align:left">' + im + '<div style="flex:1;min-width:0"><b>' + esc(i.name) + '</b><div style="color:var(--mut);font-size:.9rem">' + esc(i.size) + ' × ' + i.qty + '</div></div><b>' + fmt(i.price * i.qty) + '</b></div>'; }).join("");
  return '<section class="sec first"><div class="wrap" style="max-width:700px"><div class="card" style="text-align:center"><div style="font-size:3.5rem">🎉</div><h2>Thank you, ' + esc(o.customer.name) + '!</h2><p style="margin:10px 0">Your order has been placed.</p>' +
    '<div class="note" style="text-align:left">Order No: <b>' + o.orderNo + '</b><br/>Subtotal: <b>' + fmt(o.subtotal || 0) + '</b><br/>Delivery: <b>' + fmt(o.delivery || 0) + '</b><br/>Total: <b>' + fmt(o.total) + '</b><br/>Payment: <b>' + esc(o.paymentMethod) + '</b><br/>A confirmation has been emailed to ' + esc(o.customer.email) + '.</div>' +
    '<h3 style="text-align:left;margin-top:20px">Items in your order</h3><div>' + itemHTML + '</div><div class="btns" style="justify-content:center;margin-top:20px"><a class="btn" href="#/shop">Explore More Items</a><a class="btn dk" href="#/account">Track my order</a></div></div></div></section>';
}
function pWish() {
  var a = S.wish.map(getP).filter(Boolean);
  if (!a.length) return banner("Wishlist") + '<section class="sec"><div class="empty"><div class="big">♡</div><h3>Your wishlist is empty</h3><p style="margin:8px 0 20px">Tap the heart on any product to save it.</p><a class="btn" href="#/shop">Browse products</a></div></section>';
  return banner("Wishlist", a.length + " saved") + '<section class="sec" style="padding-top:50px"><div class="wrap"><div class="bar"><p style="color:var(--mut)">Tap ✕ Remove to cancel a product from your wishlist.</p><button class="btn red sm" onclick="PH.clearWish()">Clear wishlist</button></div><div class="grid">' + a.map(function (p) { return pcard(p, true); }).join("") + '</div></div></section>';
}
function pReset() {
  return banner("Reset Password", "Enter the code from your email") + '<section class="sec" style="padding-top:50px"><div class="wrap" style="max-width:520px"><form class="card" onsubmit="PH.doReset(event)"><div id="cmsg"></div>' +
    '<p style="color:var(--mut);margin-bottom:14px">Open the reset email we sent you. Press and hold (or right-click) the <b>reset link</b>, choose <b>Copy link address</b>, and paste it below. The secret code is already inside the link, so you do not need to find it yourself.</p>' +
    '<div class="fld"><label>Paste the reset link from your email</label><input name="code" required="required" autocomplete="off"/></div><div class="fld"><label>New password</label><input name="pw" type="password" minlength="6" required="required"/></div><div class="fld"><label>Confirm new password</label><input name="pw2" type="password" minlength="6" required="required"/></div>' +
    '<button class="btn" style="width:100%" type="submit">Change password</button><p style="text-align:center;margin-top:14px"><a href="#/login" style="color:var(--amber);font-weight:600">Back to login</a></p></form></div></section>';
}
function pLogin() {
  if (S.user) { var rd = S.redirect; S.redirect = null; location.hash = rd ? "#/" + rd : (S.isAdmin ? "#/admin" : "#/account"); return ""; }
  var reg = S.authTab === "register";
  return banner("Login / Register", "Save your orders and check out faster") + '<section class="sec" style="padding-top:50px"><div class="wrap" style="max-width:520px"><div class="tabs"><button class="' + (reg ? "" : "on") + '" onclick="PH.atab(\'login\')">Login</button><button class="' + (reg ? "on" : "") + '" onclick="PH.atab(\'register\')">Create account</button></div>' +
    '<form class="card" onsubmit="PH.' + (reg ? "register" : "login") + '(event)"><div id="cmsg"></div>' +
    (reg ? '<div class="fld"><label>Account type</label><select name="atype" class="inp"><option value="customer">Customer (retail)</option><option value="business">Business (request wholesale access)</option><option value="reseller">Reseller (request approval)</option></select></div><div class="fld"><label>Full name</label><input name="name" required="required"/></div><div class="fld"><label>Phone</label><input name="phone" required="required"/></div>' : "") +
    '<div class="fld"><label>Email</label><input name="email" type="email" required="required"/></div><div class="fld"><label>Password</label><input name="password" type="password" minlength="6" required="required"/></div>' +
    '<button class="btn" style="width:100%" type="submit">' + (reg ? "Create account" : "Login") + '</button>' + (reg ? "" : '<p style="text-align:center;margin-top:14px"><a href="#/login" onclick="PH.forgot(event)" style="color:var(--amber);font-weight:600">Forgot password?</a><br/><a href="#/reset" style="color:var(--mut);font-size:.9rem">Already have a reset code? Enter it here</a></p>') + '</form></div></section>';
}
function loadMyOrders() {
  if (!FB_OK || !S.user) return Promise.resolve([]);
  return db.collection("orders").where("userId", "==", S.user.uid).get().then(function (s) { var a = []; s.forEach(function (d) { var o = d.data(); o.id = d.id; a.push(o); }); a.sort(function (x, y) { return y.createdMs - x.createdMs; }); S.myo = a; return a; });
}
function rlink(id) { return location.href.split("#")[0] + "#/product/" + id; }
function pAccount() {
  if (!S.user || S.user.isAnonymous) { location.hash = "#/login"; return ""; }
  S.hook = drawAccount;
  var pr = S.profile || {}, bd = '<span class="st">Customer</span>' + (pr.wholesale ? ' <span class="st">Wholesale</span>' : "") + (pr.type === "reseller" ? ' <span class="st">Reseller</span>' : "") + (S.isAdmin ? ' <span class="st">Admin</span>' : "");
  return banner("My Account", esc(S.user.displayName || S.user.email)) + '<section class="sec" style="padding-top:40px"><div class="wrap"><div class="card" style="margin-bottom:20px"><div class="bar" style="margin:0"><div><h3>' + esc(pr.name || S.user.displayName || "Customer") + ' ' + bd + '</h3><p style="color:var(--mut)">' + esc(S.user.email || "") + (pr.phone ? " · " + esc(pr.phone) : "") + '</p></div><div class="row">' + (S.isAdmin ? '<a class="btn dk sm" href="#/admin">Admin Panel</a>' : "") + '<button class="btn red sm" onclick="PH.logout()">Logout</button></div></div></div><div class="tabs" id="atabs2"></div><div id="acc"></div></div></section>';
}
function accTabs() {
  var t = [["profile", "👤 Profile"], ["orders", "📦 My orders"], ["track", "📍 Track order"]];
  if (!S.isAdmin) t.push(["wholesale", "🏭 Wholesale"], ["reseller", "🤝 Reseller"]);
  t.push(["help", "💬 Help"]); return t;
}
function drawAccount() {
  var tb = $("#atabs2"); if (!tb) return; var T = accTabs(), cur = S.accTab || "profile";
  if (!T.some(function (x) { return x[0] === cur; })) cur = S.accTab = "profile";
  tb.innerHTML = T.map(function (x) { return '<button class="' + (x[0] === cur ? "on" : "") + '" onclick="PH.accTab(\'' + x[0] + '\')">' + x[1] + '</button>'; }).join("");
  ({ profile: tabProfile, orders: tabOrders, track: tabTrack, wholesale: drawWholesale, reseller: drawReseller, help: tabHelp })[cur]();
}
function tabProfile() {
  var b = $("#acc"), pr = S.profile || {};
  b.innerHTML = '<div class="stat-grid" id="pstat"><div class="stat"><b>…</b>Orders</div><div class="stat"><b>…</b>Total spent</div><div class="stat"><b>' + S.wish.length + '</b>Wishlist</div><div class="stat"><b>' + cartCount() + '</b>In cart</div></div>' +
    '<div class="two"><form class="card" onsubmit="PH.profSave(event)"><h3 style="margin-bottom:12px">Personal details</h3><div id="pfmsg"></div><div class="fld"><label>Full name</label><input name="name" required="required" value="' + esc(pr.name || (S.user && S.user.displayName) || "") + '"/></div><div class="fld"><label>Phone / WhatsApp</label><input name="phone" required="required" value="' + esc(pr.phone || "") + '"/></div><div class="fld"><label>City</label><input name="city" list="pkc2" autocomplete="off" value="' + esc(pr.city || "") + '"/><datalist id="pkc2">' + PK_CITIES.map(function (c) { return '<option value="' + c + '"></option>'; }).join("") + '</datalist></div><div class="fld"><label>Delivery address</label><textarea name="address" rows="3">' + esc(pr.address || "") + '</textarea></div><button class="btn" type="submit">Save changes</button><p class="fine" style="text-align:left">Your city and address are filled in automatically at checkout.</p></form>' +
    '<div><div class="card" style="margin-bottom:16px"><h3 style="margin-bottom:10px">Account</h3><table class="info"><tr><th>Email</th><td>' + esc(S.user.email || "") + '</td></tr><tr><th>Member since</th><td>' + (pr.createdMs ? new Date(pr.createdMs).toLocaleDateString() : "-") + '</td></tr><tr><th>Account type</th><td>' + [pr.type === "reseller" ? "Reseller" : "", pr.wholesale ? "Wholesale" : "", "Customer"].filter(Boolean).join(" + ") + '</td></tr></table><button class="btn dk sm" style="margin-top:14px" onclick="PH.pwReset()">Send password reset email</button></div>' +
    '<div class="card"><h3 style="margin-bottom:10px">Quick links</h3><div class="row" style="gap:8px;flex-wrap:wrap"><a class="btn dk sm" href="#/wishlist">♡ Wishlist</a><a class="btn dk sm" href="#/cart">🛒 Cart</a><a class="btn dk sm" href="#/policies">Policies</a><a class="btn dk sm" target="_blank" rel="noopener" href="https://wa.me/' + SH.whatsapp + '">WhatsApp</a></div></div></div></div>';
  loadMyOrders().then(function (a) { var s = $("#pstat"); if (!s) return; var n = 0, tot = 0; a.forEach(function (o) { if (o.status !== "Cancelled") { n++; tot += o.total || 0; } }); s.children[0].innerHTML = '<b>' + n + '</b>Orders'; s.children[1].innerHTML = '<b>' + fmt(tot) + '</b>Total spent'; }).catch(function () {});
}
function tabOrders() {
  var b = $("#acc"), st = ["all", "Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
  b.innerHTML = '<div class="bar"><h3>My orders</h3><select class="inp" style="max-width:200px" onchange="PH.ofil(this.value)">' + st.map(function (s) { return '<option value="' + s + '"' + ((S.of || "all") === s ? " selected" : "") + '>' + (s === "all" ? "All orders" : s) + '</option>'; }).join("") + '</select></div><div id="myo"><p>Loading...</p></div>';
  loadMyOrders().then(drawOrdersList).catch(function (e) { if ($("#myo")) $("#myo").innerHTML = '<p class="msg err">Could not load orders: ' + esc(e.message) + '</p>'; });
}
function drawOrdersList() {
  var m = $("#myo"); if (!m) return; var a = (S.myo || []).filter(function (o) { return !S.of || S.of === "all" || o.status === S.of; });
  m.innerHTML = a.length ? '<div class="tw"><table><tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>' + a.map(function (o) {
    return '<tr><td><b>' + o.orderNo + '</b></td><td>' + new Date(o.createdMs).toLocaleDateString() + '</td><td>' + o.items.map(function (i) { return esc(i.name) + " (" + esc(i.size) + ") × " + i.qty; }).join("<br/>") + '</td><td>' + fmt(o.total) + '</td><td>' + esc(o.paymentMethod) + '</td><td><span class="st">' + esc(o.status) + '</span></td><td class="row"><button class="btn dk sm" onclick="PH.track(\'' + o.id + '\')">Track</button><button class="btn sm" onclick="PH.reorder(\'' + o.id + '\')">Order again</button></td></tr>'; }).join("") + '</table></div>'
    : '<div class="empty"><div class="big">📦</div><p>No orders here.</p><a class="btn" href="#/shop">Start shopping</a></div>';
}
function tabTrack() {
  $("#acc").innerHTML = '<div class="card"><h3>📍 Track your order</h3><p style="color:var(--mut);margin:6px 0 14px">Enter your order number (like AM-ABC123) to see where your order is.</p><form style="display:flex;gap:10px;flex-wrap:wrap" onsubmit="PH.trackForm(event)"><input class="inp" name="no" placeholder="Order number e.g. AM-LK4F2A" required="required" style="max-width:320px"/><button class="btn" type="submit">Track order</button></form><div id="tmsg"></div></div>';
}
function tabHelp() {
  $("#acc").innerHTML = '<div class="two"><div class="card"><h3 style="margin-bottom:10px">Need help?</h3><p style="color:var(--mut);margin-bottom:12px">We are here ' + esc(SH.hours) + '.</p><div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn sm" onclick="PH.chatTog()">💬 Open live chat</button><a class="btn dk sm" target="_blank" rel="noopener" href="https://wa.me/' + SH.whatsapp + '">WhatsApp</a><a class="btn dk sm" href="tel:' + SH.phone + '">📞 Call ' + SH.phone + '</a></div></div><div class="card"><h3 style="margin-bottom:10px">Useful pages</h3><div class="row" style="gap:8px;flex-wrap:wrap"><a class="btn dk sm" href="#/faq">FAQs</a><a class="btn dk sm" href="#/policies/delivery">Delivery</a><a class="btn dk sm" href="#/policies/returns">Returns</a><a class="btn dk sm" href="#/contact">Contact us</a></div></div></div>';
}

/* ---------- benefits, 3D bits, admin check ---------- */
var BEN = [
  ["🚚", "Fast delivery", "Orders delivered across Pakistan in a few working days."],
  ["💳", "Easy payment", "Cash on Delivery, JazzCash or EasyPaisa."],
  ["🏷️", "Fair prices", "Clear prices and regular discount codes."],
  ["🔄", "Easy returns", "Report a damaged or wrong item and we will fix it."],
  ["💬", "WhatsApp support", "Message us any time to confirm or change your order."],
  ["⭐", "Real reviews", "Read honest reviews from other customers."]
];
var HX = '<i class="hx" style="top:2%;left:-6%;--s:46px;--z:70px;--r:-8deg;--t:5.5s"></i><i class="hx" style="top:14%;right:-12%;--s:34px;--z:110px;--r:12deg;--t:7s"></i>' +
  '<i class="hx" style="top:58%;left:-22%;--s:26px;--z:40px;--r:20deg;--t:6s"></i><i class="hx" style="top:70%;right:-20%;--s:52px;--z:-60px;--r:-14deg;--t:8s"></i><i class="hx" style="top:-6%;left:48%;--s:24px;--z:90px;--r:6deg;--t:6.5s"></i>';
function isAdminEmail(e) { return CONFIG.adminEmails.map(function (x) { return x.toLowerCase(); }).indexOf(String(e || "").toLowerCase()) > -1; }

/* ---------- policies ---------- */
function polBody(k) {
  var P = CONFIG.policy, fee = Number(CONFIG.deliveryFee) || 0, feeTxt = fee ? "A delivery charge of " + fmt(fee) + " applies to each order." : "Delivery is free on all orders.";
  var u = '<p class="upd">Last updated: ' + P.updated + '</p>';
  if (k === "returns") return '<h2>Return &amp; Refund Policy</h2>' + u +
    '<h3>Our promise</h3><p>We want you to be happy with your purchase. For hygiene and safety, we cannot take back used or opened personal-care or food items unless they are faulty.</p>' +
    '<h3>When you can get a replacement or refund</h3><ul><li>The item arrived damaged or faulty.</li><li>You received a different product or size than you ordered.</li><li>The parcel was already opened when it arrived.</li></ul>' +
    '<h3>How to make a request</h3><ol><li>Contact us within <b>' + P.returnWindow + '</b> of delivery on WhatsApp ' + SH.phone + ' or email ' + SH.email + '.</li><li>Send your order number and clear photos or a short video of the parcel and the product.</li><li>We review your request and reply as soon as possible.</li></ol>' +
    '<h3>Refunds and replacements</h3><p>If your request is approved, we send a replacement or refund you. Refunds go to your JazzCash or EasyPaisa account, and are normally processed within <b>' + P.refundTime + '</b>.</p>' +
    '<h3>Cancelling an order</h3><p>You can cancel an order before it is shipped by calling or messaging us on WhatsApp. Once an order is shipped, it cannot be cancelled.</p>' +
    '<h3>What is not covered</h3><ul><li>Used items with no defect.</li><li>Damage that happens after delivery.</li></ul>';
  if (k === "privacy") return '<h2>Privacy Policy</h2>' + u +
    '<p>Online Shah Alami respects your privacy. This page explains what we collect and how we use it.</p>' +
    '<h3>What we collect</h3><ul><li>Account details: your name, email and phone number. Your password is handled by Firebase Authentication and we cannot see it.</li><li>Order details: delivery address, items, payment method, transaction ID, and the payment screenshot if you upload one.</li><li>Messages you send through the Contact form.</li><li>Reviews you write (your name, rating and comment). They are shown publicly only after we approve them.</li><li>Your cart and wishlist, which are saved in your own browser (local storage).</li></ul>' +
    '<h3>How we use your information</h3><ul><li>To process, deliver and support your orders.</li><li>To contact you about your order by phone, WhatsApp or email.</li><li>To reply to your messages.</li></ul>' +
    '<h3>Who handles your data</h3><p>We use Google Firebase to run logins and store data, EmailJS to send emails, and delivery partners to deliver your parcel. We share only what is needed to do this. We never sell your personal data.</p>' +
    '<h3>Security</h3><p>Data is stored in a secured database, and only you and the shop owner can see your orders. No online system is completely risk-free, but we work to protect your information.</p>' +
    '<h3>Your choices</h3><p>You can ask us to show, correct or delete your information at any time by emailing ' + SH.email + ' or messaging ' + SH.phone + '.</p>' +
    '<h3>Changes</h3><p>We may update this policy. The date at the top shows the latest version.</p>';
  if (k === "terms") return '<h2>Terms &amp; Conditions</h2>' + u +
    '<h3>Using this website</h3><p>By using this website or placing an order, you agree to these terms and to our Delivery, Return and Privacy policies.</p>' +
    '<h3>Products and prices</h3><p>All prices are in Pakistani Rupees (PKR). Product photos are for illustration, and colour or packaging may look slightly different. We may change prices or stock at any time. The price shown when you place your order is the price you pay.</p>' +
    '<h3>Orders</h3><p>An order is accepted when we confirm it. We may cancel an order if an item is out of stock, the details are wrong or fraud is suspected. If you already paid, we refund the amount.</p>' +
    '<h3>Payments</h3><p>We accept Cash on Delivery, JazzCash and EasyPaisa. Payments sent by JazzCash or EasyPaisa must be genuine, and you must enter the correct Transaction ID. Orders with false payment details may be cancelled.</p>' +
    '<h3>Your account</h3><p>Keep your password safe. You are responsible for activity on your account.</p>' +
    '<h3>Product use</h3><p>Please read product labels and instructions before use. For food, cosmetic and health items, check the ingredients and ask a doctor if you have allergies.</p>' +
    '<h3>Our responsibility</h3><p>To the extent allowed by law, our responsibility for any order is limited to the value of that order.</p>' +
    '<h3>Governing law</h3><p>These terms follow the laws of Pakistan.</p>' +
    '<h3>Contact</h3><p>Questions? Call or WhatsApp ' + SH.phone + ' or email ' + SH.email + '.</p>';
  return '<h2>Delivery Policy</h2>' + u +
    '<h3>Where we deliver</h3><p>We deliver Online Shah Alami orders to addresses across Pakistan. If you are not sure about your area, call or WhatsApp us on ' + SH.phone + ' before ordering.</p>' +
    '<h3>Order confirmation</h3><p>You can order 24/7. After you order, we confirm it by phone, WhatsApp or email. Please enter a correct phone number and full address at checkout.</p>' +
    '<h3>Delivery time</h3><p>Orders are usually delivered within <b>' + P.deliveryTime + '</b> after confirmation. Weather, public holidays or courier problems can cause delays, and we will keep you updated.</p>' +
    '<h3>Delivery charges</h3><p>' + feeTxt + '</p>' +
    '<h3>Payment</h3><ul><li><b>Cash on Delivery:</b> pay the rider when your parcel arrives.</li><li><b>JazzCash / EasyPaisa:</b> send the payment to ' + esc(SH.accountName) + ' on ' + SH.jazzcash + ' (JazzCash) or ' + SH.easypaisa + ' (EasyPaisa), then enter the Transaction ID at checkout. We ship after the payment is verified.</li></ul>' +
    '<h3>Tracking your order</h3><p>Log in and open Account to see your order status: Pending, Confirmed, Shipped or Delivered. We also email you when the status changes.</p>' +
    '<h3>When your parcel arrives</h3><p>Please check the parcel. If the item is damaged, broken or opened, contact us within <b>' + P.returnWindow + '</b>. See our Return &amp; Refund Policy.</p>';
}
function pPolicies(k) {
  var keys = ["delivery", "returns", "privacy", "terms"], names = ["Delivery Policy", "Return & Refund", "Privacy Policy", "Terms & Conditions"];
  if (keys.indexOf(k) < 0) k = "delivery";
  return banner("Policies", "Delivery, returns, privacy and terms") + '<section class="sec" style="padding-top:40px"><div class="wrap" style="max-width:860px"><div class="tabs">' +
    keys.map(function (x, i) { return '<button class="' + (x === k ? "on" : "") + '" onclick="location.hash=\'#/policies/' + x + '\'">' + esc(names[i]) + '</button>'; }).join("") +
    '</div><div class="card policy">' + polBody(k) + '</div></div></section>';
}

/* ---------- admin ---------- */
function pAdminLogin() {
  if (S.isAdmin) { location.hash = "#/admin"; return ""; }
  return banner("Admin Login", "Authorized staff only") + '<section class="sec" style="padding-top:50px"><div class="wrap" style="max-width:480px"><form class="card" onsubmit="PH.adminLogin(event)"><div id="cmsg">' +
    (S.user ? '<div class="msg err">You are logged in as ' + esc(S.user.email || "") + ', which is not an admin email.</div>' : "") + '</div><div class="fld"><label>Admin email</label><input name="email" type="email" required="required"/></div>' +
    '<div class="fld"><label>Password</label><input name="password" type="password" required="required"/></div><button class="btn dk" style="width:100%" type="submit">Login to Admin Panel</button><p style="text-align:center;margin-top:14px"><a href="#/admin-login" onclick="PH.forgot(event)" style="color:var(--amber);font-weight:600">Forgot password?</a></p></form></div></section>';
}
function pAdmin() {
  if (!S.isAdmin && auth && auth.currentUser && isAdminEmail(auth.currentUser.email)) { S.user = auth.currentUser; S.isAdmin = true; }
  if (!S.isAdmin) { if (!S.user) S.redirect = "admin"; location.hash = S.user ? "#/account" : "#/login"; return ""; }
  S.hook = function () { if (S.adm.loaded) drawAdmin(); else loadAdmin(); };
  var tabs = [["dashboard", "Dashboard"], ["revenue", "Revenue"], ["products", "Products"], ["categories", "Categories"], ["orders", "Orders"], ["discounts", "Discounts"], ["delivery", "Delivery"], ["site", "Site"], ["resellerSettings", "Reseller Rules & Profit"], ["pages", "Pages"], ["chat", "Chat"], ["faq", "FAQ & Chat Questions"], ["customers", "Customers"], ["messages", "Messages"], ["reviews", "Reviews"], ["payouts", "Payouts"]];
  return banner("Admin Panel", esc(S.user.email || "")) + '<section class="sec" style="padding-top:40px"><div class="wrap"><div class="tabs" id="atabs">' +
    tabs.map(function (t) { return '<button class="' + (S.tab === t[0] ? "on" : "") + '" onclick="PH.tab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join("") + '<button onclick="PH.refresh()">⟳ Refresh</button><button onclick="PH.logout()">Logout</button></div><div id="adm"><p>Loading...</p></div></div></section>';
}
function snap(q) { return q.get().then(function (s) { var a = []; s.forEach(function (d) { var o = d.data(); o.id = d.id; a.push(o); }); return a; }); }
function loadAdmin() {
  if (!FB_OK) { $("#adm").innerHTML = '<div class="msg err">Firebase is not configured. Add your keys in the CONFIG block.</div>'; return; }
  Promise.all([loadProducts(), snap(db.collection("orders")), snap(db.collection("messages")), snap(db.collection("users")), snap(db.collection("reviews")), snap(db.collection("coupons")).catch(function () { return []; }), db.collection("settings").doc("reseller").get().then(function(d){return d.exists?d.data():null;}).catch(function(){return null;})]).then(function (r) {
    S.adm.coupons = r[5].sort(function (a, b) { return (b.createdMs || 0) - (a.createdMs || 0); });
    if (r[6]) { S.resellerSettings = r[6]; S.resellerSettingsLoaded = true; CONFIG.commissionPct = Number(r[6].commissionPct == null ? CONFIG.commissionPct : r[6].commissionPct); }
    S.adm.orders = r[1].sort(function (a, b) { return b.createdMs - a.createdMs; });
    S.adm.messages = r[2].sort(function (a, b) { return b.createdMs - a.createdMs; });
    S.adm.reviews = r[4].sort(function (a, b) { return (a.approved === b.approved ? 0 : a.approved ? 1 : -1) || b.createdMs - a.createdMs; });
    S.adm.users = r[3].sort(function (a, b) { return (b.createdMs || 0) - (a.createdMs || 0); });
    S.adm.loaded = true; drawAdmin();
  }).catch(function (e) { if ($("#adm")) $("#adm").innerHTML = '<div class="msg err">Could not load data: ' + esc(e.message) + '<br/>Check that your Firestore rules are published and your email is in adminEmails.</div>'; });
}
/* ---------- message replies + buyer-only reviews ---------- */
function sendReply(m, text) {
  var T = CONFIG.emailjs.replyTemplateId || CONFIG.emailjs.messageTemplateId;
  if (!EJ_OK || !T || T.indexOf("YOUR_") === 0) return Promise.reject(new Error("Reply email is not set up yet. Add messageTemplateId in the CONFIG block, or use the WhatsApp button."));
  return emailjs.send(CONFIG.emailjs.serviceId, T, { to_email: m.email, email: m.email, to_name: m.name, customer_name: m.name, subject: "Reply from " + SH.name, message: text, reply_message: text, original_message: m.message, reply_to: SH.email, shop_name: SH.name, shop_phone: SH.phone, shop_email: SH.email });
}
function checkBuyer(pid) {
  var box = $("#rvbox"); if (!box) return;
  if (!FB_OK) { box.innerHTML = ""; return; }
  db.collection("orders").where("userId", "==", S.user.uid).get().then(function (s) {
    var ok = false;
    s.forEach(function (d) { var o = d.data(); if (o.status === "Cancelled") return; if (CONFIG.reviewNeedsDelivery && o.status !== "Delivered") return; (o.items || []).forEach(function (i) { if (i.pid === pid) ok = true; }); });
    var b = $("#rvbox"); if (!b) return;
    b.innerHTML = ok ? S.rvform : '<div class="note" style="margin:0">🔒 Only customers who bought this product can write a review.' + (CONFIG.reviewNeedsDelivery ? " You can review it after your order is delivered." : "") + '</div><a class="btn" style="margin-top:12px" href="#/shop">Shop now</a>';
  }).catch(function (x) { var b = $("#rvbox"); if (b) b.innerHTML = '<div class="msg err">' + esc(nice(x)) + '</div>'; });
}
/* ---------- revenue + order tracking ---------- */
function revenueHTML(orders) {
  var now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime(), wk = now.getTime() - 7 * 864e5, m0 = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  var R = { all: 0, got: 0, wait: 0, canc: 0, today: 0, week: 0, month: 0, n: 0 }, pay = {}, mon = {};
  orders.forEach(function (o) {
    var v = Number(o.total) || 0;
    if (o.status === "Cancelled") { R.canc += v; return; }
    R.all += v; R.n++;
    if (o.status === "Delivered") R.got += v; else R.wait += v;
    if (o.createdMs >= t0) R.today += v; if (o.createdMs >= wk) R.week += v; if (o.createdMs >= m0) R.month += v;
    var k = o.paymentMethod || "Other"; pay[k] = pay[k] || { n: 0, v: 0 }; pay[k].n++; pay[k].v += v;
    var d = new Date(o.createdMs), key = d.getFullYear() + "-" + d.getMonth(); mon[key] = (mon[key] || 0) + v;
  });
  var ms = [], i, d, mx = 1;
  for (i = 5; i >= 0; i--) { d = new Date(now.getFullYear(), now.getMonth() - i, 1); var val = mon[d.getFullYear() + "-" + d.getMonth()] || 0; if (val > mx) mx = val; ms.push({ l: d.toLocaleString("en", { month: "short" }) + " " + String(d.getFullYear()).slice(2), v: val }); }
  var card = function (v, l) { return '<div class="stat"><b>' + fmt(v) + '</b>' + l + '</div>'; };
  return '<div class="stat-grid">' + card(R.all, "Total revenue (excl. cancelled)") + card(R.got, "Received (Delivered)") + card(R.wait, "Pending / on the way") + card(R.canc, "Cancelled orders value") + '</div>' +
    '<div class="stat-grid">' + card(R.today, "Today") + card(R.week, "Last 7 days") + card(R.month, "This month") + card(R.n ? Math.round(R.all / R.n) : 0, "Average order value") + '</div>' +
    '<div class="card" style="margin-bottom:24px"><h3>Revenue - last 6 months</h3><div class="bars">' + ms.map(function (m) { return '<div class="c"><span class="v">' + (m.v ? fmt(m.v).replace("PKR ", "") : "0") + '</span><i style="height:' + Math.max(2, Math.round(m.v / mx * 140)) + 'px"></i>' + m.l + '</div>'; }).join("") + '</div></div>' +
    '<h3 style="margin-bottom:12px">Revenue by payment method</h3>' + (R.n ? '<div class="tw"><table><tr><th>Method</th><th>Orders</th><th>Revenue</th><th>Share</th></tr>' + Object.keys(pay).map(function (k) { return '<tr><td>' + esc(k) + '</td><td>' + pay[k].n + '</td><td>' + fmt(pay[k].v) + '</td><td>' + Math.round(pay[k].v / R.all * 100) + '%</td></tr>'; }).join("") + '</table></div>' : '<div class="empty"><p>No revenue yet.</p></div>');
}
var TSTEPS = ["Pending", "Confirmed", "Shipped", "Delivered"];
var TINFO = { Pending: ["Order placed", "We received your order and will confirm it soon.", "🧾"], Confirmed: ["Order confirmed", "Your order is confirmed and is being packed.", "✅"], Shipped: ["On the way", "Your parcel has been handed to our delivery partner.", "🚚"], Delivered: ["Delivered", "Your order has been delivered. Enjoy your purchase!", "📦"] };
function trackHTML(o) {
  var H = {}; (o.history || []).forEach(function (h) { H[h.s] = h.t; }); if (!H.Pending) H.Pending = o.createdMs;
  var head = '<h3 style="margin-bottom:4px">Track order ' + esc(o.orderNo) + '</h3><p style="color:var(--mut);margin-bottom:12px">Placed ' + new Date(o.createdMs).toLocaleDateString() + ' · ' + fmt(o.total) + ' · ' + esc(o.paymentMethod) + '</p>';
  var items = '<div class="note" style="margin-top:16px;margin-bottom:0">' + o.items.map(function (i) { return esc(i.name) + " (" + esc(i.size) + ") × " + i.qty; }).join("<br/>") + '</div>';
  var help = '<p style="color:var(--mut);font-size:.9rem;margin-top:12px">Need help? Call/WhatsApp <b>' + esc(SH.phone) + '</b></p>';
  if (o.status === "Cancelled") return head + '<div class="msg err">This order was cancelled' + (H.Cancelled ? " on " + new Date(H.Cancelled).toLocaleDateString() : "") + '.</div>' + items + help;
  var idx = TSTEPS.indexOf(o.status); if (idx < 0) idx = 0;
  return head + '<ul class="tl">' + TSTEPS.map(function (s, i) {
    var c = i < idx ? "done" : i === idx ? "done now" : "todo";
    return '<li class="' + c + '"><span class="dot">' + (i <= idx ? TINFO[s][2] : "") + '</span><b>' + TINFO[s][0] + '</b><small>' + (H[s] ? new Date(H[s]).toLocaleString() : (i > idx ? "Waiting" : "")) + '</small>' + (i === idx ? '<div style="font-size:.9rem;margin-top:2px">' + TINFO[s][1] + '</div>' : "") + '</li>';
  }).join("") + '</ul>' + items + help;
}
function drawAdmin() {
  var b = $("#adm"); if (!b) return; var A = S.adm, h = "";
  if (S.tab === "dashboard") {
    var rev = 0, pend = 0; A.orders.forEach(function (o) { if (o.status !== "Cancelled") rev += o.total; if (o.status === "Pending") pend++; });
    h = '<div class="stat-grid"><div class="stat"><b>' + A.orders.length + '</b>Total orders</div><div class="stat"><b>' + pend + '</b>Pending orders</div><div class="stat"><b>' + fmt(rev) + '</b>Revenue</div><div class="stat"><b>' + A.users.length + '</b>Customers</div><div class="stat"><b>' + S.all.length + '</b>Products</div><div class="stat"><b>' + A.messages.length + '</b>Messages</div><div class="stat"><b>' + A.reviews.filter(function (r) { return !r.approved; }).length + '</b>Reviews to approve</div></div>' +
      '<h3 style="margin-bottom:12px">Latest orders</h3>' + ordersTable(A.orders.slice(0, 5), true);
  } else if (S.tab === "payouts") {
    h = payoutsHTML();
  } else if (S.tab === "revenue") {
    h = revenueHTML(A.orders);
  } else if (S.tab === "products") {
    if (!S.stored) h = '<div class="note"><b>Step 1:</b> import the 3 starter products into your database, then you can edit them and add new ones.</div><button class="btn" onclick="PH.seed()">Import starter products</button>';
    else h = '<div class="bar"><h3>Products (' + S.all.length + ')</h3><p style="color:var(--mut);font-size:.9rem">Use the Home page button to choose which products show in Featured Products on the home page. If you choose none, the first 8 are shown.</p><button class="btn sm" onclick="PH.pform()">+ Add new product</button></div><div class="tw"><table><tr><th>Image</th><th>Name</th><th>Sizes &amp; prices</th><th>Order</th><th>Home page</th><th>Status</th><th>Actions</th></tr>' +
      S.all.map(function (p) { return '<tr><td>' + (p.image ? '<img src="' + esc(p.image) + '" alt=""/>' : "📦") + '</td><td><b>' + esc(p.name) + '</b></td><td>' + p.variants.map(function (v) { return esc(v.size) + ": " + fmt(v.price); }).join("<br/>") + '</td><td>' + (p.order || 0) + '</td><td><button class="btn ' + (p.home ? "" : "dk ") + 'sm" onclick="PH.homeTog(\'' + p.id + '\')">' + (p.home ? "✓ On Home" : "+ Add to Home") + '</button></td><td><span class="st">' + (p.active === false ? (p.owner ? "Waiting approval" : "Hidden") : "Live") + '</span></td><td class="row">' + (p.active === false ? '<button class="btn sm" onclick="PH.approve(\'' + p.id + '\')">Approve</button>' : '<button class="btn dk sm" onclick="PH.approve(\'' + p.id + '\')">Hide</button>') + '<button class="btn dk sm" onclick="PH.pform(\'' + p.id + '\')">Edit</button><button class="btn red sm" onclick="PH.pdel(\'' + p.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>';
  } else if (S.tab === "orders") {
    var st = ["all", "Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
    var list = A.orders.filter(function (o) { return A.filter === "all" || o.status === A.filter; });
    h = '<div class="bar"><select class="inp" style="max-width:220px" onchange="PH.ofilter(this.value)">' + st.map(function (s) { return '<option value="' + s + '"' + (A.filter === s ? " selected" : "") + '>' + (s === "all" ? "All orders" : s) + '</option>'; }).join("") + '</select><button class="btn sm" onclick="PH.exportOrders()">⬇ Export to Excel</button></div>' + ordersTable(list, false);
  } else if (S.tab === "discounts") {
    h = '<div class="card" style="margin-bottom:24px"><h3 style="margin-bottom:12px">Create a discount code</h3><form onsubmit="PH.cadd(event)"><div class="g2"><div class="fld"><label>Code (letters / numbers)</label><input name="code" required="required" placeholder="SALE10" style="text-transform:uppercase"/></div><div class="fld"><label>Type</label><select name="type"><option value="percent">Percent (%)</option><option value="fixed">Fixed amount (PKR)</option></select></div></div>' +
      '<div class="g2"><div class="fld"><label>Discount value</label><input name="value" type="number" min="1" required="required" placeholder="10"/></div><div class="fld"><label>Minimum order in PKR (optional)</label><input name="min" type="number" min="0" placeholder="0"/></div></div>' +
      '<div class="fld"><label>Expiry date (optional)</label><input name="exp" type="date"/></div><button class="btn" type="submit">Save discount code</button></form></div>' +
      '<h3 style="margin-bottom:12px">Your discount codes (' + A.coupons.length + ')</h3>' + (A.coupons.length ? '<div class="tw"><table><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Expires</th><th>Status</th><th></th></tr>' +
      A.coupons.map(function (c) { return '<tr><td><b>' + esc(c.code) + '</b></td><td>' + (c.type === "percent" ? c.value + "%" : fmt(c.value)) + '</td><td>' + (c.minOrder ? fmt(c.minOrder) : "-") + '</td><td>' + (c.expiresMs ? new Date(c.expiresMs).toLocaleDateString() : "Never") + '</td><td><span class="st">' + (c.active === false ? "Off" : (c.expiresMs && Date.now() > c.expiresMs ? "Expired" : "Active")) + '</span></td><td class="row"><button class="btn dk sm" onclick="PH.ctoggle(\'' + c.id + '\')">' + (c.active === false ? "Turn on" : "Turn off") + '</button><button class="btn red sm" onclick="PH.cdel(\'' + c.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>' : '<div class="empty"><p>No discount codes yet. Create your first one above.</p></div>');
  } else if (S.tab === "categories") {
    h = '<div class="card"><h3 style="margin-bottom:6px">Categories</h3><p style="color:var(--mut);margin-bottom:14px">They appear on the home page, the shop filter and the product form.</p><form onsubmit="PH.catadd(event)"><div class="g2"><div class="fld"><label>Category name</label><input name="name" required="required" maxlength="30"/></div><div class="fld"><label>Emoji (optional)</label><input name="emoji" maxlength="4" placeholder="🛍️"/></div></div><button class="btn" type="submit">Add category</button></form></div>' +
      '<div class="card" style="margin-top:18px">' + (CONFIG.categories || []).map(function (c) {
        var n = S.all.filter(function (p) { return (p.cat || "General") === c; }).length;
        return '<div style="display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid var(--line)"><span style="font-size:1.6rem">' + ((CONFIG.catEmoji || {})[c] || "🛍️") + '</span><b style="flex:1">' + esc(c) + '</b><small>' + n + ' product' + (n === 1 ? "" : "s") + '</small><button class="btn red sm" data-c="' + esc(c) + '" onclick="PH.catdel(this.dataset.c)">Delete</button></div>';
      }).join("") + '</div>';
  } else if (S.tab === "pages") {
    h = '<div class="card"><h3 style="margin-bottom:12px">Custom pages</h3><form onsubmit="PH.padd(event)"><div class="fld"><label>Page title (shown in the menu)</label><input name="title" required="required"/></div><div class="fld"><label>Top image link (optional)</label><input name="img"/></div><div class="fld"><label>Content: headings, text or HTML</label><textarea name="body" rows="6" required="required"></textarea></div><button class="btn" type="submit">Add page</button></form></div>' + (S.pagesList || []).map(function (g) { return '<div class="card" style="margin-top:12px"><div class="bar" style="margin:0"><b>' + esc(g.title) + '</b><button class="btn red sm" onclick="PH.pgdel(\'' + g.id + '\')">Delete</button></div></div>'; }).join("");
  } else if (S.tab === "chat") {
    startAdminChat();
    h = (S.chatList || []).map(function (c) { return '<div class="card" style="margin-bottom:12px"><b>' + esc(c.name || "") + '</b> <span style="color:var(--mut)">' + esc(c.email || "") + '</span>' + (c.msgs || []).map(function (m) { return bubble(m, "a"); }).join("") + '<form onsubmit="PH.achat(event,\'' + c.id + '\')" style="display:flex;gap:6px;margin-top:8px"><input class="inp" name="m" placeholder="Reply" required="required"/><button class="btn sm" type="submit">Send</button></form></div>'; }).join("") || '<p>No chats yet.</p>';
  } else if (S.tab === "faq") {
    var FL = faqList();
    h = '<div class="card" style="margin-bottom:18px"><h3 style="margin-bottom:6px">Add a question</h3><p style="color:var(--mut);margin-bottom:12px">You choose where each question appears: on the FAQ page, as a quick question in the live chat, or both. In the chat the customer taps the question and gets the answer instantly.</p><form onsubmit="PH.faqAdd(event)"><div class="fld"><label>Question</label><input name="q" required="required" maxlength="140"/></div><div class="fld"><label>Answer</label><textarea name="a" rows="3" required="required" maxlength="600"></textarea></div><label class="row" style="margin-bottom:8px"><input type="checkbox" name="onfaq" checked="checked" style="width:auto"/> Show on FAQ page</label><label class="row" style="margin-bottom:12px"><input type="checkbox" name="onchat" checked="checked" style="width:auto"/> Show in live chat (max 8 are shown)</label><button class="btn" type="submit">Add question</button></form></div>' +
      (S.faqs ? "" : '<div class="note">You are seeing the default questions. When you change anything, your own list is saved.</div>') +
      FL.map(function (x) { return '<div class="card" style="margin-bottom:10px"><b>' + esc(x.q) + '</b><p style="color:var(--mut);margin:4px 0 10px">' + esc(x.a) + '</p><div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn ' + (x.faq !== false ? "" : "dk ") + 'sm" onclick="PH.faqTog(\'' + x.id + '\',\'faq\')">FAQ page: ' + (x.faq !== false ? "ON" : "OFF") + '</button><button class="btn ' + (x.chat ? "" : "dk ") + 'sm" onclick="PH.faqTog(\'' + x.id + '\',\'chat\')">Live chat: ' + (x.chat ? "ON" : "OFF") + '</button><button class="btn dk sm" onclick="PH.faqEdit(\'' + x.id + '\')">Edit</button><button class="btn red sm" onclick="PH.faqDel(\'' + x.id + '\')">Delete</button></div></div>'; }).join("");
  } else if (S.tab === "resellerSettings") {
    var RS = S.resellerSettings || CONFIG.resellerDefaults;
    h = '<div class="card"><h3 style="margin-bottom:8px">Reseller commission, profit limits and rules</h3><p style="color:var(--mut);margin-bottom:14px">These settings apply to reseller earnings and customer orders created by resellers.</p><form onsubmit="PH.rsetSave(event)"><div class="g2"><div class="fld"><label>Commission per product (%)</label><input name="commission" type="number" min="0" max="100" step="0.1" required="required" value="' + Number(RS.commissionPct == null ? CONFIG.commissionPct : RS.commissionPct) + '"/></div><div class="fld"><label>Minimum reseller profit per item (PKR)</label><input name="minProfit" type="number" min="0" required="required" value="' + Number(RS.minProfit || 0) + '"/></div></div><div class="fld"><label>Maximum reseller profit per item (PKR)</label><input name="maxProfit" type="number" min="0" required="required" value="' + Number(RS.maxProfit == null ? 100000 : RS.maxProfit) + '"/></div><div class="fld"><label>Reseller rules (shown in reseller dashboard)</label><textarea name="rules" rows="6" required="required">' + esc(RS.rules || "") + '</textarea></div><button class="btn" type="submit">Save reseller settings</button></form></div>';
  } else if (S.tab === "site") {
    var X = S.site || {};
    h = '<div class="card"><h3 style="margin-bottom:12px">Home page banner and notice</h3><form onsubmit="PH.ssave(event)"><div class="fld"><label>Notice bar messages: one message per line. They change automatically every 5 seconds (message 2 appears 5 seconds after message 1).</label><textarea name="notice" rows="4">' + esc(X.notice || "") + '</textarea></div><div class="fld"><label>Banner image link (optional)</label><input name="banner" value="' + esc(X.banner || "") + '"/></div><button class="btn" type="submit">Save</button></form></div>';
  } else if (S.tab === "delivery") {
    var D = S.delivery || { fee: 200, freeAbove: 0, perKg: 100, auto: true };
    h = '<div class="card"><h3 style="margin-bottom:6px">Delivery charges</h3><p style="color:var(--mut);margin-bottom:14px">These prices are used at checkout and in the order emails.</p><form onsubmit="PH.dsave(event)"><div class="g2"><div class="fld"><label>Standard delivery charge (PKR)</label><input name="fee" type="number" min="0" required="required" value="' + (D.fee != null ? D.fee : (Number(CONFIG.deliveryFee) || 0)) + '"/></div>' +
      '<div class="fld"><label>Free delivery on orders above (PKR)</label><input name="free" type="number" min="0" value="' + (D.freeAbove || 0) + '"/></div></div>' +
      '<div class="g2"><div class="fld"><label>Extra charge for each additional kg (PKR)</label><input name="perkg" type="number" min="0" value="' + (D.perKg || 0) + '"/></div><div class="fld"><label>Automatic by weight</label><label style="display:flex;gap:10px;align-items:center;font-weight:500;padding:12px 0"><input type="checkbox" name="auto" style="width:auto"' + (D.auto ? ' checked="checked"' : "") + '/> Calculate delivery from order weight</label></div></div>' +
      '<div class="g2"><div class="fld"><label>Wholesale delivery applies above (PKR)</label><input name="wholesaleThreshold" type="number" min="0" value="' + (D.wholesaleThreshold != null ? D.wholesaleThreshold : (CONFIG.wholesale && CONFIG.wholesale.threshold) || 50000) + '"/></div><div class="fld"><label>Minimum wholesale delivery charge above threshold (PKR)</label><input name="wholesaleFee" type="number" min="0" value="' + (D.wholesaleFee != null ? D.wholesaleFee : (CONFIG.wholesale && CONFIG.wholesale.fee) || 200) + '"/></div></div>' +
      '<div class="fld"><label>City-wise charges (optional) - one per line, like Lahore=150</label><textarea name="cities" rows="6" placeholder="Lahore=150">' + esc(D.citiesText || "") + '</textarea></div>' +
      '<p class="fine" style="text-align:left;margin-bottom:12px">Automatic: the standard charge (or the city charge) covers the first kg, and each extra kg adds the extra charge. 250 GM counts as 0.25 kg, 500 GM as 0.5 kg, and the total is rounded up to whole kg. Cities that are not in the list use the standard charge. Put 0 in "Free delivery above" to switch free delivery off. Put 0 as the standard charge for free delivery everywhere.</p><button class="btn" type="submit">Save delivery charges</button></form></div>';
  } else if (S.tab === "customers") {
    h = '<div class="bar"><h3>Customers (' + A.users.length + ')</h3><button class="btn sm" onclick="PH.exportUsers()">⬇ Export to Excel</button></div><div class="tw"><table><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Access</th><th></th></tr>' +
      A.users.map(function (u) { return '<tr><td>' + esc(u.name) + '</td><td>' + esc(u.email) + '</td><td>' + esc(u.phone) + '</td><td>' + (u.createdMs ? new Date(u.createdMs).toLocaleDateString() : "") + '</td><td>' + accessCell(u) + '</td><td><button class="btn red sm" onclick="PH.udel(\'' + u.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>';
  } else if (S.tab === "reviews") {
    h = '<div class="bar"><h3>Reviews (' + A.reviews.length + ')</h3><p style="color:var(--mut)">Only approved reviews are shown on the website.</p></div>' + (A.reviews.length ? '<div class="tw"><table><tr><th>Date</th><th>Product</th><th>Customer</th><th>Rating</th><th>Review</th><th>Status</th><th></th></tr>' +
      A.reviews.map(function (r) { return '<tr><td>' + new Date(r.createdMs).toLocaleDateString() + '</td><td>' + esc(r.productName) + '</td><td>' + esc(r.name) + '</td><td>' + stars(r.rating) + '</td><td style="min-width:240px">' + esc(r.text) + '</td><td><span class="st">' + (r.approved ? "Approved" : "Waiting") + '</span></td><td class="row">' +
        (r.approved ? '<button class="btn dk sm" onclick="PH.rapprove(\'' + r.id + '\',false)">Hide</button>' : '<button class="btn sm" onclick="PH.rapprove(\'' + r.id + '\',true)">Approve</button>') + '<button class="btn red sm" onclick="PH.rdel(\'' + r.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>' : '<div class="empty"><p>No reviews yet.</p></div>');
  } else {
    h = '<div class="bar"><h3>Messages (' + A.messages.length + ')</h3><button class="btn sm" onclick="PH.exportMsgs()">⬇ Export to Excel</button></div><div class="tw"><table><tr><th>Date</th><th>Name</th><th>Contact</th><th>Message</th><th>Status</th><th></th></tr>' +
      A.messages.map(function (m) { return '<tr><td>' + new Date(m.createdMs).toLocaleString() + '</td><td>' + esc(m.name) + '</td><td>' + esc(m.email) + '<br/>' + esc(m.phone) + '</td><td style="min-width:240px">' + esc(m.message) + (m.reply ? '<div class="note" style="margin:8px 0 0"><b>Your reply:</b> ' + esc(m.reply) + '</div>' : "") + '</td><td><span class="st">' + (m.repliedMs ? "Replied" : "New") + '</span></td><td class="row"><button class="btn sm" onclick="PH.mreply(\'' + m.id + '\')">Reply</button><button class="btn red sm" onclick="PH.mdel(\'' + m.id + '\')">Delete</button></td></tr>'; }).join("") + '</table></div>';
  }
  b.innerHTML = h;
  var tb = $("#atabs"); if (tb) { var bs = tb.querySelectorAll("button"), names = ["dashboard", "revenue", "products", "categories", "orders", "discounts", "delivery", "site", "pages", "chat", "faq", "customers", "messages", "reviews"]; for (var i = 0; i < names.length; i++) if (bs[i]) bs[i].className = names[i] === S.tab ? "on" : ""; }
}
function ordersTable(list, ro) {
  if (!list.length) return '<div class="empty"><p>No orders yet.</p></div>';
  var ss = ["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
  return '<div class="tw"><table><tr><th>Order</th><th>Date</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>' + list.map(function (o) {
    return '<tr><td><b>' + o.orderNo + '</b></td><td>' + new Date(o.createdMs).toLocaleString() + '</td><td>' + esc(o.customer.name) + '<br/><small>' + esc(o.customer.phone) + '</small></td><td>' + fmt(o.total) + '</td><td>' + esc(o.paymentMethod) + (o.txnId ? '<br/><small>' + esc(o.txnId) + '</small>' : "") + '</td><td>' +
      (ro ? '<span class="st">' + esc(o.status) + '</span>' : '<select class="inp" style="padding:6px 10px" onchange="PH.status(\'' + o.id + '\',this)">' + ss.map(function (s) { return '<option' + (s === o.status ? " selected" : "") + '>' + s + '</option>'; }).join("") + '</select>') +
      '</td><td class="row"><button class="btn dk sm" onclick="PH.oview(\'' + o.id + '\')">View</button>' + (ro ? "" : '<button class="btn red sm" onclick="PH.odel(\'' + o.id + '\')">Delete</button>') + '</td></tr>'; }).join("") + '</table></div>';
}
function accessCell(u) {
  var h = [], b = "";
  if (u.wholesale) h.push("Wholesale"); if (u.type === "reseller") h.push("Reseller");
  if (!u.wholesale) b += '<button class="btn sm" onclick="PH.uaccess(\'' + u.id + '\',\'wholesale\',true)">Approve wholesale' + (u.requestedType === "business" ? " (requested)" : "") + '</button> ';
  if (u.wholesale) b += '<button class="btn dk sm" onclick="PH.uaccess(\'' + u.id + '\',\'wholesale\',false)">Remove wholesale</button> ';
  if (u.type !== "reseller") b += '<button class="btn sm" onclick="PH.uaccess(\'' + u.id + '\',\'reseller\',true)">Approve reseller' + (u.requestedType === "reseller" ? " (requested)" : "") + '</button> ';
  if (u.type === "reseller") b += '<button class="btn dk sm" onclick="PH.uaccess(\'' + u.id + '\',\'reseller\',false)">Remove reseller</button>';
  return (h.length ? '<small>Approved: ' + h.join(", ") + '</small><br/>' : "") + b;
}
function modal(h) { closeModal(); var m = document.createElement("div"); m.id = "modal"; m.innerHTML = '<div class="box"><button class="close" onclick="PH.close()" aria-label="Close">✕</button>' + h + '</div>'; document.body.appendChild(m); }
function closeModal() { var m = $("#modal"); if (m) m.remove(); }
function vrow(v) { v = v || {}; return '<div class="vrow am-variant-row"><input class="vs" aria-label="Variant name" placeholder="e.g. Black / Medium" value="' + esc(v.size || "") + '"/><input class="vp" aria-label="Variant price" type="number" min="0" step="1" placeholder="Price PKR" value="' + (v.price || "") + '" oninput="PH.pLive()"/><input class="vstock" aria-label="Variant stock" type="number" min="0" step="1" placeholder="Stock" value="' + (v.stock == null ? "" : v.stock) + '"/><div class="am-variant-image-cell"><input class="vimage" aria-label="Variant image URL" placeholder="Image URL (optional)" value="' + esc(v.image || "") + '"/><label class="am-vfile-label">Upload<input class="vimagefile" type="file" accept="image/*" onchange="PH.vimg(this)"/></label><img class="vimageprev" alt="Variant preview" src="' + esc(v.image || "") + '" style="' + (v.image ? '' : 'display:none') + '"/><small class="vimage-status"></small></div><button type="button" class="x" aria-label="Remove variant" onclick="this.parentNode.remove()">×</button></div>'; }
function xl(rows, name) {
  if (!rows.length) { toast("Nothing to export yet."); return; }
  if (typeof XLSX === "undefined") { toast("Preparing Excel file..."); var xs = document.createElement("script"); xs.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"; xs.onload = function () { xl(rows, name); }; xs.onerror = function () { toast("Excel library could not load. Check your internet."); }; document.head.appendChild(xs); return; }
  var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Sheet1");
  XLSX.writeFile(wb, name + "_" + new Date().toISOString().slice(0, 10) + ".xlsx");
}

/* ---------- router / render ---------- */
function after() {
  var els = document.querySelectorAll(".rv:not(.in)");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (en) { en.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }); }, { threshold: .08 });
    els.forEach(function (e) { io.observe(e); });
  } else els.forEach(function (e) { e.classList.add("in"); });
  if (!window.matchMedia || !matchMedia("(hover:hover)").matches || reduce) return;
  document.querySelectorAll("[data-tilt]").forEach(function (c) {
    if (c._t) return; c._t = 1;
    c.addEventListener("mousemove", function (e) { var r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; c.style.transform = "perspective(900px) rotateY(" + x * 10 + "deg) rotateX(" + -y * 10 + "deg) translateY(-6px)"; });
    c.addEventListener("mouseleave", function () { c.style.transform = ""; });
  });
}
function bindStage() {
  var st = $("#stage"), t = $("#tilt"); if (!st || !t || reduce) return;
  st.addEventListener("mousemove", function (e) { var r = st.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; t.style.transform = "rotateY(" + x * 30 + "deg) rotateX(" + -y * 20 + "deg)"; });
  st.addEventListener("mouseleave", function () { t.style.transform = ""; });
}
function particles() {
  var c = $("#parts"); if (!c || reduce || getComputedStyle(c).display === "none") return; var x = c.getContext("2d"), P = [], n = innerWidth < 700 ? 16 : 38;
  function size() { c.width = c.offsetWidth; c.height = c.offsetHeight; } size();
  for (var i = 0; i < n; i++) P.push({ x: Math.random() * c.width, y: Math.random() * c.height, r: 1 + Math.random() * 3, v: .25 + Math.random() * .6, a: Math.random() * 6.28 });
  (function loop() {
    if (!document.getElementById("parts")) return;
    if (!document.hidden) {
      x.clearRect(0, 0, c.width, c.height);
      P.forEach(function (p) { p.y -= p.v; p.a += .015; p.x += Math.sin(p.a) * .4; if (p.y < -6) { p.y = c.height + 6; p.x = Math.random() * c.width; }
        x.beginPath(); x.arc(p.x, p.y, p.r, 0, 6.283); x.fillStyle = "rgba(255,200,60," + (.2 + p.r / 8) + ")"; x.fill(); });
    }
    raf = requestAnimationFrame(loop);
  })();
}
function render() {
  cancelAnimationFrame(raf); clearInterval(NT); closeModal();
  var h = (location.hash || "#/home").replace(/^#\/?/, "") || "home", parts = h.split("/"), r = parts[0], html = "";
  S.hook = null;
  var map = { home: pHome, shop: pShop, about: pAbout, contact: pContact, faq: pFaq, cart: pCart, checkout: pCheckout, success: pSuccess, wishlist: pWish, login: pLogin, reset: pReset, account: pAccount, "admin-login": pAdminLogin, admin: pAdmin };
  if (r === "page") html = pCustom(parts[1]); else if (r === "product") html = pProduct(parts[1]); else if (r === "policies") html = pPolicies(parts[1]); else html = (map[r] || pHome)();
  if (!html) return;
  $("#view").innerHTML = html;
  hdr(); $("#nav").className = ""; $("#burger").className = "burger";
  document.querySelectorAll("#nav a").forEach(function (a) { a.classList.toggle("act", a.getAttribute("data-r") === r); });
  window.scrollTo(0, 0); after(); bindStage(); particles(); startNotice();
  if (S.hook) S.hook();
}

/* ---------- public actions (used by onclick) ---------- */
function err(m, id) { var b = $("#" + (id || "cmsg")); if (b) b.innerHTML = '<div class="msg err">' + esc(m) + '</div>'; }
function okm(m) { var b = $("#cmsg"); if (b) b.innerHTML = '<div class="msg ok">' + esc(m) + '</div>'; }
function afterLogin() { var r = S.redirect, u = auth && auth.currentUser; S.redirect = null; location.hash = r ? "#/" + r : (u && isAdminEmail(u.email) ? "#/admin" : "#/account"); }
function nice(e) { var c = e && e.code || ""; if (c.indexOf("wrong-password") > -1 || c.indexOf("invalid-credential") > -1 || c.indexOf("user-not-found") > -1) return "Wrong email or password."; if (c.indexOf("email-already") > -1) return "This email already has an account. Please log in."; if (c.indexOf("weak-password") > -1) return "Password must be at least 6 characters."; if (c.indexOf("too-many") > -1) return "Too many attempts. Try again later."; if (c.indexOf("invalid-email") > -1) return "That email address is not valid."; if (c.indexOf("network") > -1) return "Network problem. Check your internet and try again."; if (c.indexOf("unauthorized-domain") > -1 || c.indexOf("unauthorized-continue") > -1) return "This website domain is not allowed yet. In Firebase Console > Authentication > Settings > Authorized domains, add your site domain."; if (c.indexOf("operation-not-allowed") > -1) return "Email/Password sign-in is turned off. Enable it in Firebase Console > Authentication > Sign-in method."; if (c.indexOf("expired-action") > -1 || c.indexOf("invalid-action") > -1) return "This reset link is expired or already used. Request a new one."; return (e && e.message) || "Something went wrong."; }

window.PH = {
  menu: function () { $("#nav").classList.toggle("open"); $("#burger").classList.toggle("open"); },
  back: function () { if (history.length > 1) history.back(); else location.hash = "#/home"; },
  pick: function (el) { var c = el.closest("[data-pid]"); c.querySelectorAll(".chip").forEach(function (x) { x.classList.remove("on"); }); el.classList.add("on"); c.querySelector("[data-price]").textContent = fmt(el.getAttribute("data-p")); },
  add: function (b) { var c = b.closest("[data-pid]"), s = c.querySelector(".chip.on"), q = c.querySelector("[data-qty]"); addItem(c.getAttribute("data-pid"), s ? +s.getAttribute("data-i") : 0, q ? +q.value : 1); },
  q: function (d) { var i = $("[data-qty]"); i.value = Math.min(99, Math.max(1, +i.value + d)); },
  wish: function (id, el) {
    var i = S.wish.indexOf(id); if (i > -1) { S.wish.splice(i, 1); toast("Removed from wishlist"); } else { S.wish.push(id); toast("Saved to wishlist"); }
    save("am_wish", S.wish); hdr();
    if ((location.hash || "").indexOf("#/wishlist") === 0) render(); else if (el) { if (el.classList.contains("heart")) el.classList.toggle("on", i < 0); else el.textContent = i < 0 ? "♥ In Wishlist" : "♡ Wishlist"; }
  },
  buy: function (b) { PH.add(b); location.hash = "#/checkout"; },
  rvlogin: function (id) { S.redirect = "product/" + id; },
  rate: function (n) { document.querySelectorAll("#rate button").forEach(function (b, i) { b.classList.toggle("on", i < n); }); $("input[name=rating]").value = n; },
  review: function (e, pid) {
    e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target, r = +f.rating.value, t = f.text.value.trim(), p = getP(pid), box = $("#rmsg");
    if (!r) { box.innerHTML = '<div class="msg err">Please choose a star rating.</div>'; return; }
    if (t.length < 5) { box.innerHTML = '<div class="msg err">Please write a few words about the product.</div>'; return; }
    var btn = f.querySelector("button[type=submit]"), photoFile = f.reviewPhoto && f.reviewPhoto.files && f.reviewPhoto.files[0]; btn.disabled = true;
    (photoFile ? compress(photoFile, 700, .72).then(function(d){return storeImg(d,"reviews");}) : Promise.resolve(""))
      .then(function(photo){ return db.collection("reviews").doc(pid + "_" + S.user.uid).set({ productId: pid, productName: p.name, userId: S.user.uid, name: (S.profile && S.profile.name) || S.user.displayName || "Customer", rating: r, text: t, photo: photo || "", approved: false, createdMs: Date.now() }); })
      .then(function () { f.reset(); document.querySelectorAll("#rate button").forEach(function (b) { b.classList.remove("on"); }); box.innerHTML = '<div class="msg ok">Thank you! Your review will appear after approval.</div>'; btn.disabled = false; })
      .catch(function (x) { box.innerHTML = '<div class="msg err">' + (x && x.code === "permission-denied" ? "You have already sent a review for this product." : esc(nice(x))) + '</div>'; btn.disabled = false; });
  },
  rapprove: function (id, v) { db.collection("reviews").doc(id).update({ approved: v }).then(function () { S.adm.reviews.forEach(function (r) { if (r.id === id) r.approved = v; }); drawAdmin(); toast(v ? "Review approved and now live" : "Review hidden"); }).catch(function (x) { toast(x.message); }); },
  rdel: function (id) { if (!confirm("Delete this review?")) return; db.collection("reviews").doc(id).delete().then(function () { S.adm.reviews = S.adm.reviews.filter(function (r) { return r.id !== id; }); drawAdmin(); }).catch(function (x) { toast(x.message); }); },
  clearWish: function () { if (!S.wish.length) return; if (!confirm("Remove all products from your wishlist?")) return; S.wish = []; save("am_wish", S.wish); hdr(); render(); },
  rm: function (pid, i) { var p = getP(pid), sz = i < 0 ? "Wholesale" : p.variants[i].size; S.cart = S.cart.filter(function (c) { return !(c.pid === pid && c.size === sz); }); saveCart(); render(); },
  cq: function (pid, i, d) { var p = getP(pid), sz = i < 0 ? "Wholesale" : p.variants[i].size, mn = i < 0 ? (p.wsMin || 10) : 1, mx = i < 0 ? 9999 : 99; S.cart.forEach(function (c) { if (c.pid === pid && c.size === sz) { var nq = c.qty + d; if (nq < mn && d < 0) toast("Wholesale minimum is " + mn + " pieces"); c.qty = Math.min(mx, Math.max(mn, nq)); } }); saveCart(); render(); },
  search: function (v) { S.q = v; drawShop(); },
  sort: function (v) { S.sort = v; drawShop(); },
  payUI: payUI,
  atab: function (t) { S.authTab = t; render(); },
  close: closeModal,
  menu2: null,

  contactWA: function (f) {
    var nm = f.name.value.trim(), ph = f.phone.value.trim(), msg = f.message.value.trim();
    if (!nm || !msg) return err("Please enter your name and message first.");
    var t = "Hello " + SH.name + ", I am " + nm + (ph ? " (" + ph + ")" : "") + ".\n\n" + msg;
    window.open("https://wa.me/" + SH.whatsapp + "?text=" + encodeURIComponent(t), "_blank");
  },
  contact: function (e) {
    e.preventDefault(); var f = e.target, m = { name: f.name.value.trim(), phone: f.phone.value.trim(), email: f.email.value.trim(), message: f.message.value.trim(), createdMs: Date.now() };
    if (!m.email) return err("Please enter your email so we can reply, or use the WhatsApp button.");
    var btn = f.querySelector("button[type=submit]"); btn.disabled = true;
    var p1 = FB_OK ? db.collection("messages").add(m) : Promise.resolve();
    p1.then(function () { return sendMail(SH.email, "New website message from " + m.name, "Name: " + m.name + "\nPhone: " + m.phone + "\nEmail: " + m.email + "\n\nMessage:\n" + m.message, "Online Shah Alami", null, CONFIG.emailjs.messageTemplateId || undefined); })
      .then(function () { if (!FB_OK && !EJ_OK) { err("Messaging is not configured yet. Please WhatsApp us on " + SH.phone + "."); } else { okm("Thank you! Your message has been sent."); f.reset(); } btn.disabled = false; })
      .catch(function (x) { err("Could not send: " + nice(x)); btn.disabled = false; });
  },
  login: function (e) { e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target;
    auth.signInWithEmailAndPassword(f.email.value.trim(), f.password.value).then(function () { toast("Welcome back!"); afterLogin(); }).catch(function (x) { err(nice(x)); }); },
  register: function (e) { e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target, nm = f.name.value.trim(), ph = f.phone.value.trim(), em = f.email.value.trim();
    auth.createUserWithEmailAndPassword(em, f.password.value).then(function (c) {
      return c.user.updateProfile({ displayName: nm }).then(function () { return db.collection("users").doc(c.user.uid).set({ name: nm, email: em, phone: ph, type: "customer", wholesale: false, requestedType: f.atype ? f.atype.value : "customer", createdMs: Date.now() }); }).then(function () { S.profile = { name: nm, email: em, phone: ph }; });
    }).then(function () { toast("Account created. Welcome!"); afterLogin(); }).catch(function (x) { err(nice(x)); }); },
  forgot: function (e) { e.preventDefault(); if (!FB_OK) return needFB(); var em = $("input[name=email]").value.trim(); if (!em) return err("Enter your email first, then tap Forgot password.");
    var done = function (fb) { $("#cmsg").innerHTML = '<div class="msg ok">If an account exists for ' + esc(em) + ', a reset email is on its way' + (fb ? " (from your Firebase project sender address)" : "") + '. Open it and tap the link to choose a new password. <b>Check Spam/Junk and Promotions too.</b> Link not opening? <a href="#/reset" style="color:#1b5e2e;font-weight:700;text-decoration:underline">Paste it here</a>.</div>'; };
    var viaFirebase = function () { return auth.sendPasswordResetEmail(em).then(function () { done(true); }); };
    var p = (typeof firebase.functions === "function") ? firebase.functions().httpsCallable("sendResetEmail")({ email: em }).then(function () { done(false); }).catch(function (x) { console.warn("EmailJS reset function failed, using Firebase email", x); return viaFirebase(); }) : viaFirebase();
    p.catch(function (x) { err(nice(x)); }); },
  logout: function () { if (auth) auth.signOut(); S.user = null; S.isAdmin = false; S.profile = null; S.adm.loaded = false; hdr(); toast("Logged out"); location.hash = "#/home"; },
  adminLogin: function (e) { e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target;
    auth.signInWithEmailAndPassword(f.email.value.trim(), f.password.value).then(function (c) {
      if (CONFIG.adminEmails.map(function (x) { return x.toLowerCase(); }).indexOf((c.user.email || "").toLowerCase()) < 0) { err("This account is not an admin."); return; }
      toast("Admin login successful");
    }).catch(function (x) { err(nice(x)); }); },

  place: function (e) {
    e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target; S.city = f.city.value.trim(); var L = lines(), t = totals();
    var ph = f.phone.value.replace(/[\s-]/g, "");
    if (!/^(?:\+?92|0)?3\d{9}$/.test(ph)) return err("Enter a valid Pakistani mobile number, e.g. 03XXXXXXXXX.");
    if (!L.length) return err("Your cart is empty.");
    var m = f.pay.value, txn = f.txn ? f.txn.value.trim() : "", btn = $("#pbtn"); btn.disabled = true; btn.textContent = "Placing order...";
    var file = f.shot && f.shot.files[0];
    (file ? compress(file, 900, .6).then(function (d) { return storeImg(d, "payments"); }) : Promise.resolve("")).then(function (shot) {
      var o = { orderNo: "AM-" + Date.now().toString(36).toUpperCase(), userId: S.user ? S.user.uid : "guest", userEmail: (S.user && S.user.email) || "",
        customer: { name: f.name.value.trim(), phone: ph, email: f.email.value.trim(), city: f.city.value.trim(), address: f.address.value.trim(), notes: f.notes.value.trim() },
        items: L.map(function (l) { var cm = l.p.owner ? Math.round(l.price * l.qty * (Number((S.resellerSettings || {}).commissionPct == null ? CONFIG.commissionPct : S.resellerSettings.commissionPct) || 0) / 100) : 0; return { pid: l.p.id, name: l.p.name, image: l.p.image || "", image2: l.p.image2 || "", size: l.size, qty: l.qty, price: l.price, owner: l.p.owner || "", comm: cm }; }), owners: L.reduce(function (a, l) { if (l.p.owner && a.indexOf(l.p.owner) < 0) a.push(l.p.owner); return a; }, []),
        subtotal: t.sub, delivery: t.del, codFee: t.codFee || 0, discount: t.disc, coupon: t.disc ? S.coupon.code : "", total: t.total, paymentMethod: m, txnId: txn, screenshot: shot || "", status: "Pending", paymentStatus: (m === "Cash on Delivery" ? "Pay on delivery" : "Pending verification"), createdMs: Date.now(), history: [{ s: "Pending", t: Date.now() }] };
      return (CONFIG.serverOrders && typeof firebase.functions === "function"
        ? firebase.functions().httpsCallable("placeOrder")({ items: L.map(function (l) { return { pid: l.p.id, size: l.size, qty: l.qty }; }), customer: o.customer, paymentMethod: m, txnId: txn, screenshot: shot || "", coupon: t.disc ? S.coupon.code : "" }).then(function (r) { return r.data.order; })
        : db.collection("orders").add(o).then(function () { return o; }));
    }).then(function (o) {
      S.last = o; S.cart = []; S.coupon = null; saveCart();
      sendMail(SH.email, "NEW ORDER " + o.orderNo + " - " + fmt(o.total), orderText(o), "Online Shah Alami", mailVars(o, "New order received", "a new order was placed by " + o.customer.name + "."));
      sendMail(o.customer.email, "Your Online Shah Alami order " + o.orderNo, "Thank you for your order, " + o.customer.name + "!\n\n" + orderText(o) + "\n\nWe will contact you shortly. Call/WhatsApp: " + SH.phone, o.customer.name, mailVars(o, "Thank you for your order!", "we have received your order and will confirm it shortly."));
      location.hash = "#/success";
    }).catch(function (x) { err("Order failed: " + nice(x) + " You can also order on WhatsApp: " + SH.phone); btn.disabled = false; btn.textContent = "Place order · " + fmt(t.total); });
  },

  more: function () { S.shown = (S.shown || 12) + 12; drawShop(); },
  setCity: function (v) { S.city = v; refreshSum(); },
  dsave: function (e) {
    e.preventDefault(); var f = e.target, cities = {}, txt = f.cities.value.trim(), bad = "";
    txt.split(/\r?\n/).forEach(function (ln) {
      ln = ln.trim(); if (!ln) return; var p = ln.split("="), nm = (p[0] || "").trim().toLowerCase(), raw = (p[1] || "").replace(/[^0-9.]/g, ""), v = Number(raw);
      if (p.length !== 2 || !nm || raw === "" || isNaN(v)) bad = ln; else cities[nm] = v;
    });
    if (bad) return toast("Fix this line: " + bad + "  (use Lahore=150)");
    var d = { fee: Number(f.fee.value) || 0, freeAbove: Number(f.free.value) || 0, freeOff: !(Number(f.free.value) > 0), auto: f.auto.checked, perKg: Number(f.perkg.value) || 0, wholesaleThreshold: f.wholesaleThreshold && f.wholesaleThreshold.value !== "" ? Math.max(0, Number(f.wholesaleThreshold.value) || 0) : (Number((CONFIG.wholesale || {}).threshold) || 50000), wholesaleFee: f.wholesaleFee && f.wholesaleFee.value !== "" ? Math.max(0, Number(f.wholesaleFee.value) || 0) : (Number((CONFIG.wholesale || {}).fee) || 200), cities: cities, citiesText: txt, updatedMs: Date.now() };
    db.collection("settings").doc("delivery").set(d).then(function () { S.delivery = d; toast("Delivery charges saved"); }).catch(function (x) { toast(x.message); });
  },
  mreply: function (id) {
    var m = S.adm.messages.filter(function (x) { return x.id === id; })[0]; if (!m) return;
    var ph = String(m.phone || "").replace(/\D/g, "").replace(/^0/, "92");
    modal('<h3 style="margin-bottom:10px">Reply to ' + esc(m.name) + '</h3><div class="note" style="margin-bottom:12px"><b>Their message:</b><br/>' + esc(m.message) + '</div>' + (m.reply ? '<div class="note" style="margin-bottom:12px;background:#e4f6e8;border-color:#7cc58d"><b>Your last reply:</b><br/>' + esc(m.reply) + '</div>' : "") +
      '<div id="rpmsg"></div><div class="fld"><label>Your reply</label><textarea id="rptext" rows="6" placeholder="Type your reply..."></textarea></div><div class="row" style="gap:10px;flex-wrap:wrap">' +
      (m.email ? '<button class="btn sm" id="rpbtn" onclick="PH.msend(\'' + id + '\')">✉ Send by email</button>' : "") + (ph ? '<button class="btn dk sm" onclick="PH.mwa(\'' + id + '\')">WhatsApp</button>' : "") + '</div><p class="fine" style="text-align:left">Email goes to: ' + esc(m.email || "no email given") + '</p>');
  },
  msend: function (id) {
    var m = S.adm.messages.filter(function (x) { return x.id === id; })[0], t = ($("#rptext").value || "").trim(), box = $("#rpmsg"), b = $("#rpbtn"); if (!m) return;
    if (t.length < 2) { box.innerHTML = '<div class="msg err">Write your reply first.</div>'; return; }
    b.disabled = true; b.textContent = "Sending...";
    sendReply(m, t).then(function () { return db.collection("messages").doc(id).update({ reply: t, repliedMs: Date.now() }); }).then(function () { m.reply = t; m.repliedMs = Date.now(); closeModal(); drawAdmin(); toast("Reply sent to " + m.email); })
      .catch(function (x) { b.disabled = false; b.textContent = "✉ Send by email"; box.innerHTML = '<div class="msg err">' + esc((x && (x.text || x.message)) || "Could not send the reply.") + '</div>'; });
  },
  mwa: function (id) {
    var m = S.adm.messages.filter(function (x) { return x.id === id; })[0]; if (!m) return; var t = ($("#rptext").value || "").trim(), ph = String(m.phone || "").replace(/\D/g, "").replace(/^0/, "92");
    window.open("https://wa.me/" + ph + "?text=" + encodeURIComponent(t || ("Hello " + m.name + ", thank you for contacting " + SH.name + ".")), "_blank");
    db.collection("messages").doc(id).update({ reply: t || "(replied on WhatsApp)", repliedMs: Date.now() }).then(function () { m.reply = t || "(replied on WhatsApp)"; m.repliedMs = Date.now(); drawAdmin(); }).catch(function () {});
  },
  doReset: function (e) {
    e.preventDefault(); if (!FB_OK) return needFB(); var f = e.target, raw = f.code.value.trim(), m = raw.match(/oobCode=([^&\s]+)/), code = m ? decodeURIComponent(m[1]) : raw;
    if (f.pw.value !== f.pw2.value) return err("The two passwords do not match.");
    auth.verifyPasswordResetCode(code).then(function (em) {
      return auth.confirmPasswordReset(code, f.pw.value).then(function () { S.authTab = "login"; toast("Password changed for " + em + ". Please log in."); location.hash = "#/login"; });
    }).catch(function (x) { var c = (x && x.code) || ""; err(c.indexOf("expired") > -1 || c.indexOf("invalid-action") > -1 ? "This code is invalid, expired or already used. Go back and request a new reset email." : nice(x)); });
  },
  applyCoupon: function () {
    if (!FB_OK) return needFB(); var code = ($("#cpn").value || "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, ""), m = $("#cpmsg");
    if (!code) { m.innerHTML = '<div class="msg err" style="margin-top:10px">Enter a discount code.</div>'; return; }
    db.collection("coupons").doc(code).get().then(function (d) {
      var c = d.exists ? d.data() : null, t = totals(), er = "";
      if (!c || c.active === false) er = "This discount code is not valid.";
      else if (c.expiresMs && Date.now() > c.expiresMs) er = "This discount code has expired.";
      else if (c.minOrder && t.sub < c.minOrder) er = "This code needs a minimum order of " + fmt(c.minOrder) + ".";
      if (er) { m.innerHTML = '<div class="msg err" style="margin-top:10px">' + er + '</div>'; return; }
      c.code = code; S.coupon = c; refreshSum(); toast("Discount applied: " + code);
    }).catch(function (x) { m.innerHTML = '<div class="msg err" style="margin-top:10px">' + esc(nice(x)) + '</div>'; });
  },
  rmCoupon: function () { S.coupon = null; refreshSum(); },
  cadd: function (e) {
    e.preventDefault(); var f = e.target, code = f.code.value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, ""), v = Number(f.value.value), type = f.type.value;
    if (!code) return toast("Enter a code (letters and numbers only)."); if (!(v > 0)) return toast("Enter a discount value."); if (type === "percent" && v > 100) return toast("Percent cannot be more than 100.");
    var c = { code: code, type: type, value: v, minOrder: Number(f.min.value) || 0, expiresMs: f.exp.value ? new Date(f.exp.value + "T23:59:59").getTime() : 0, active: true, createdMs: Date.now() };
    db.collection("coupons").doc(code).set(c).then(function () {
      c.id = code; S.adm.coupons = S.adm.coupons.filter(function (x) { return x.id !== code; }); S.adm.coupons.unshift(c); drawAdmin(); toast("Discount code saved: " + code);
    }).catch(function (x) { toast(x.message); });
  },
  ctoggle: function (id) { var c = S.adm.coupons.filter(function (x) { return x.id === id; })[0]; if (!c) return; var nv = c.active === false; db.collection("coupons").doc(id).update({ active: nv }).then(function () { c.active = nv; drawAdmin(); toast(nv ? "Code turned on" : "Code turned off"); }).catch(function (x) { toast(x.message); }); },
  cdel: function (id) { if (!confirm("Delete discount code " + id + "?")) return; db.collection("coupons").doc(id).delete().then(function () { S.adm.coupons = S.adm.coupons.filter(function (x) { return x.id !== id; }); drawAdmin(); toast("Code deleted"); }).catch(function (x) { toast(x.message); }); },
  udel: function (id) {
    if (!confirm("Delete this customer from your database?\n\nTheir past orders are kept. To also stop them logging in, delete them in Firebase Console > Authentication > Users.")) return;
    db.collection("users").doc(id).delete().then(function () { S.adm.users = S.adm.users.filter(function (u) { return u.id !== id; }); drawAdmin(); toast("Customer deleted"); }).catch(function (x) { toast(x.message); });
  },
  track: function (id) { var o = (S.myo || []).filter(function (x) { return x.id === id; })[0]; if (o) modal(trackHTML(o)); },
  trackForm: function (e) {
    e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var no = e.target.no.value.trim().toUpperCase(), m = $("#tmsg"); m.innerHTML = "";
    db.collection("orders").where("userId", "==", S.user.uid).where("orderNo", "==", no).get().then(function (s) {
      if (s.empty) { m.innerHTML = '<div class="msg err" style="margin-top:12px">No order found with that number in your account. Check the number in your confirmation email.</div>'; return; }
      var o = s.docs[0].data(); o.id = s.docs[0].id; modal(trackHTML(o));
    }).catch(function (x) { m.innerHTML = '<div class="msg err" style="margin-top:12px">' + esc(x.message) + '</div>'; });
  },
  /* admin actions */
  tab: function (t) { S.tab = t; drawAdmin(); },
  approve: function (id) { var p = getP(id); if (!p) return; var v = p.active === false; db.collection("products").doc(id).set({ active: v, updatedMs: Date.now() }, { merge: true }).then(function () { p.active = v; S.products = S.all.filter(function (x) { return x.active !== false; }); drawAdmin(); toast(v ? "Product approved and now live" : "Product hidden"); }).catch(function (x) { toast(x.message); }); },
  homeTog: function (id) { var p = getP(id); if (!p) return; var v = !p.home; db.collection("products").doc(id).set({ home: v }, { merge: true }).then(function () { p.home = v; S.products = S.all.filter(function (x) { return x.active !== false; }); drawAdmin(); toast(v ? "Added to Home page" : "Removed from Home page"); }).catch(function (x) { toast(x.message); }); },
  refresh: function () { S.adm.loaded = false; $("#adm").innerHTML = "<p>Loading...</p>"; loadAdmin(); },
  ofilter: function (v) { S.adm.filter = v; drawAdmin(); },
  seed: function () {
    var b = db.batch(); DEFAULTS.forEach(function (p) { var d = JSON.parse(JSON.stringify(p)); delete d.id; b.set(db.collection("products").doc(p.id), d); });
    b.commit().then(function () { toast("Starter products imported"); return loadProducts(); }).then(drawAdmin).catch(function (x) { toast("Failed: " + x.message); });
  },
  pform: function (id) {
    var p = id ? getP(id) : { name: "", desc: "", details: "", badge: "", order: S.all.length + 1, active: true, image: "", images: [], variants: [{ size: "Standard", price: "" }] };
    p.variants = Array.isArray(p.variants) && p.variants.length ? p.variants : [{ size: "Standard", price: "" }];
    S.newImg = null; S.newImg2 = null;
    var existingImages = (Array.isArray(p.images) ? p.images : []).concat([p.image || "", p.image2 || ""]).filter(function (x, i, a) { return !!x && a.indexOf(x) === i; });
    var galleryHtml = existingImages.length ? existingImages.map(function (im) { return '<div class="am-existing-img"><img src="' + esc(im) + '" alt="Product image"/><span>Saved image</span></div>'; }).join("") : '<div class="am-empty-gallery">🖼️<span>Product photos will appear here</span></div>';
    var h = `
      <div class="am-product-builder">
        <div id="pmsg" class="am-product-message" role="status" aria-live="polite"></div><header class="am-product-head">
          <div class="am-product-crumb">SELLER CENTER <span>›</span> PRODUCTS <span>›</span> ${id ? 'EDIT PRODUCT' : 'ADD PRODUCT'}</div>
          <div class="am-product-headrow"><div><h2>${id ? 'Edit product' : 'Add a new product'}</h2><p>Complete each section to publish a polished, easy-to-find product listing.</p></div><span class="am-product-status"><i></i> Product listing</span></div>
          <div class="am-product-progress"><span></span></div>
        </header>
        <nav class="am-product-steps" aria-label="Product form sections">
          <button type="button" class="active" onclick="PH.pnav('amProdBasic',this)"><b>1</b><span>Basic information</span></button>
          <button type="button" onclick="PH.pnav('amProdMedia',this)"><b>2</b><span>Images &amp; media</span></button>
          <button type="button" onclick="PH.pnav('amProdSales',this)"><b>3</b><span>Sales information</span></button>
          <button type="button" onclick="PH.pnav('amProdDelivery',this)"><b>4</b><span>Delivery &amp; details</span></button>
          <button type="button" onclick="PH.pnav('amProdPublish',this)"><b>5</b><span>Publish settings</span></button>
        </nav>
        <div class="am-product-layout">
          <aside class="am-product-aside">
            <div class="am-aside-card am-live-preview"><div class="am-aside-title"><span>Live preview</span><small>Preview</small></div>
              <div class="am-preview-photo">${p.image ? '<img id="amProdLiveImage" src="' + esc(p.image) + '" alt="Product preview"/>' : '<img id="amProdLiveImage" style="display:none" alt="Product preview"/><span id="amProdLivePlaceholder">📦</span>'}</div>
              <b id="amProdLiveName">${esc(p.name || 'Your product name')}</b><p id="amProdLiveCat">${esc(p.cat || 'Category')}</p>
              <strong id="amProdLivePrice">${p.variants[0] && p.variants[0].price ? fmt(p.variants[0].price) : 'PKR 0'}</strong>
              <small class="am-preview-tip">Your shop listing updates after you save.</small>
            </div>
            <div class="am-aside-card"><div class="am-aside-title">Listing checklist</div><ul class="am-checklist"><li><span>✓</span> Clear product title</li><li><span>✓</span> Correct category</li><li><span>✓</span> Good product photos</li><li><span>✓</span> Price and stock</li></ul><div class="am-tip">💡 <b>Tip</b><p>Use a plain, searchable product name and clear photos from multiple angles.</p></div></div>
          </aside>
          <div class="am-product-sections">
            <section class="am-product-section" id="amProdBasic"><div class="am-section-heading"><span class="am-section-number">01</span><div><h3>Basic information</h3><p>Tell shoppers exactly what you are selling.</p></div></div>
              <div class="am-product-fields">
                <div class="fld am-full"><label for="pn">Product name <em>Required</em></label><input id="pn" maxlength="180" value="${esc(p.name || '')}" placeholder="e.g. Hair Oil Applicator Comb — Scalp Liquid Comb" oninput="PH.pLive()"/><small>Include the product type and a key feature. Avoid promotional phrases.</small></div>
                <div class="g2"><div class="fld"><label for="pcat">Category <em>Required</em></label><input id="pcat" list="catl" value="${esc(p.cat || '')}" placeholder="Choose or type a category" oninput="PH.pLive()"/><datalist id="catl">${(CONFIG.categories || []).map(function (c) { return '<option value="' + esc(c) + '">'; }).join('')}</datalist></div><div class="fld"><label for="psub">Subcategory</label><input id="psub" value="${esc(p.sub || '')}" placeholder="e.g. Hair care"/></div></div>
                <div class="g2"><div class="fld"><label for="pbrand">Brand</label><input id="pbrand" value="${esc(p.brand || '')}" placeholder="Brand or unbranded"/></div><div class="fld"><label for="psku">Seller SKU</label><input id="psku" value="${esc(p.sku || '')}" placeholder="Optional stock keeping code"/><small>Use a unique code to help manage inventory.</small></div></div>
                <div class="fld am-full"><label for="pd">Product description <em>Required</em></label><textarea id="pd" rows="4" maxlength="5000" placeholder="Describe the main benefits, material, usage and what is included.">${esc(p.desc || '')}</textarea><small>Write original, accurate product information.</small></div>
                <div class="fld am-full"><label for="pdt">Key features / product details</label><textarea id="pdt" rows="4" placeholder="One feature per line&#10;Lightweight design&#10;Easy to clean">${esc(p.details || '')}</textarea></div>
                <div class="fld am-full"><label for="pkeywords">Search keywords (optional)</label><input id="pkeywords" value="${esc(p.searchKeywords || '')}" placeholder="e.g. hair comb, oil applicator, scalp massage"/><small>Separate related search words with commas.</small></div>
                <div class="g2"><div class="fld"><label for="pb">Product label</label><input id="pb" value="${esc(p.badge || '')}" placeholder="e.g. Best Seller"/></div><div class="fld"><label for="pcondition">Condition</label><select id="pcondition"><option value="New"${(p.condition || 'New') === 'New' ? ' selected' : ''}>New</option><option value="Used"${p.condition === 'Used' ? ' selected' : ''}>Used</option><option value="Refurbished"${p.condition === 'Refurbished' ? ' selected' : ''}>Refurbished</option></select></div></div>
              </div>
            </section>
            <section class="am-product-section" id="amProdMedia"><div class="am-section-heading"><span class="am-section-number">02</span><div><h3>Images &amp; media</h3><p>Upload clear, high-quality images of the actual product.</p></div></div>
              <div class="am-primary-upload"><div class="am-upload-icon">＋</div><div class="am-upload-copy"><b>Main product image</b><span>JPG, PNG or WebP · square image recommended</span></div><label class="am-upload-btn" for="pf">Choose image</label><input id="pf" type="file" accept="image/*" onchange="PH.pimg(this)"/></div>
              <div class="am-main-preview">${p.image ? '<img class="prev" id="pv" src="' + esc(p.image) + '" alt="Main product preview"/>' : '<img class="prev" id="pv" style="display:none" alt="Main product preview"/>'}<div><b>Main photo</b><p>Use a sharp image with good lighting and minimal background clutter.</p></div></div>
              <div class="fld am-full"><label for="pu">Or paste the main image URL</label><input id="pu" value="${esc(p.image && p.image.indexOf('data:') !== 0 ? p.image : '')}" placeholder="https://example.com/product-image.jpg" oninput="PH.pLive()"/></div>
              <div class="am-gallery-block"><div class="am-gallery-head"><div><b>Product gallery</b><p>Add additional angles, packaging or details.</p></div><span class="am-gallery-count">${existingImages.length} saved</span></div><div class="am-existing-gallery" id="amExistingGallery">${galleryHtml}</div>
                <label class="am-dropzone" for="pfiles"><span class="am-drop-icon">⇧</span><b>Choose multiple images</b><small>Click to select more than one image at a time</small><input id="pfiles" type="file" accept="image/*" multiple onchange="PH.pfilesPreview(this)"/></label><div id="pnewgallery" class="am-new-gallery"></div>
              </div>
              <div class="am-secondary-image"><div class="fld"><label for="pu2">Optional second image URL</label><input id="pu2" value="${esc(p.image2 && p.image2.indexOf('data:') !== 0 ? p.image2 : '')}" placeholder="https://..."/></div><div class="fld"><label>Or upload second image</label><input type="file" accept="image/*" onchange="PH.pimg2(this)"/><img class="prev" id="pv2" ${p.image2 ? 'src="' + esc(p.image2) + '"' : 'style="display:none"'} alt="Second image preview"/></div></div>
              <label class="am-switch-row"><input id="pshow2" type="checkbox"${p.showSecondOnThumb === false ? '' : ' checked'}/><span><b>Show second image on product-card hover</b><small>Shoppers can see another view when they hover over the card.</small></span></label>
              <div class="fld am-full"><label for="pvid">Product video URL (optional)</label><input id="pvid" value="${esc(p.video || '')}" placeholder="Direct .mp4 link or uploaded video URL"/><small>Video upload may require Cloudinary configuration.</small><input type="file" accept="video/*" onchange="PH.vup(this)"/><small id="vst"></small></div>
            </section>
            <section class="am-product-section" id="amProdSales"><div class="am-section-heading"><span class="am-section-number">03</span><div><h3>Sales information</h3><p>Set the options, price and available stock for each variant.</p></div></div>
              <div class="am-price-highlight"><div><span>Sale price</span><b>PKR</b><small>Set price in the option rows below.</small></div><div class="fld"><label for="pold">Original price (optional)</label><input id="pold" type="number" min="0" step="1" value="${p.oldPrice || ''}" placeholder="0"/><small>Shown crossed out when higher than sale price.</small></div></div>
              <div class="am-variant-panel"><div class="am-variant-title"><div><b>Variants / options</b><p>Use one row per size, color, pack or other sellable option.</p></div><button type="button" class="btn sm" onclick="document.getElementById('vr').insertAdjacentHTML('beforeend',PH.vrow())">＋ Add variant</button></div>
                <div class="am-variant-labels"><span>Option name</span><span>Price (PKR)</span><span>Stock qty</span><span>Variant image URL</span><span>Upload image</span><span></span></div><div id="vr">${p.variants.map(vrow).join('')}</div>
                <small class="am-muted-help">Examples: Black / Medium, Blue / Large, Refill Comb. Stock can be left blank if you don't track it.</small>
              </div>
              <div class="g2"><div class="fld"><label for="pstock">Overall stock (optional)</label><input id="pstock" type="number" min="0" step="1" value="${p.stock == null ? '' : p.stock}" placeholder="Blank = not set"/></div><div class="fld"><label for="po">Display sort order</label><input id="po" type="number" value="${p.order || 0}"/><small>Smaller numbers appear earlier where sort order is used.</small></div></div>
              <div class="am-wholesale-grid"><div class="fld"><label for="pws">Wholesale price (PKR)</label><input id="pws" type="number" min="0" value="${p.ws || ''}" placeholder="Optional bulk price"/></div><div class="fld"><label for="pwm">Minimum wholesale quantity</label><input id="pwm" type="number" min="1" value="${p.wsMin || 10}"/></div><div class="fld"><label for="pcommission">Reseller commission (%)</label><input id="pcommission" type="number" min="0" max="100" step="0.1" value="${p.commissionPct == null ? '' : p.commissionPct}" placeholder="Use admin default"/><small>Leave blank to use the global reseller rule.</small></div></div>
            </section>
            <section class="am-product-section" id="amProdDelivery"><div class="am-section-heading"><span class="am-section-number">04</span><div><h3>Delivery &amp; product details</h3><p>Accurate weight and package details help with shipping estimates.</p></div></div>
              <div class="g2"><div class="fld"><label for="pweight">Product weight (grams)</label><input id="pweight" type="number" min="0" step="1" value="${p.weightGrams || ''}" placeholder="e.g. 350"/><small>Enter the packed item's weight in grams.</small></div><div class="fld"><label for="pwarranty">Warranty / guarantee</label><input id="pwarranty" value="${esc(p.warranty || '')}" placeholder="e.g. No warranty / 7-day seller warranty"/></div></div>
              <div class="am-dimensions"><b>Package dimensions (optional)</b><div class="g3"><div class="fld"><label for="plength">Length (cm)</label><input id="plength" type="number" min="0" step="0.1" value="${p.packageDimensions && p.packageDimensions.lengthCm || ''}" placeholder="L"/></div><div class="fld"><label for="pwidth">Width (cm)</label><input id="pwidth" type="number" min="0" step="0.1" value="${p.packageDimensions && p.packageDimensions.widthCm || ''}" placeholder="W"/></div><div class="fld"><label for="pheight">Height (cm)</label><input id="pheight" type="number" min="0" step="0.1" value="${p.packageDimensions && p.packageDimensions.heightCm || ''}" placeholder="H"/></div></div></div>
              <div class="note am-delivery-note">🚚 <b>Shipping note:</b> Weight and dimensions are stored with the product listing. Your current checkout delivery settings still control the actual delivery charge calculation.</div>
            </section>
            <section class="am-product-section" id="amProdPublish"><div class="am-section-heading"><span class="am-section-number">05</span><div><h3>Publish settings</h3><p>Choose where and how this product is displayed.</p></div></div>
              <div class="am-publish-options">${S.isAdmin ? `<label class="am-option-card"><input id="pa" type="checkbox"${p.active === false ? '' : ' checked'}/><span><b>Visible in shop</b><small>Customers can find and order this product.</small></span></label><label class="am-option-card"><input id="phot" type="checkbox"${p.hot ? ' checked' : ''}/><span><b>Most demanded</b><small>Highlight this item as a popular product.</small></span></label><label class="am-option-card"><input id="pnew" type="checkbox"${p.isNew ? ' checked' : ''}/><span><b>New arrival</b><small>Mark this item as a new product.</small></span></label>${S.isAdmin ? '<label class="am-option-card"><input id="phome" type="checkbox"' + (p.home ? ' checked' : '') + '/><span><b>Feature on home page</b><small>Show in the Featured Products area.</small></span></label>' : ''}` : `<label class="am-option-card"><input id="pa" type="checkbox" checked disabled/><span><b>Visible in shop</b><small>Goes live in the shop after the admin approves it.</small></span></label>`}</div>
              <div class="am-publish-note"><span>🔎</span><div><b>Before saving</b><p>Review your title, category, main photo, variant prices and stock. A product is published according to its visibility setting.</p></div></div>
            </section>
          </div>
        </div>
        <footer class="am-product-footer"><span>Changes are saved to your product database when you click Save.</span><div><button type="button" class="btn dk" onclick="PH.close()">Cancel</button><button class="btn" id="psave" type="button" onclick="PH.psave(${id ? "'" + id + "'" : 'null'})">${id ? 'Save changes' : 'Save product'}</button></div></footer>
      </div>`;
    modal(h);
    var mbox = document.querySelector('#modal .box'); if (mbox) mbox.classList.add('am-product-modal');
    PH.pLive();
  },
  vrow: function () { return vrow({}); },
  fx: function (mode) { var src = S.newImg || ($("#pv") && $("#pv").src); if (!src || src.indexOf("data:") !== 0) return toast("Upload an image from your device first"); fxImg(src, mode).then(function (d) { S.newImg = d; var v = $("#pv"); v.src = d; v.style.display = "block"; if ($('#pu')) $('#pu').value = ''; PH.pLive(); toast("Image updated"); }).catch(function (x) { toast(x.message || "Could not edit image"); }); },
  vup: function (inp) { var f = inp.files[0], C = CONFIG.cloudinary || {}; if (!f) return; if (!C.cloud) return toast("Add your Cloudinary cloud name and preset in CONFIG first"); $("#vst").textContent = "Uploading..."; var fd = new FormData(); fd.append("file", f); fd.append("upload_preset", C.preset); fetch("https://api.cloudinary.com/v1_1/" + C.cloud + "/video/upload", { method: "POST", body: fd }).then(function (r) { return r.json(); }).then(function (j) { if (!j.secure_url) throw new Error(j.error ? j.error.message : "Upload failed"); $("#pvid").value = j.secure_url; $("#vst").textContent = "Video uploaded"; }).catch(function (x) { $("#vst").textContent = x.message; }); },
  padd: function (e) { e.preventDefault(); var f = e.target; S.pagesList = (S.pagesList || []).concat([{ id: "p" + Date.now().toString(36), title: f.title.value.trim(), img: f.img.value.trim(), body: f.body.value }]); savePages(); },
  pgdel: function (id) { if (!confirm("Delete this page?")) return; S.pagesList = S.pagesList.filter(function (g) { return g.id !== id; }); savePages(); },
  chatTog: function () {
    var p = $("#cp"), open = p.style.display === "block"; p.style.display = open ? "none" : "block"; if (open) return;
    S.cql = faqList().filter(function (f) { return f.chat; }).slice(0, 8);
    $("#cq").innerHTML = S.cql.map(function (f, i) { return '<button type="button" class="qchip" onclick="PH.askQ(' + i + ')">' + esc(f.q) + '</button>'; }).join("");
    if (S.user && db) {
      if (S.chatUid !== S.user.uid) { if (S.chatOff) S.chatOff(); S.chatUid = S.user.uid;
        S.chatOff = db.collection("chats").doc(S.user.uid).onSnapshot(function (d) { var m = (d.exists && d.data().msgs) || []; if (!m.length) m = [{ f: "a", t: "Hi! Tap a question below or type your message." }]; $("#cm").innerHTML = m.map(function (x) { return bubble(x, "c"); }).join(""); $("#cm").scrollTop = 99999; }); }
    } else { $("#cm").innerHTML = bubble({ f: "a", t: "Hi! Tap a question below. To talk to our team, please log in." }, "c"); }
  },
  askQ: function (i) {
    var f = (S.cql || [])[i]; if (!f) return;
    if (!S.user || !db) { $("#cm").insertAdjacentHTML("beforeend", bubble({ f: "c", t: f.q }, "c") + bubble({ f: "a", t: f.a }, "c")); $("#cm").scrollTop = 99999; return; }
    var ms = Date.now(); db.collection("chats").doc(S.user.uid).set({ name: S.user.displayName || "", email: S.user.email, updatedMs: ms, msgs: firebase.firestore.FieldValue.arrayUnion({ f: "c", t: f.q, ms: ms }, { f: "a", t: f.a, ms: ms + 1, bot: 1 }) }, { merge: true }).catch(function (x) { toast(x.message); });
  },
  chatSend: function (e) { e.preventDefault(); var f = e.target, t = f.m.value.trim(); if (!t) return; if (!S.user || !db) { toast("Please log in to chat with our team"); location.hash = "#/login"; return; } f.m.value = ""; db.collection("chats").doc(S.user.uid).set({ name: S.user.displayName || "", email: S.user.email, updatedMs: Date.now(), msgs: firebase.firestore.FieldValue.arrayUnion({ f: "c", t: t, ms: Date.now() }) }, { merge: true }); },
  achat: function (e, id) { e.preventDefault(); var f = e.target, t = f.m.value.trim(); if (!t) return; db.collection("chats").doc(id).set({ updatedMs: Date.now(), msgs: firebase.firestore.FieldValue.arrayUnion({ f: "a", t: t, ms: Date.now() }) }, { merge: true }); },
  faqAdd: function (e) { e.preventDefault(); var f = e.target, q = f.q.value.trim(), a = f.a.value.trim(); if (!q || !a) return toast("Enter a question and an answer"); var l = faqList().slice(); l.push({ id: "f" + Date.now().toString(36), q: q, a: a, faq: f.onfaq.checked, chat: f.onchat.checked }); saveFaq(l); },
  faqTog: function (id, k) { var l = faqList().map(function (x) { var y = Object.assign({}, x); if (y.id === id) y[k] = !(y[k] !== false && y[k]); return y; }); saveFaq(l); },
  faqDel: function (id) { if (!confirm("Delete this question?")) return; saveFaq(faqList().filter(function (x) { return x.id !== id; })); },
  faqEdit: function (id) { var x = faqList().filter(function (y) { return y.id === id; })[0]; if (!x) return; modal('<h3 style="margin-bottom:12px">Edit question</h3><div class="fld"><label>Question</label><input id="eq" value="' + esc(x.q) + '"/></div><div class="fld"><label>Answer</label><textarea id="ea" rows="5">' + esc(x.a) + '</textarea></div><button class="btn" onclick="PH.faqUpd(\'' + id + '\')">Save</button>'); },
  faqUpd: function (id) { var q = $("#eq").value.trim(), a = $("#ea").value.trim(); if (!q || !a) return toast("Enter a question and an answer"); saveFaq(faqList().map(function (x) { var y = Object.assign({}, x); if (y.id === id) { y.q = q; y.a = a; } return y; })); closeModal(); },
  ssave: function (e) { e.preventDefault(); var f = e.target; S.site = { notice: f.notice.value.trim(), banner: f.banner.value.trim() }; db.collection("settings").doc("site").set(S.site).then(function () { toast("Saved"); }).catch(function (x) { toast(x.message); }); },
  rsetSave: function (e) { e.preventDefault(); if (!S.isAdmin) return toast("Admin access required"); var f=e.target, mn=Number(f.minProfit.value), mx=Number(f.maxProfit.value), cp=Number(f.commission.value); if (mx < mn) return toast("Maximum profit must be at least the minimum profit"); var d={commissionPct:cp,minProfit:mn,maxProfit:mx,rules:f.rules.value.trim(),updatedMs:Date.now()}; db.collection("settings").doc("reseller").set(d).then(function(){S.resellerSettings=d; CONFIG.commissionPct=cp; toast("Reseller settings saved"); drawAdmin();}).catch(function(x){toast("Could not save settings: "+x.message);}); },
  pimg2: function (inp) { var f = inp.files[0]; if (!f) return; compress(f, 500, .7).then(function (d) { S.newImg2 = d; var v = $("#pv2"); v.src = d; v.style.display = "block"; }).catch(function () { toast("Could not read this image"); }); },
  bulk: function (b) { var c = b.closest("[data-pid]"), pid = c.getAttribute("data-pid"), p = getP(pid), q = c.querySelector("[data-qty]");
    if (!S.user) { S.redirect = "product/" + pid; S.authTab = "register"; toast("Please register first for bulk orders"); location.hash = "#/login"; return; }
    if (!(S.isAdmin || (S.profile && S.profile.wholesale))) { toast("Wholesale prices need approval. Register as Business, then message us and we will approve you."); location.hash = "#/contact"; return; }
    var n = Math.max(+(q ? q.value : 1), p.wsMin || 10), f = null; S.cart.forEach(function (x) { if (x.pid === pid && x.size === "Wholesale") f = x; });
    if (f) f.qty = n; else S.cart.push({ pid: pid, size: "Wholesale", qty: n }); saveCart(); toast("Bulk order added: " + n + " pieces"); location.hash = "#/cart"; },
  hsearch: function (e) { e.preventDefault(); S.q = e.target.q.value.trim(); if (location.hash === "#/shop") drawShop(); else location.hash = "#/shop"; },
  setcat: function (c) { S.cat = c; drawShop(); },
  goCat: function (c) { S.cat = c; if (location.hash === "#/shop") drawShop(); else location.hash = "#/shop"; },
  catadd: function (e) {
    e.preventDefault(); var f = e.target, n = f.name.value.trim(); if (!n) return;
    if (CONFIG.categories.indexOf(n) > -1) return toast("This category already exists");
    CONFIG.categories.push(n); CONFIG.catEmoji = CONFIG.catEmoji || {}; if (f.emoji.value.trim()) CONFIG.catEmoji[n] = f.emoji.value.trim();
    saveCats().then(function () { toast("Category added"); drawAdmin(); }).catch(function (x) { toast(x.message); });
  },
  catdel: function (c) {
    if (!confirm("Delete category " + c + "? Products keep their category name.")) return;
    CONFIG.categories = CONFIG.categories.filter(function (x) { return x !== c; });
    saveCats().then(function () { toast("Category deleted"); drawAdmin(); }).catch(function (x) { toast(x.message); });
  },
  pnav: function (id, button) {
    var el = document.getElementById(id); if (!el) return;
    if (button && button.parentNode) { Array.prototype.forEach.call(button.parentNode.querySelectorAll('button'), function (b) { b.classList.remove('active'); }); button.classList.add('active'); }
    var steps = document.querySelector('.am-product-steps');
    if (steps) Array.prototype.forEach.call(steps.querySelectorAll('button'), function (b) { if (button !== b && b.getAttribute('onclick') && b.getAttribute('onclick').indexOf("'" + id + "'") > -1) b.classList.add('active'); });
    el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
  },
  pLive: function () {
    var name = $('#pn'), cat = $('#pcat'), price = document.querySelector('#vr .vp'), image = $('#pv'), liveName = $('#amProdLiveName'), liveCat = $('#amProdLiveCat'), livePrice = $('#amProdLivePrice'), liveImage = $('#amProdLiveImage'), placeholder = $('#amProdLivePlaceholder');
    if (liveName) liveName.textContent = name && name.value.trim() ? name.value.trim() : 'Your product name';
    if (liveCat) liveCat.textContent = cat && cat.value.trim() ? cat.value.trim() : 'Category';
    if (livePrice) livePrice.textContent = price && Number(price.value) > 0 ? fmt(Number(price.value)) : 'PKR 0';
    var src = S.newImg || ((($('#pu') && $('#pu').value.trim()) || '') || (image && image.src && image.style.display !== 'none' ? image.src : ''));
    if (liveImage && src) { liveImage.src = src; liveImage.style.display = 'block'; if (placeholder) placeholder.style.display = 'none'; }
  },
  pfilesPreview: function (inp) {
    var box = $('#pnewgallery'); if (!box) return; box.innerHTML = '';
    Array.prototype.forEach.call(Array.prototype.slice.call(inp.files || []).slice(0, 12), function (file) {
      var url = URL.createObjectURL(file), item = document.createElement('div'); item.className = 'am-new-img';
      var im = document.createElement('img'); im.src = url; im.alt = file.name || 'New product photo';
      var cap = document.createElement('span'); cap.textContent = file.name || 'New image';
      item.appendChild(im); item.appendChild(cap); box.appendChild(item);
    });
    if ((inp.files || []).length > 12) toast('The first 12 selected images will be processed.');
  },
  vimg: function (inp) {
    var file = inp.files && inp.files[0], row = inp.closest('.vrow'); if (!file || !row) return;
    var note = row.querySelector('.vimage-status'); if (note) note.textContent = 'Preparing image…';
    compress(file, 850, .78).then(function (data) {
      row.dataset.imageData = data; var prev = row.querySelector('.vimageprev');
      if (prev) { prev.src = data; prev.style.display = 'block'; }
      var urlInput = row.querySelector('.vimage'); if (urlInput) urlInput.value = '';
      if (note) note.textContent = 'Image ready';
    }).catch(function () { if (note) note.textContent = 'Could not read image'; toast('Could not read this variant image.'); });
  },
  pimg: function (inp) { var f = inp.files[0]; if (!f) return; compress(f, 700, .75).then(function (d) { S.newImg = d; var v = $("#pv"); v.src = d; v.style.display = "block"; if ($("#pu")) $("#pu").value = ""; PH.pLive(); }).catch(function () { err("Could not read this image.", "pmsg"); }); },
  psave: function (id) {
    var name = ($('#pn').value || '').trim(), vs = [], variantRows = document.querySelectorAll('#vr .vrow');
    Array.prototype.forEach.call(variantRows, function (r) {
      var s = (r.querySelector('.vs').value || '').trim(), pr = Number(r.querySelector('.vp').value), st = r.querySelector('.vstock'), im = r.querySelector('.vimage'), fileInput = r.querySelector('.vimagefile');
      if (s && pr > 0) vs.push({ size: s, price: pr, stock: st && st.value !== '' ? Math.max(0, Math.floor(Number(st.value))) : null, image: im ? im.value.trim() : '', imageData: r.dataset.imageData || '' });
    });
    if (!name) { PH.pnav('amProdBasic'); return err('Enter a product name.', 'pmsg'); }
    if (!($('#pcat').value || '').trim()) { PH.pnav('amProdBasic'); return err('Choose a product category.', 'pmsg'); }
    if (!vs.length) { PH.pnav('amProdSales'); return err('Add at least one variant with a valid price.', 'pmsg'); }
    if (vs.some(function (v) { return !isFinite(v.price) || v.price <= 0; })) { PH.pnav('amProdSales'); return err('Each variant needs a price greater than zero.', 'pmsg'); }
    var old = id ? getP(id) : null, url = ($('#pu').value || '').trim(), btn = $('#psave');
    btn.disabled = true; btn.textContent = 'Saving product...';
    var imgP = S.newImg ? storeImg(S.newImg, 'products') : Promise.resolve(url || (old && old.image ? old.image : ''));
    var extraFiles = Array.prototype.slice.call(($('#pfiles') && $('#pfiles').files) || []).slice(0, 12);
    var extraImagesP = Promise.all(extraFiles.map(function (file) { return compress(file, 1100, .8).then(function (data) { return storeImg(data, 'products'); }); }));
    var secondImageP = S.newImg2 ? storeImg(S.newImg2, 'products') : Promise.resolve((($('#pu2') && $('#pu2').value) || '').trim() || (old && old.image2) || '');
    var variantImagesP = Promise.all(vs.map(function (v) { return v.imageData ? storeImg(v.imageData, 'products').then(function (im) { return im; }) : Promise.resolve(v.image || ''); }));
    Promise.all([imgP, extraImagesP, secondImageP, variantImagesP]).then(function (all) {
      var img = all[0], extraImages = all[1] || [], secondImage = all[2] || '', variantImages = all[3] || [];
      var previousImages = old && Array.isArray(old.images) ? old.images : [];
      var allImages = [img].concat(previousImages, extraImages, [secondImage]).filter(function (x, i, a) { return x && a.indexOf(x) === i; });
      var finalVariants = vs.map(function (v, i) { return { size: v.size, price: v.price, stock: v.stock, image: variantImages[i] || '' }; });
      var d = {
        name: name, desc: ($('#pd').value || '').trim(), details: ($('#pdt').value || '').trim(), badge: ($('#pb').value || '').trim(),
        cat: ($('#pcat').value || '').trim(), sub: ($('#psub').value || '').trim(), brand: ($('#pbrand').value || '').trim(), searchKeywords: ($('#pkeywords').value || '').trim(),
        condition: ($('#pcondition') && $('#pcondition').value) || 'New', warranty: ($('#pwarranty').value || '').trim(),
        packageDimensions: { lengthCm: Number($('#plength').value) || 0, widthCm: Number($('#pwidth').value) || 0, heightCm: Number($('#pheight').value) || 0 },
        weightGrams: Math.max(0, Number($('#pweight').value) || 0),
        order: Number($('#po').value) || 0, active: S.isAdmin ? $('#pa').checked : false, owner: S.isAdmin ? ((old && old.owner) || '') : S.user.uid,
        image: img, images: allImages, image2: secondImage, commissionPct: $('#pcommission').value !== '' ? Number($('#pcommission').value) : null,
        showSecondOnThumb: !!$('#pshow2').checked, video: ($('#pvid').value || '').trim(), ws: Number($('#pws').value) || 0, wsMin: Number($('#pwm').value) || 10,
        hot: $('#phot') ? $('#phot').checked : !!(old && old.hot), isNew: $('#pnew') ? $('#pnew').checked : !!(old && old.isNew), home: S.isAdmin ? !!($('#phome') && $('#phome').checked) : false,
        variants: finalVariants, sku: ($('#psku').value || '').trim(), stock: $('#pstock').value === '' ? null : Math.max(0, Math.floor(Number($('#pstock').value))),
        oldPrice: Number($('#pold').value) || 0, updatedMs: Date.now()
      };
      return id ? db.collection('products').doc(id).set(d, { merge: true }) : db.collection('products').add(d);
    }).then(function () { toast('Product saved'); closeModal(); return loadProducts(); }).then(function () { drawAdmin(); drawAccount(); })
      .catch(function (x) { err('Save failed: ' + ((x && x.message) || x) + '. Check your Firebase Storage/Firestore permissions and try again.', 'pmsg'); btn.disabled = false; btn.textContent = id ? 'Save changes' : 'Save product'; });
  },
  pdel: function (id) { if (!confirm("Delete this product permanently?")) return; db.collection("products").doc(id).delete().then(function () { toast("Product deleted"); return loadProducts(); }).then(function () { drawAdmin(); drawAccount(); }).catch(function (x) { toast(x.message); }); },
  status: function (id, sel) {
    var o = S.adm.orders.filter(function (x) { return x.id === id; })[0]; if (!o) return;
    var hv = { s: sel.value, t: Date.now() };
    db.collection("orders").doc(id).update({ status: sel.value, updatedMs: hv.t, history: firebase.firestore.FieldValue.arrayUnion(hv) }).then(function () {
      o.status = sel.value; o.history = (o.history || []).concat([hv]); toast("Status updated to " + sel.value);
      sendMail(o.customer.email, "Your Online Shah Alami order " + o.orderNo + " is " + sel.value, "Hello " + o.customer.name + ",\n\nYour order " + o.orderNo + " is now: " + sel.value + ".\n\nTotal: " + fmt(o.total) + "\nQuestions? Call/WhatsApp " + SH.phone + ".\n\nThank you for choosing Online Shah Alami.", o.customer.name, mailVars(o, (STATUS_MAIL[sel.value] || ["Order update"])[0], "Hello " + o.customer.name.split(" ")[0] + ", " + ((STATUS_MAIL[sel.value] || [0, "your order status is now " + sel.value + "."])[1])));
    }).catch(function (x) { toast(x.message); });
  },
  odelSave: function (id) {
    var o = S.adm.orders.filter(function (x) { return x.id === id; })[0]; if (!o) return;
    var v = Math.round(Number($("#odel").value)); if (isNaN(v) || v < 0) return toast("Enter a valid delivery charge (0 or more).");
    var tot = (Number(o.subtotal) || 0) - (Number(o.discount) || 0) + v, mail = $("#odelm") && $("#odelm").checked;
    db.collection("orders").doc(id).update({ delivery: v, total: tot, deliveryEditedMs: Date.now() }).then(function () {
      o.delivery = v; o.total = tot; drawAdmin(); PH.oview(id); toast("Delivery charge saved. New total " + fmt(tot));
      if (mail) sendMail(o.customer.email, "Delivery charge updated for order " + o.orderNo, "The delivery charge for your order " + o.orderNo + " was updated. New total: " + fmt(tot), o.customer.name, mailVars(o, "Delivery charge updated", "the delivery charge for your order has been updated. Your new total is " + fmt(tot) + "."));
    }).catch(function (x) { toast(x.message); });
  },
  oview: function (id) {
    var o = S.adm.orders.filter(function (x) { return x.id === id; })[0]; if (!o) return;
    modal('<h3 style="margin-bottom:12px">Order ' + o.orderNo + '</h3><pre style="white-space:pre-wrap;font-family:inherit;background:#F7F9FB;border:1px solid var(--line);border-radius:14px;padding:16px">' + esc(orderText(o)) + '</pre>' +
      (o.screenshot ? '<h4 style="margin:14px 0 6px">Payment screenshot</h4><img src="' + esc(o.screenshot) + '" style="max-height:420px;border-radius:12px;border:1px solid var(--line)" alt="Payment screenshot"/>' : "") +
      '<div class="note" style="margin-top:16px"><b>Delivery charge for this order</b><div class="row" style="gap:10px;margin-top:8px;flex-wrap:wrap"><input class="inp" id="odel" type="number" min="0" value="' + (o.delivery || 0) + '" style="max-width:160px"/><button class="btn sm" onclick="PH.odelSave(\'' + id + '\')">Save delivery charge</button></div><label style="display:flex;gap:8px;align-items:center;margin-top:10px;font-size:.9rem"><input type="checkbox" id="odelm" style="width:auto"/> Email the customer the new total</label><div class="fine" style="text-align:left;margin-top:6px">Subtotal ' + fmt(o.subtotal) + (o.discount ? " - discount " + fmt(o.discount) : "") + ' + delivery = total. Saving updates the order total and your revenue.</div></div>' +
      '<div class="note" style="margin-top:16px"><b>Payment status: ' + esc(o.paymentStatus || "Not recorded") + '</b><div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn sm" onclick="PH.paystat(\'' + id + '\',\'Verified\')">Mark verified</button><button class="btn dk sm" onclick="PH.paystat(\'' + id + '\',\'Pending verification\')">Pending</button><button class="btn red sm" onclick="PH.paystat(\'' + id + '\',\'Failed\')">Mark failed</button></div></div>' +
      '<div class="row" style="margin-top:16px"><a class="btn sm" target="_blank" rel="noopener" href="https://wa.me/' + String(o.customer.phone).replace(/^0/, "92").replace(/^\+/, "") + '">WhatsApp customer</a></div>');
  },
  odel: function (id) { if (!confirm("Delete this order permanently?")) return; db.collection("orders").doc(id).delete().then(function () { S.adm.orders = S.adm.orders.filter(function (o) { return o.id !== id; }); drawAdmin(); toast("Order deleted"); }).catch(function (x) { toast(x.message); }); },
  paystat: function (id, v) { var o = S.adm.orders.filter(function (x) { return x.id === id; })[0]; if (!o) return; db.collection("orders").doc(id).update({ paymentStatus: v, paymentCheckedMs: Date.now() }).then(function () { o.paymentStatus = v; drawAdmin(); PH.oview(id); toast("Payment marked: " + v); }).catch(function (x) { toast(x.message); }); },
  accTab: function (t) { S.accTab = t; drawAccount(); },
  ofil: function (v) { S.of = v; drawOrdersList(); },
  profSave: function (e) { e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var f = e.target, d = { name: f.name.value.trim(), phone: f.phone.value.trim(), city: f.city.value.trim(), address: f.address.value.trim() }, box = $("#pfmsg"); if (!d.name || !d.phone) { box.innerHTML = '<div class="msg err">Name and phone are required.</div>'; return; }
    if (!S.profile) { d.email = S.user.email; d.type = "customer"; d.wholesale = false; d.createdMs = Date.now(); }
    var btn = f.querySelector("button[type=submit]"); btn.disabled = true;
    db.collection("users").doc(S.user.uid).set(d, { merge: true }).then(function () { return S.user.updateProfile({ displayName: d.name }); }).then(function () { S.profile = Object.assign({}, S.profile || {}, d); box.innerHTML = '<div class="msg ok">Saved.</div>'; btn.disabled = false; hdr(); }).catch(function (x) { box.innerHTML = '<div class="msg err">' + esc(nice(x)) + '</div>'; btn.disabled = false; }); },
  pwReset: function () { if (!FB_OK || !S.user) return needFB(); auth.sendPasswordResetEmail(S.user.email).then(function () { toast("Reset email sent to " + S.user.email + ". Check Spam too."); }).catch(function (x) { toast(nice(x)); }); },
  reorder: function (id) { var o = (S.myo || []).filter(function (x) { return x.id === id; })[0]; if (!o) return; var n = 0, sk = 0;
    o.items.forEach(function (i) { var p = getP(i.pid); if (!p || p.active === false || oos(p)) { sk++; return; }
      if (i.size === "Wholesale") { if (!(p.ws && S.profile && S.profile.wholesale)) { sk++; return; } } else if (!p.variants.some(function (v) { return v.size === i.size; })) { sk++; return; }
      var f = null; S.cart.forEach(function (c) { if (c.pid === i.pid && c.size === i.size) f = c; }); if (f) f.qty += i.qty; else S.cart.push({ pid: i.pid, size: i.size, qty: i.qty }); n++; });
    saveCart(); toast(n ? n + " item(s) added to cart" + (sk ? " (" + sk + " not available)" : "") : "These items are no longer available"); if (n) location.hash = "#/cart"; },
  wsFilter: function (v) { v = v.trim().toLowerCase(); document.querySelectorAll("#wst tr[data-n]").forEach(function (r) { r.style.display = r.getAttribute("data-n").indexOf(v) > -1 ? "" : "none"; }); },
  wsAll: function () { var n = 0; S.products.forEach(function (p) { if (!p.ws || oos(p)) return; var el = $("#wq_" + p.id), mn = p.wsMin || 10, q = Math.max(mn, Math.floor(+(el ? el.value : mn)) || mn), f = null; S.cart.forEach(function (x) { if (x.pid === p.id && x.size === "Wholesale") f = x; }); if (f) f.qty = q; else S.cart.push({ pid: p.id, size: "Wholesale", qty: q }); n++; }); saveCart(); toast(n + " products added to cart"); if (n) location.hash = "#/cart"; },
  wsQuote: function (e) { e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var f = e.target, pr = S.profile || {}, btn = f.querySelector("button[type=submit]"), m = { name: pr.name || S.user.displayName || "", phone: pr.phone || "", email: S.user.email, message: "[WHOLESALE QUOTE] " + f.item.value.trim() + " | Qty: " + f.qty.value + (f.note.value.trim() ? " | " + f.note.value.trim() : ""), createdMs: Date.now() }; btn.disabled = true;
    db.collection("messages").add(m).then(function () { f.reset(); btn.disabled = false; toast("Quote request sent. We will contact you soon."); sendMail(SH.email, "Wholesale quote request from " + m.name, m.message + "\nPhone: " + m.phone + "\nEmail: " + m.email, "Online Shah Alami"); }).catch(function (x) { btn.disabled = false; toast(nice(x)); }); },
  payout: function (e) { e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var f = e.target, pr = S.profile || {}, amt = Number(f.amt.value), btn = f.querySelector("button[type=submit]");
    if (!(amt > 0)) return toast("Enter an amount"); if (S.rAvail != null && amt > S.rAvail) return toast("Amount is more than your available commission (" + fmt(S.rAvail) + ")");
    var m = { name: pr.name || S.user.displayName || "", phone: pr.phone || "", email: S.user.email, message: "[PAYOUT REQUEST] Reseller ID: " + (pr.refCode || "-") + " | Amount: " + fmt(amt) + " | " + f.method.value + ": " + f.acct.value.trim(), createdMs: Date.now() }; btn.disabled = true;
    db.collection("messages").add(m).then(function () { f.reset(); btn.disabled = false; toast("Payout request sent. We will contact you soon."); sendMail(SH.email, "Reseller payout request from " + m.name, m.message + "\nPhone: " + m.phone + "\nEmail: " + m.email, "Online Shah Alami"); }).catch(function (x) { btn.disabled = false; toast(nice(x)); }); },
  rcopy: function (id) { var u = rlink(id); if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(u).then(function () { toast("Link copied"); }, function () { prompt("Copy this link", u); }); else prompt("Copy this link", u); },
  rwa: function (id) { var p = getP(id); if (p) window.open("https://wa.me/?text=" + encodeURIComponent(p.name + " - " + rlink(id)), "_blank"); },
  rexport: function () { xl((S.rrows || []).map(function (x) { var cm = 0; x.items.forEach(function (i) { cm += i.comm || 0; }); return { "Order No": x.o.orderNo, Date: new Date(x.o.createdMs).toLocaleString(), Items: x.items.map(function (i) { return i.name + " (" + i.size + ") x" + i.qty; }).join("; "), Commission: cm, Status: x.o.status }; }), "AnasMart_Reseller_Statement"); },
  reqAccess: function (k) { if (!FB_OK || !S.user) return needFB(); db.collection("users").doc(S.user.uid).set({ requestedType: k }, { merge: true }).then(function () { S.profile = Object.assign({}, S.profile || {}, { requestedType: k }); toast("Request sent. We will approve your account soon."); drawAccount(); sendMail(SH.email, "Access request: " + k, "User " + S.user.email + " requested " + (k === "business" ? "wholesale" : "reseller") + " access. Approve it in Admin > Customers.", "Online Shah Alami"); }).catch(function (x) { toast(x.message); }); },
  wsAdd: function (pid) { var p = getP(pid), el = $("#wq_" + pid), mn = p.wsMin || 10, n = Math.max(mn, Math.floor(+(el ? el.value : mn)) || mn), f = null; S.cart.forEach(function (x) { if (x.pid === pid && x.size === "Wholesale") f = x; }); if (f) f.qty = n; else S.cart.push({ pid: pid, size: "Wholesale", qty: n }); saveCart(); toast("Added " + n + " pieces: " + p.name); },
  wsExport: function () { xl(S.products.filter(function (p) { return p.ws; }).map(function (p) { return { Product: p.name, Category: p.cat || "", "Retail price": minP(p), "Wholesale price": p.ws, "Minimum qty": p.wsMin || 10 }; }), "AnasMart_Wholesale_Prices"); },
  uaccess: function (id, kind, val) { var u = S.adm.users.filter(function (x) { return x.id === id; })[0]; if (!u) return; var d = kind === "wholesale" ? { wholesale: val } : { type: val ? "reseller" : "customer" }; if (kind === "reseller" && val) d.refCode = "AM" + id.slice(0, 6).toUpperCase(); db.collection("users").doc(id).update(d).then(function () { for (var k in d) u[k] = d[k]; drawAdmin(); toast("Access updated"); }).catch(function (x) { toast(x.message); }); },
  mdel: function (id) { if (!confirm("Delete this message?")) return; db.collection("messages").doc(id).delete().then(function () { S.adm.messages = S.adm.messages.filter(function (m) { return m.id !== id; }); drawAdmin(); }).catch(function (x) { toast(x.message); }); },
  exportOrders: function () {
    xl(S.adm.orders.filter(function (o) { return S.adm.filter === "all" || o.status === S.adm.filter; }).map(function (o) {
      return { "Order No": o.orderNo, "Date": new Date(o.createdMs).toLocaleString(), "Customer": o.customer.name, "Phone": o.customer.phone, "Email": o.customer.email, "City": o.customer.city, "Address": o.customer.address,
        "Items": o.items.map(function (i) { return i.name + " (" + i.size + ") x" + i.qty; }).join("; "), "Subtotal": o.subtotal, "Delivery": o.delivery, "Total": o.total, "Payment": o.paymentMethod, "Transaction ID": o.txnId || "", "Status": o.status, "Notes": o.customer.notes || "" }; }), "AnasMart_Orders");
  },
  exportUsers: function () { xl(S.adm.users.map(function (u) { return { Name: u.name, Email: u.email, Phone: u.phone, Joined: u.createdMs ? new Date(u.createdMs).toLocaleString() : "" }; }), "AnasMart_Customers"); },
  exportMsgs: function () { xl(S.adm.messages.map(function (m) { return { Date: new Date(m.createdMs).toLocaleString(), Name: m.name, Email: m.email, Phone: m.phone, Message: m.message }; }), "AnasMart_Messages"); }
};

/* ---------- start ---------- */
shell(); hdr();
window.addEventListener("hashchange", render);
try { var pc = JSON.parse(localStorage.getItem("am_pc") || "null"); if (pc && pc.length) { S.stored = true; S.all = pc; S.products = pc.filter(function (p) { return p.active !== false; }); if (!location.hash) location.hash = "#/home"; render(); } } catch (e) {}
Promise.all([loadProducts(), loadSettings(), loadFaq()]).then(function () { if (!location.hash) location.hash = "#/home"; render(); });
if (FB_OK) {
  auth.onAuthStateChanged(function (u) {
    S.user = u; S.isAdmin = !!u && CONFIG.adminEmails.map(function (x) { return x.toLowerCase(); }).indexOf((u.email || "").toLowerCase()) > -1; S.profile = null;
    var done = function () { hdr(); render(); };
    if (S.pu) { S.pu(); S.pu = null; }
    if (u) { var first = true; S.pu = db.collection("users").doc(u.uid).onSnapshot(function (d) { var old = S.profile, nw = d.exists ? d.data() : null; S.profile = nw;
        if (first) { first = false; done(); return; }
        hdr(); if (!nw) return;
        var chg = !old || old.wholesale !== nw.wholesale || old.type !== nw.type || old.requestedType !== nw.requestedType;
        if (old && (old.wholesale !== nw.wholesale || old.type !== nw.type)) toast("Your account access was updated");
        if (chg && /^#\/(account|cart|product|shop|home|wishlist)?$/.test(location.hash || "#/")) render();
      }, function () { if (first) { first = false; done(); } }); }
    else { S.adm.loaded = false; done(); }
  });
}
/* ===== EXTRA RESELLER + WHOLESALE TOOLS (added) ===== */
var RLEVELS = [["🌱 Starter", 0], ["🥈 Silver", 50000], ["🥇 Gold", 200000], ["💎 Platinum", 500000]];
function wsCartLine() {
  var n = 0, t = 0; S.cart.forEach(function (c) { if (c.size !== "Wholesale") return; var p = getP(c.pid); if (!p) return; n += c.qty; t += c.qty * slabPrice("Wholesale", c.qty, p.ws || 0); });
  var el = $("#wscart"); if (el) el.innerHTML = n ? "🛒 Wholesale in cart: <b>" + n + " pcs</b> · <b>" + fmt(t) + "</b> &nbsp;<a class=\"btn sm\" href=\"#/cart\">Checkout</a>" : "Your wholesale cart is empty.";
}
function wsApply() {
  var q = S.wsQ || "", c = S.wsCat || "";
  document.querySelectorAll("#wst tr[data-n]").forEach(function (r) { var ok = r.getAttribute("data-n").indexOf(q) > -1 && (!c || r.getAttribute("data-c") === c); r.style.display = ok ? "" : "none"; });
}
var _dWs = drawWholesale;
drawWholesale = function () {
  _dWs(); var pr = S.profile || {}; var tbl = $("#wst"); if (!pr.wholesale || !tbl) return;
  var cats = [], byName = {}; S.products.forEach(function (p) { if (p.ws) { byName[p.name.toLowerCase()] = p; if (p.cat && cats.indexOf(p.cat) < 0) cats.push(p.cat); } });
  tbl.querySelectorAll("tr[data-n]").forEach(function (r) { var p = byName[r.getAttribute("data-n")]; r.setAttribute("data-c", p && p.cat ? p.cat : ""); });
  S.wsQ = ""; S.wsCat = "";
  var html = '<div class="card" style="margin-bottom:20px"><h3 style="margin-bottom:10px">⚡ Quick order</h3><div class="note" style="margin-bottom:12px">' + slabText() + '</div><div id="wscart" style="margin-bottom:12px"></div>' +
    '<div class="chips2" id="wscats"><button class="on" onclick="PH.wsCat(\'\',this)">All</button>' + cats.map(function (c) { return '<button onclick="PH.wsCat(\'' + esc(c).replace(/'/g, "") + '\',this)">' + esc(c) + '</button>'; }).join("") + '</div>' +
    '<div class="row" style="gap:8px;margin-bottom:12px"><label style="font-weight:600">Sort:</label><select class="inp" style="max-width:220px;padding:8px 12px" onchange="PH.wsSort(this.value)"><option value="name">Name A-Z</option><option value="save">Biggest saving</option><option value="low">Lowest wholesale price</option></select></div>' +
    '<div class="fld"><label>Paste a list: one product per line as <i>name, quantity</i></label><textarea id="wsq" rows="3" placeholder="Example:\nBlue T-Shirt, 50\nWireless Earbuds, 20"></textarea></div><button class="btn sm" onclick="PH.wsQuick()">Add list to cart</button></div>';
  tbl.parentNode.insertAdjacentHTML("beforebegin", html); wsCartLine();
};
var _wsAdd = PH.wsAdd, _wsAll = PH.wsAll;
PH.wsAdd = function (id) { _wsAdd(id); wsCartLine(); };
PH.wsAll = function () { _wsAll(); wsCartLine(); };
PH.wsFilter = function (v) { S.wsQ = String(v || "").trim().toLowerCase(); wsApply(); };
PH.wsCat = function (c, btn) { S.wsCat = c; document.querySelectorAll("#wscats button").forEach(function (b) { b.className = b === btn ? "on" : ""; }); wsApply(); };
PH.wsSort = function (m) {
  var tbl = $("#wst"); if (!tbl) return; var rows = [].slice.call(tbl.querySelectorAll("tr[data-n]")), byName = {};
  S.products.forEach(function (p) { byName[p.name.toLowerCase()] = p; });
  function sv(r) { var p = byName[r.getAttribute("data-n")]; if (!p) return 0; var x = minP(p); return x > p.ws ? (x - p.ws) / x : 0; }
  function ws(r) { var p = byName[r.getAttribute("data-n")]; return p ? p.ws : 0; }
  rows.sort(function (a, b) { return m === "save" ? sv(b) - sv(a) : m === "low" ? ws(a) - ws(b) : a.getAttribute("data-n") < b.getAttribute("data-n") ? -1 : 1; });
  rows.forEach(function (r) { tbl.appendChild(r); });
};
PH.wsQuick = function () {
  var ta = $("#wsq"); if (!ta) return; var added = 0, miss = [];
  ta.value.split(/\n+/).forEach(function (ln) {
    ln = ln.trim(); if (!ln) return; var m = ln.match(/^(.*?)[\s,;:\t]+(\d+)\s*$/), name = (m ? m[1] : ln).trim().toLowerCase(), qty = m ? +m[2] : 0, hit = null;
    S.products.forEach(function (p) { if (!p.ws || oos(p)) return; var n = p.name.toLowerCase(); if (n === name) hit = p; else if (!hit && name && n.indexOf(name) > -1) hit = p; });
    if (!hit) { miss.push(ln); return; }
    var q = Math.max(hit.wsMin || 10, qty || 0), f = null; S.cart.forEach(function (x) { if (x.pid === hit.id && x.size === "Wholesale") f = x; });
    if (f) f.qty = q; else S.cart.push({ pid: hit.id, size: "Wholesale", qty: q }); added++;
  });
  saveCart(); wsCartLine();
  toast(added + " product(s) added" + (miss.length ? " · not found: " + miss.slice(0, 3).join(", ") : ""));
};

var _dRes = drawReseller;
drawReseller = function () {
  S.rrows = null; _dRes();
  if ((S.profile || {}).type !== "reseller") return;
  var tries = 0, t = setInterval(function () {
    if (++tries > 40) return clearInterval(t);
    if (!S.rrows) return; clearInterval(t);
    var anchor = $("#rstat"); if (!anchor) return; var old = $("#rx"); if (old) old.remove();
    var sales = 0, cnt = {}, mon = {}, pr = S.profile || {};
    S.rrows.forEach(function (x) { var st = x.o.status || "Pending"; cnt[st] = (cnt[st] || 0) + 1; if (st === "Cancelled") return;
      x.items.forEach(function (i) { sales += (i.price || 0) * (i.qty || 0); var k = new Date(x.o.createdMs); k = k.getFullYear() + "-" + ("0" + (k.getMonth() + 1)).slice(-2); mon[k] = (mon[k] || 0) + (i.comm || 0); }); });
    var li = 0; RLEVELS.forEach(function (l, i) { if (sales >= l[1]) li = i; });
    var nx = RLEVELS[li + 1], pct = nx ? Math.min(100, Math.round((sales - RLEVELS[li][1]) * 100 / (nx[1] - RLEVELS[li][1]))) : 100;
    var keys = []; for (var m = 5; m >= 0; m--) { var d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - m); keys.push(d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2)); }
    var mx = Math.max.apply(null, keys.map(function (k) { return mon[k] || 0; }).concat([1]));
    var bars = '<div class="bars">' + keys.map(function (k) { var v = mon[k] || 0; return '<div class="c"><span class="v">' + (v ? fmt(v) : "") + '</span><i style="height:' + Math.max(4, Math.round(v * 100 / mx)) + '%"></i>' + k.slice(2) + '</div>'; }).join("") + '</div>';
    var live = S.products.filter(function (p) { return p.active !== false; }).slice(0, 40);
    var calc = '<div class="card" style="margin-bottom:18px"><h3 style="margin-bottom:4px">🧮 My selling price &amp; profit calculator</h3><p style="color:var(--mut);margin-bottom:10px">Cost = wholesale price (or retail price if none). Type your own selling price to see your profit, then share it with your customer on WhatsApp.</p><div class="tw"><table><tr><th>Product</th><th>Cost</th><th>My price</th><th>Profit / pc</th><th></th></tr>' +
      live.map(function (p) { var c = p.ws || minP(p); return '<tr><td><b>' + esc(p.name) + '</b></td><td>' + fmt(c) + '</td><td><input class="inp" id="rp_' + p.id + '" type="number" min="0" style="max-width:120px;padding:6px 10px" oninput="PH.rcalc(\'' + p.id + '\')"/></td><td class="pftv" id="rpf_' + p.id + '">-</td><td><button class="btn sm" onclick="PH.rshare(\'' + p.id + '\')">Share</button></td></tr>'; }).join("") + '</table></div></div>';
    var box = document.createElement("div"); box.id = "rx";
    box.innerHTML = '<div class="rxg"><div class="card"><div class="lvl"><span class="ic">' + RLEVELS[li][0].split(" ")[0] + '</span><div><h3>' + RLEVELS[li][0].split(" ")[1] + ' reseller</h3><small style="color:var(--mut)">Total sales: ' + fmt(sales) + '</small></div></div><div class="prog"><i style="width:' + pct + '%"></i></div><small style="color:var(--mut)">' + (nx ? fmt(nx[1] - sales) + " more sales to reach " + nx[0] : "Top level reached. Great work!") + '</small>' +
      '<div class="row" style="gap:6px;margin-top:12px">' + ["Pending", "Shipped", "Delivered", "Cancelled"].map(function (s) { return '<span class="st">' + s + ': ' + (cnt[s] || 0) + '</span>'; }).join("") + '</div></div>' +
      '<div class="card"><h3 style="margin-bottom:6px">Commission, last 6 months</h3>' + bars + '</div></div>' + calc +
      '<div class="card" style="margin-bottom:18px"><h3 style="margin-bottom:8px">📣 Promote my store</h3><div class="row" style="gap:8px"><button class="btn sm" onclick="PH.rstore(0)">Copy store link</button><button class="btn dk sm" onclick="PH.rstore(1)">Share on WhatsApp</button></div></div>';
    anchor.insertAdjacentElement("afterend", box);
  }, 400);
};
PH.rcalc = function (id) {
  var p = getP(id), el = $("#rp_" + id), out = $("#rpf_" + id); if (!p || !el || !out) return; var v = Number(el.value);
  if (!el.value) { out.textContent = "-"; out.className = "pftv"; return; }
  var d = v - (p.ws || minP(p)), rs = S.resellerSettings || CONFIG.resellerDefaults || {}, mn = Number(rs.minProfit || 0), mx = Number(rs.maxProfit == null ? 100000 : rs.maxProfit); out.textContent = fmt(d) + (d < mn ? " · below minimum" : d > mx ? " · above maximum" : ""); out.className = "pftv" + (d < mn || d > mx ? " neg" : "");
};
PH.rshare = function (id) {
  var p = getP(id), el = $("#rp_" + id); if (!p) return; var v = el && el.value ? Number(el.value) : minP(p), pr = S.profile || {};
  window.open("https://wa.me/?text=" + encodeURIComponent(p.name + " - " + fmt(v) + "\n" + rlink(id) + (pr.refCode ? "\nReseller ID: " + pr.refCode : "")), "_blank");
};
PH.rstore = function (wa) {
  var u = location.href.split("#")[0], pr = S.profile || {}, txt = "Shop on Online Shah Alami: " + u + (pr.refCode ? "  (Reseller ID: " + pr.refCode + ")" : "");
  if (wa) return void window.open("https://wa.me/?text=" + encodeURIComponent(txt), "_blank");
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(u).then(function () { toast("Store link copied"); }, function () { prompt("Copy this link", u); }); else prompt("Copy this link", u);
};

/* ===== SLABS + RESELLER-PRICED ORDERS + PAYOUT HISTORY (added) ===== */
function slabList() { return CONFIG.wsSlabs || [[50, 3], [100, 5], [250, 8]]; }
function slabPrice(size, qty, base) { if (size !== "Wholesale") return base; var off = 0; slabList().forEach(function (s) { if (qty >= s[0]) off = s[1]; }); return Math.round(base * (1 - off / 100)); }
function slabText() { return "Bulk slab discount on wholesale lines: " + slabList().map(function (s) { return s[0] + "+ pcs = " + s[1] + "% off"; }).join(" · "); }
function roCost(p) { return p.ws || minP(p); }
function roSize(p) { var b = p.variants[0]; p.variants.forEach(function (v) { if (Number(v.price) < Number(b.price)) b = v; }); return b.size; }
function roDraw() {
  var el = $("#rolines"); if (!el) return; var tot = 0, pf = 0; S.ro = S.ro || [];
  el.innerHTML = S.ro.length ? '<div class="tw"><table><tr><th>Product</th><th>Qty</th><th>My price</th><th>Profit</th><th></th></tr>' + S.ro.map(function (l, i) { var p = getP(l.pid), g = (l.price - roCost(p)) * l.qty; tot += l.price * l.qty; pf += g; return '<tr><td>' + esc(p.name) + '</td><td>' + l.qty + '</td><td>' + fmt(l.price) + '</td><td class="pftv">' + fmt(g) + '</td><td><button class="x" type="button" onclick="PH.roDel(' + i + ')">✕</button></td></tr>'; }).join("") + '</table></div><p style="margin-top:8px">Customer pays (before delivery): <b>' + fmt(tot) + '</b> · Your profit: <b class="pftv">' + fmt(pf) + '</b></p>' : '<p style="color:var(--mut)">No items yet.</p>';
}
PH.roAdd = function () {
  var p = getP($("#ro_p").value), q = Math.max(1, Math.floor(+$("#ro_q").value) || 1), pr = Number($("#ro_pr").value); if (!p) return;
  var profit = pr - roCost(p), rs = S.resellerSettings || CONFIG.resellerDefaults || {}, minProfit = Number(rs.minProfit || 0), maxProfit = Number(rs.maxProfit == null ? 100000 : rs.maxProfit);
  if (profit < minProfit) return toast("Profit must be at least " + fmt(minProfit) + " per product.");
  if (profit > maxProfit) return toast("Profit cannot exceed " + fmt(maxProfit) + " per product.");
  S.ro = S.ro || []; var f = null; S.ro.forEach(function (l) { if (l.pid === p.id) f = l; }); if (f) { f.qty += q; f.price = pr; } else S.ro.push({ pid: p.id, qty: q, price: pr });
  $("#ro_pr").value = ""; roDraw();
};
PH.roDel = function (i) { S.ro.splice(i, 1); roDraw(); };
PH.roPlace = function (e) {
  e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var f = e.target; S.ro = S.ro || [];
  if (CONFIG.serverOrders) return toast("Reseller-priced orders need serverOrders:false (or an updated placeOrder function).");
  var ph = f.phone.value.replace(/[\s-]/g, ""); if (!/^(?:\+?92|0)?3\d{9}$/.test(ph)) return toast("Enter a valid customer mobile number, e.g. 03XXXXXXXXX.");
  if (!S.ro.length) return toast("Add at least one product.");
  var sub = 0, prof = 0, oldCart = S.cart, rs = S.resellerSettings || CONFIG.resellerDefaults || {}, minProfit = Number(rs.minProfit || 0), maxProfit = Number(rs.maxProfit == null ? 100000 : rs.maxProfit); if (S.ro.some(function(l){var p=getP(l.pid);var per=Number(l.price)-roCost(p);return per<minProfit||per>maxProfit;})) return toast("One or more product profits are outside the admin-set limits."); var items = S.ro.map(function (l) { var p = getP(l.pid), c = roCost(p); sub += l.price * l.qty; prof += (l.price - c) * l.qty; return { pid: p.id, name: p.name, size: roSize(p), qty: l.qty, price: l.price, owner: S.user.uid, comm: Math.round((l.price - c) * l.qty), cost: c, resold: true }; });
  S.city = f.city.value.trim(); S.cart = items.map(function (i) { return { pid: i.pid, size: i.size, qty: i.qty }; }); var del = deliveryFor(sub); S.cart = oldCart;
  var btn = f.querySelector("button[type=submit]"); btn.disabled = true;
  var pr = S.profile || {}, o = { orderNo: "AM-" + Date.now().toString(36).toUpperCase(), userId: S.user ? S.user.uid : "guest", userEmail: (S.user && S.user.email) || "",
    customer: { name: f.name.value.trim(), phone: ph, email: S.user.email, city: S.city, address: f.address.value.trim(), notes: "Reseller order. Reseller ID: " + (pr.refCode || "-") },
    items: items, owners: [S.user.uid], subtotal: sub, delivery: del, discount: 0, coupon: "", total: sub + del, paymentMethod: "Cash on Delivery", txnId: "", screenshot: "", status: "Pending", paymentStatus: "Pay on delivery", createdMs: Date.now(), history: [{ s: "Pending", t: Date.now() }], resold: true, resellerId: S.user.uid, resellerProfit: Math.round(prof) };
  db.collection("orders").add(o).then(function () { S.ro = []; btn.disabled = false; toast("Order " + o.orderNo + " placed. Profit " + fmt(prof) + " is paid after delivery.");
    sendMail(SH.email, "RESELLER ORDER " + o.orderNo + " - " + fmt(o.total), orderText(o), "Online Shah Alami", mailVars(o, "New reseller order", "a reseller order was placed for " + o.customer.name + "."));
    drawReseller(); }).catch(function (x) { btn.disabled = false; toast(nice(x)); });
};
function rpDraw() {
  var el = $("#rpay"); if (!el || !S.rPays) return; var held = 0; S.rPays.forEach(function (p) { if (p.status !== "Rejected") held += p.amount || 0; });
  S.rNet = Math.max(0, (S.rAvail || 0) - held); var av = $("#ravail"); if (av) av.innerHTML = 'Available to withdraw: <b>' + fmt(S.rNet) + '</b> <small>(delivered commission minus payouts)</small>';
  el.innerHTML = S.rPays.length ? '<div class="tw"><table><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr>' + S.rPays.map(function (p) { return '<tr><td>' + new Date(p.createdMs).toLocaleDateString() + '</td><td><b>' + fmt(p.amount) + '</b></td><td>' + esc(p.method) + ': ' + esc(p.acct) + '</td><td><span class="st">' + esc(p.status) + '</span></td></tr>'; }).join("") + '</table></div>' : '<p style="color:var(--mut)">No payout requests yet.</p>';
}
function loadRPays() {
  if (!FB_OK || !S.user) return;
  db.collection("payouts").where("uid", "==", S.user.uid).get().then(function (q) { var a = []; q.forEach(function (d) { var o = d.data(); o.id = d.id; a.push(o); }); a.sort(function (x, y) { return y.createdMs - x.createdMs; }); S.rPays = a; rpDraw(); })
    .catch(function (e) { S.rPays = null; var el = $("#rpay"); if (el) el.innerHTML = '<p class="msg err">Payout history needs the new "payouts" Firestore rule (see firestore-rules-additions.txt). ' + esc(e.message) + '</p>'; });
}
var _dRes2 = drawReseller;
drawReseller = function () {
  S.rPays = null; _dRes2(); if ((S.profile || {}).type !== "reseller") return;
  var tries = 0, t = setInterval(function () {
    if (++tries > 45) return clearInterval(t); var box = $("#rx"); if (!box) return; clearInterval(t);
    var opts = S.products.filter(function (p) { return p.active !== false && !p.owner && !oos(p); }).map(function (p) { return '<option value="' + p.id + '">' + esc(p.name) + ' (cost ' + fmt(roCost(p)) + ')</option>'; }).join("");
    var h = '<form class="card" style="margin-bottom:18px" onsubmit="PH.roPlace(event)"><h3 style="margin-bottom:4px">🛍️ Place an order for my customer</h3><p style="color:var(--mut);margin-bottom:12px">You choose the selling price. The customer pays you-set price (Cash on Delivery). After delivery your profit (price minus cost) is added to your commission.</p>' +
      '<div class="g2"><div class="fld"><label>Customer name</label><input name="name" required="required"/></div><div class="fld"><label>Customer phone</label><input name="phone" required="required" placeholder="03XXXXXXXXX"/></div></div><div class="g2"><div class="fld"><label>City</label><input name="city" required="required"/></div><div class="fld"><label>Address</label><input name="address" required="required"/></div></div>' +
      '<div class="row" style="gap:8px;margin-bottom:10px"><select class="inp" id="ro_p" style="flex:2 1 200px">' + opts + '</select><input class="inp" id="ro_q" type="number" min="1" value="1" style="flex:0 1 80px"/><input class="inp" id="ro_pr" type="number" min="0" placeholder="My price" style="flex:1 1 110px"/><button class="btn dk sm" type="button" onclick="PH.roAdd()">+ Add</button></div><div id="rolines"></div><button class="btn" type="submit" style="margin-top:12px">Place customer order</button></form>' +
      '<div class="card" style="margin-bottom:18px"><h3 style="margin-bottom:8px">💸 Payout history</h3><div id="rpay"><p>Loading...</p></div></div>';
    box.insertAdjacentHTML("beforeend", h); roDraw(); loadRPays();
  }, 400);
};
var _payout = PH.payout;
PH.payout = function (e) {
  e.preventDefault(); if (!FB_OK || !S.user) return needFB(); var f = e.target, pr = S.profile || {}, amt = Number(f.amt.value), btn = f.querySelector("button[type=submit]");
  if (!(amt > 0)) return toast("Enter an amount"); var av = S.rPays ? S.rNet : S.rAvail; if (av != null && amt > av) return toast("Amount is more than your available commission (" + fmt(av) + ")");
  var d = { uid: S.user.uid, name: pr.name || S.user.displayName || "", phone: pr.phone || "", email: S.user.email, refCode: pr.refCode || "", amount: amt, method: f.method.value, acct: f.acct.value.trim(), status: "Pending", createdMs: Date.now() }; btn.disabled = true;
  db.collection("payouts").add(d).then(function () { f.reset(); btn.disabled = false; toast("Payout request sent. We will contact you soon.");
    sendMail(SH.email, "Reseller payout request from " + d.name, "Reseller ID: " + (d.refCode || "-") + "\nAmount: " + fmt(amt) + "\n" + d.method + ": " + d.acct + "\nPhone: " + d.phone + "\nEmail: " + d.email, "Online Shah Alami"); loadRPays(); })
    .catch(function () { btn.disabled = false; _payout(e); });
};
function payoutsHTML() {
  var A = S.adm; if (!FB_OK || !db) return '<div class="msg err">Firebase is not configured. Connect the secure backend to load or update real payout requests.</div>'; if (!A.pays) { A.pays = []; db.collection("payouts").get().then(function (q) { var a = []; q.forEach(function (d) { var o = d.data(); o.id = d.id; a.push(o); }); a.sort(function (x, y) { return y.createdMs - x.createdMs; }); A.pays = a; A.paysOk = true; drawAdmin(); }).catch(function (e) { A.paysErr = e.message; drawAdmin(); }); return "<p>Loading...</p>"; }
  if (A.paysErr) return '<div class="msg err">Could not load payouts: ' + esc(A.paysErr) + '. Add the payouts rule from firestore-rules-additions.txt.</div>';
  var due = 0; A.pays.forEach(function (p) { if (p.status === "Pending") due += p.amount || 0; });
  return '<div class="stat-grid"><div class="stat"><b>' + A.pays.length + '</b>Requests</div><div class="stat"><b>' + fmt(due) + '</b>Waiting to pay</div></div>' + (A.pays.length ? '<div class="tw"><table><tr><th>Date</th><th>Reseller</th><th>Amount</th><th>Pay to</th><th>Status</th><th></th></tr>' + A.pays.map(function (p) { return '<tr><td>' + new Date(p.createdMs).toLocaleDateString() + '</td><td><b>' + esc(p.name) + '</b><br/><small>' + esc(p.refCode) + ' · ' + esc(p.phone) + '</small></td><td><b>' + fmt(p.amount) + '</b></td><td>' + esc(p.method) + ': ' + esc(p.acct) + '</td><td><span class="st">' + esc(p.status) + '</span></td><td class="row">' + (p.status === "Pending" ? '<button class="btn sm" onclick="PH.paySet(\'' + p.id + '\',\'Paid\')">Mark paid</button><button class="btn red sm" onclick="PH.paySet(\'' + p.id + '\',\'Rejected\')">Reject</button>' : "") + '</td></tr>'; }).join("") + '</table></div>' : '<p>No payout requests yet.</p>');
}
PH.paySet = function (id, st) { db.collection("payouts").doc(id).update({ status: st, updatedMs: Date.now() }).then(function () { S.adm.pays.forEach(function (p) { if (p.id === id) p.status = st; }); drawAdmin(); toast("Payout marked " + st); }).catch(function (x) { toast(x.message); }); };

/* ===== SMARTER SEARCH + LIVE SUGGESTIONS (added) ===== */
function matchQ(p, q) { var h = (p.name + " " + (p.cat || "") + " " + (p.desc || "") + " " + (p.badge || "") + " " + (p.sub || "") + " " + (p.brand || "") + " " + (p.searchKeywords || "")).toLowerCase(); var groups = [["shirt","shirts","tee","tshirt","t-shirt"],["mobile","phone","smartphone","cellphone"],["earbuds","earphone","earphones","headphones","headset"],["pan","pans","cookware","frying","fry"],["beauty","cosmetic","makeup","skincare"],["shoe","shoes","sneaker","sneakers","footwear"],["bag","bags","handbag","backpack"],["laptop","computer","notebook"],["charger","charging","adapter"],["watch","watches","wristwatch"]]; var words=String(q).toLowerCase().split(/\s+/).filter(Boolean); return words.every(function(w){if(h.indexOf(w)>-1)return true;var g=groups.filter(function(a){return a.indexOf(w)>-1;})[0];return !!g&&g.some(function(x){return h.indexOf(x)>-1;});}); }
function sugHide() { var d = $("#sug"); if (d) d.remove(); }
function sugShow(inp) {
  var q = inp.value.trim(); sugHide(); if (!q) return;
  var ql = q.toLowerCase(), a = S.products.filter(function (p) { return p.active !== false && matchQ(p, q); });
  a.sort(function (x, y) { return (y.name.toLowerCase().indexOf(ql) === 0) - (x.name.toLowerCase().indexOf(ql) === 0); });
  var d = document.createElement("div"); d.id = "sug"; d.addEventListener("mousedown", function (e) { e.preventDefault(); });
  d.innerHTML = a.length ? a.slice(0, 6).map(function (p) { return '<a class="sugi" href="#/product/' + p.id + '">' + (p.image ? '<img src="' + esc(p.image) + '" alt=""/>' : '<i>' + ((CONFIG.catEmoji || {})[p.cat] || "📦") + '</i>') + '<span><b>' + esc(p.name) + '</b><small>' + esc(p.cat || "General") + ' · ' + fmt(minP(p)) + '</small></span></a>'; }).join("") + '<a class="sugall" onclick="PH.sugAll()">See all results for "' + esc(q) + '"</a>' : '<div class="sugn">No product found for "' + esc(q) + '"</div>';
  inp.form.appendChild(d);
}
PH.sugAll = function () { var i = $(".hsearch input"); if (!i) return; S.q = i.value.trim(); sugHide(); if (location.hash === "#/shop") drawShop(); else location.hash = "#/shop"; };
document.addEventListener("input", function (e) { var t = e.target; if (t.matches && t.matches(".hsearch input")) sugShow(t); });
document.addEventListener("focusin", function (e) { var t = e.target; if (t.matches && t.matches(".hsearch input") && t.value.trim()) sugShow(t); });
document.addEventListener("click", function (e) { if (!e.target.closest || !e.target.closest(".hsearch")) sugHide(); });
document.addEventListener("keydown", function (e) { if (e.key === "Escape") sugHide(); });
window.addEventListener("hashchange", sugHide);
var _hs = PH.hsearch; PH.hsearch = function (e) { sugHide(); _hs(e); };

/* ===================== STORE ENHANCEMENTS (added) ===================== */
try {
var st2 = document.createElement("style");
st2.textContent = `
#mdr,#qvm{position:fixed;inset:0;z-index:300;visibility:hidden}
#mdr.on,#qvm.on{visibility:visible}
.mdb{position:absolute;inset:0;background:rgba(15,37,64,.55);opacity:0;transition:.3s}
.on>.mdb{opacity:1}
.mdp{position:absolute;top:0;right:0;bottom:0;width:min(400px,100%);background:#fff;display:flex;flex-direction:column;transform:translateX(100%);transition:.3s;box-shadow:-10px 0 40px rgba(0,0,0,.2)}
#mdr.on .mdp{transform:none}
.mdh{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid var(--line);font-family:Poppins,sans-serif;font-size:1.1rem}
.mdh button,.qvx{background:none;border:0;font-size:1.2rem;color:var(--ink)}
#mdbody{flex:1;display:flex;flex-direction:column;min-height:0}
.mdl{flex:1;overflow:auto;padding:8px 20px}
.mdi{display:grid;grid-template-columns:64px 1fr auto;gap:12px;padding:12px 0;border-bottom:1px solid var(--line);align-items:center}
.mdt{width:64px;height:64px;border-radius:12px;overflow:hidden;background:var(--cream);display:grid;place-items:center}
.mdt img{width:100%;height:100%;object-fit:cover}
.mdi small{display:block;color:var(--mut)}
.mdq{display:inline-flex;align-items:center;gap:10px;margin-top:6px;border:1px solid var(--line);border-radius:999px;padding:2px 6px}
.mdq button{border:0;background:none;width:24px;font-weight:700}
.mdp2{text-align:right;font-weight:700;color:var(--ink)}
.mdp2 button{display:block;margin:6px 0 0 auto;border:0;background:none}
.mdx{padding:16px 20px;border-top:1px solid var(--line);display:grid;gap:10px}
.mdx>div{display:flex;justify-content:space-between;font-size:1.1rem}
.mdx small{color:var(--mut)}
.mdf{margin:12px 20px 0;padding:10px 14px;background:#FFF3E6;border-radius:12px;font-size:.9rem}
.mdf.ok{background:#E7F6EC;color:#14602d}
.mdf i{display:block;height:6px;background:#f0d7bd;border-radius:6px;margin-top:8px;overflow:hidden}
.mdf u{display:block;height:100%;background:var(--gold);border-radius:6px}
.mde{margin:auto;text-align:center;display:grid;gap:12px;justify-items:center}
.qvc{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(780px,94%);max-height:90vh;overflow:auto;background:#fff;border-radius:22px;display:grid;grid-template-columns:1fr 1fr;gap:22px;padding:22px}
.qvi{border-radius:16px;overflow:hidden;background:var(--cream);min-height:240px}
.qvi img,.qvi video{width:100%;height:100%;object-fit:cover}
.qvr{display:grid;gap:12px;align-content:start}
.qvx{position:absolute;top:10px;right:14px;z-index:2}
.qvl{color:var(--amber);font-weight:700}
.qvb{position:absolute;top:54px;right:10px;z-index:3;width:36px;height:36px;border-radius:50%;border:0;background:#fff;box-shadow:var(--shadow)}
.off{position:absolute;top:48px;left:10px;z-index:3;background:#b3261e;color:#fff;font-size:.75rem;font-weight:700;padding:2px 8px;border-radius:999px}
.low{color:#b3261e;font-weight:700}.ins{color:#14602d;font-weight:600}
.dx{margin:10px 0;padding:10px 14px;background:#F3F5F8;border-radius:12px;font-size:.92rem}
.shr{display:flex;gap:12px;align-items:center;margin:10px 0;font-size:.92rem}
.shr a,.shr button{color:var(--amber);font-weight:700;background:none;border:0}
.fbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:0 0 16px}
.fbar .inp{width:130px}.fbar label{display:flex;gap:6px;align-items:center;font-weight:600}
.btt{position:fixed;left:16px;bottom:16px;z-index:60;width:44px;height:44px;border-radius:50%;border:0;background:var(--ink);color:#fff;font-size:1.2rem;display:none}
.btt.on{display:block}
#lbx{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.88);display:none;align-items:center;justify-content:center;cursor:zoom-out}
#lbx.on{display:flex}#lbx img{max-width:92vw;max-height:90vh;border-radius:12px}
.pd .pimg img{cursor:zoom-in}
#bnav,.sbar{display:none}
@media(max-width:640px){.qvc{grid-template-columns:1fr}}
@media(max-width:768px){
#bnav{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:90;background:#fff;border-top:1px solid var(--line);padding:6px 0 calc(6px + env(safe-area-inset-bottom,0px))}
#bnav a{flex:1;text-align:center;font-size:.72rem;color:var(--mut);position:relative}
#bnav a i{display:block;font-style:normal;font-size:1.3rem}
#bnav a.act{color:var(--amber);font-weight:700}
#bnav em{position:absolute;top:-2px;left:56%;background:var(--gold);color:#0A1628;border-radius:999px;font-size:.65rem;font-weight:700;padding:0 6px;font-style:normal}
body{padding-bottom:64px}.wa,#waf{bottom:78px!important}.btt{bottom:78px}
.sbar{display:flex;position:fixed;left:0;right:0;bottom:56px;z-index:89;background:#fff;padding:10px 14px;gap:10px;align-items:center;justify-content:space-between;box-shadow:0 -4px 16px rgba(0,0,0,.1)}
.sbar b{color:var(--ink);font-size:.9rem}}`;
document.head.appendChild(st2);

function stock(p) {
  var s = p.stock;
  if (oos(p)) return "";
  if (s != null && s !== "" && Number(s) > 0 && Number(s) <= 5) return '<div class="low">🔥 Only ' + Number(s) + ' left in stock</div>';
  return '<div class="ins">✓ In stock</div>';
}
function dt(n) { var d = new Date(); while (n > 0) { d.setDate(d.getDate() + 1); if (d.getDay()) n--; } return d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" }); }

/* --- slide-out cart --- */
var dr = document.createElement("div"); dr.id = "mdr";
dr.innerHTML = '<div class="mdb" onclick="PH.dclose()"></div><aside class="mdp" role="dialog" aria-label="Cart"><div class="mdh"><b>Your cart</b><button onclick="PH.dclose()" aria-label="Close">✕</button></div><div id="mdbody"></div></aside>';
document.body.appendChild(dr);
function drawDrawer() {
  var L = lines(), t = totals(), fa = Number((S.delivery || {}).freeAbove) || 0, b = $("#mdbody");
  if (!L.length) { b.innerHTML = '<div class="mde"><div style="font-size:3rem">🛒</div><p>Your cart is empty</p><a class="btn sm" href="#/shop" onclick="PH.dclose()">Start shopping</a></div>'; return; }
  var bar = fa ? (t.sub >= fa ? '<div class="mdf ok">🎉 You get free delivery!</div>' : '<div class="mdf">Add <b>' + fmt(fa - t.sub) + '</b> more for free delivery<i><u style="width:' + Math.min(100, t.sub / fa * 100) + '%"></u></i></div>') : "";
  b.innerHTML = bar + '<div class="mdl">' + L.map(function (l) {
    var i = l.size === "Wholesale" ? -1 : l.p.variants.indexOf(l.v), id = l.p.id;
    return '<div class="mdi"><div class="mdt">' + thumb(l.p) + '</div><div><b>' + esc(l.p.name) + '</b><small>' + esc(l.size) + '</small><div class="mdq"><button onclick="PH.dq(\'' + id + '\',' + i + ',-1)" aria-label="Less">−</button><span>' + l.qty + '</span><button onclick="PH.dq(\'' + id + '\',' + i + ',1)" aria-label="More">+</button></div></div><div class="mdp2">' + fmt(l.price * l.qty) + '<button onclick="PH.drm(\'' + id + '\',' + i + ')" aria-label="Remove">🗑</button></div></div>';
  }).join("") + '</div><div class="mdx"><div><span>Subtotal</span><b>' + fmt(t.sub) + '</b></div><small>Delivery and discounts are calculated at checkout.</small><a class="btn" href="#/checkout" onclick="PH.dclose()">Checkout</a><a class="btn ghost" href="#/cart" onclick="PH.dclose()">View cart</a></div>';
}
PH.dopen = function () { drawDrawer(); dr.classList.add("on"); document.body.style.overflow = "hidden"; };
PH.dclose = function () { dr.classList.remove("on"); document.body.style.overflow = ""; };
PH.dq = function (pid, i, d) { var p = getP(pid), sz = i < 0 ? "Wholesale" : p.variants[i].size, mn = i < 0 ? (p.wsMin || 10) : 1; S.cart.forEach(function (c) { if (c.pid === pid && c.size === sz) { var n = c.qty + d; if (d < 0 && n < mn) { n = mn; toast("Minimum quantity is " + mn + ". Use the bin to remove."); } c.qty = Math.min(n, i < 0 ? 9999 : 99); } }); saveCart(); drawDrawer(); };
PH.drm = function (pid, i) { var p = getP(pid), sz = i < 0 ? "Wholesale" : p.variants[i].size; S.cart = S.cart.filter(function (c) { return !(c.pid === pid && c.size === sz); }); saveCart(); drawDrawer(); };
var _ai = addItem;
addItem = function (pid, i, q) { var n = cartCount(); _ai(pid, i, q); if (cartCount() > n && !/^#\/(cart|checkout)/.test(location.hash)) PH.dopen(); };
document.addEventListener("click", function (e) {
  var a = e.target.closest && e.target.closest('#nav a[data-r="cart"]');
  if (a && !/^#\/(cart|checkout)/.test(location.hash)) { e.preventDefault(); $("#nav").classList.remove("open"); $("#burger").classList.remove("open"); PH.dopen(); }
  var im = e.target.closest && e.target.closest(".pd .pimg img");
  if (im) { $("#lbx img").src = im.src; $("#lbx").classList.add("on"); }
});
window.addEventListener("hashchange", PH.dclose);

/* --- quick view --- */
var qv = document.createElement("div"); qv.id = "qvm"; document.body.appendChild(qv);
PH.qv = function (id) {
  var p = getP(id); if (!p) return;
  qv.innerHTML = '<div class="mdb" onclick="PH.qvclose()"></div><div class="qvc" data-pid="' + p.id + '"><button class="qvx" onclick="PH.qvclose()" aria-label="Close">✕</button><div class="qvi">' + pimg(p, hueOf(p)) + '</div><div class="qvr"><span class="pcat">' + esc(p.cat || "") + '</span><h3>' + esc(p.name) + '</h3><div class="price" data-price>' + fmt(p.variants[0].price) + '</div>' + stock(p) + '<p>' + esc((p.desc || "").slice(0, 160)) + '</p><div class="chips">' + chips(p) + '</div><div class="row"><div class="qty"><button onclick="PH.qvq(-1)" aria-label="Less">−</button><input data-qty value="1" readonly="readonly"/><button onclick="PH.qvq(1)" aria-label="More">+</button></div>' + (oos(p) ? '<button class="btn sm" disabled="disabled">Out of stock</button>' : '<button class="btn sm" onclick="PH.qvadd(this)">Add to cart</button>') + '</div><a class="qvl" href="#/product/' + p.id + '" onclick="PH.qvclose()">View full details →</a></div></div>';
  qv.classList.add("on");
};
PH.qvclose = function () { qv.classList.remove("on"); };
PH.qvq = function (d) { var i = qv.querySelector("[data-qty]"); i.value = Math.min(99, Math.max(1, +i.value + d)); };
PH.qvadd = function (b) { PH.add(b); PH.qvclose(); };
window.addEventListener("hashchange", PH.qvclose);
document.addEventListener("keydown", function (e) { if (e.key === "Escape") { PH.dclose(); PH.qvclose(); $("#lbx").classList.remove("on"); } });
var lb = document.createElement("div"); lb.id = "lbx"; lb.innerHTML = "<img alt=''/>"; lb.onclick = function () { lb.classList.remove("on"); }; document.body.appendChild(lb);

/* --- shop filters (price range + in stock) --- */
var _ps = pShop;
pShop = function () {
  return _ps().replace('<div class="chips cats" id="cats">', '<div class="fbar"><b>Filter:</b><input class="inp" id="fmin" type="number" min="0" placeholder="Min PKR" value="' + (S.fmin || "") + '" oninput="PH.flt()"/><input class="inp" id="fmax" type="number" min="0" placeholder="Max PKR" value="' + (S.fmax || "") + '" oninput="PH.flt()"/><label><input id="fstk" type="checkbox"' + (S.fstock ? " checked" : "") + ' onchange="PH.flt()"/> In stock only</label><button class="btn ghost sm" type="button" onclick="PH.fclr()">Clear</button></div><div class="chips cats" id="cats">');
};
var _ds = drawShop;
drawShop = function () {
  var all = S.products;
  S.products = all.filter(function (p) { var m = minP(p); return (!S.fmin || m >= S.fmin) && (!S.fmax || m <= S.fmax) && (!S.fstock || !oos(p)); });
  try { _ds(); } finally { S.products = all; }
  var cs = $("#cats");
  if (cs) { var n = ["All"]; all.forEach(function (p) { var c = p.cat || "General"; if (n.indexOf(c) < 0) n.push(c); }); cs.innerHTML = n.length > 2 ? n.map(function (c) { return '<button class="chip' + (c === S.cat ? " on" : "") + '" data-c="' + esc(c) + '" onclick="PH.setcat(this.dataset.c)">' + esc(c) + '</button>'; }).join("") : ""; }
};
PH.flt = function () { S.fmin = Number($("#fmin").value) || 0; S.fmax = Number($("#fmax").value) || 0; S.fstock = $("#fstk").checked; S.sig = null; drawShop(); };
PH.fclr = function () { S.fmin = S.fmax = 0; S.fstock = false; render(); };
PH.copy = function () { if (navigator.clipboard) navigator.clipboard.writeText(location.href).then(function () { toast("Link copied"); }); };

/* --- page enhancements applied as pages render --- */
function deco() {
  document.querySelectorAll(".pcard:not([data-e])").forEach(function (c) {
    c.setAttribute("data-e", "1");
    var id = c.getAttribute("data-pid"), p = getP(id); if (!p) return;
    var o = Number(p.oldPrice), v = Number(p.variants[0].price);
    c.insertAdjacentHTML("beforeend", '<button class="qvb" onclick="PH.qv(\'' + id + '\')" aria-label="Quick view" title="Quick view">👁</button>' + (o > v ? '<span class="off">-' + Math.round((1 - v / o) * 100) + '%</span>' : ""));
  });
}
function pdx() {
  var d = $(".pd:not([data-e])"); if (!d) return; d.setAttribute("data-e", "1");
  var p = getP(d.getAttribute("data-pid")), n = d.querySelector(".note"); if (!p || !n) return;
  var m = /(\d+)\D+(\d+)/.exec(CONFIG.policy.deliveryTime || ""), est = m ? '<div class="dx">🚚 Estimated delivery: <b>' + dt(+m[1]) + ' – ' + dt(+m[2]) + '</b></div>' : "";
  var u = encodeURIComponent(p.name + " - " + location.href);
  n.insertAdjacentHTML("beforebegin", stock(p) + est + '<div class="shr">Share: <a href="https://wa.me/?text=' + u + '" target="_blank" rel="noopener">WhatsApp</a><button type="button" onclick="PH.copy()">Copy link</button></div>');
  if (!oos(p)) d.insertAdjacentHTML("beforeend", '<div class="sbar"><b>' + esc(p.name.slice(0, 26)) + '</b><span><button class="btn sm" onclick="PH.add(this)">Add to cart</button> <button class="btn dk sm" onclick="PH.buy(this)">Order now</button></span></div>');
}
function recent() {
  var h = location.hash, v = $("#view"); if (!v) return;
  var m = /^#\/product\/([^\/?]+)/.exec(h), cur = m && m[1], L = load("am_rv", []);
  if (cur && $(".pd") && L[0] !== cur) { L = [cur].concat(L.filter(function (x) { return x !== cur; })).slice(0, 10); save("am_rv", L); }
  if ($("#rvs") || !((cur && $(".pd")) || ((h === "" || /^#\/(home)?$/.test(h)) && $(".hero")))) return;
  var a = L.filter(function (x) { return x !== cur; }).map(getP).filter(function (p) { return p && S.products.indexOf(p) > -1; }).slice(0, 4);
  if (!a.length) return;
  v.insertAdjacentHTML("beforeend", '<section class="sec" id="rvs"><div class="wrap"><div class="stitle"><h2>Recently viewed</h2></div><div class="grid">' + a.map(function (p) { return pcard(p); }).join("") + '</div></div></section>'); after();
}
function bn() {
  var b = $("#bnav");
  if (!b) { b = document.createElement("nav"); b.id = "bnav"; b.setAttribute("aria-label", "Quick navigation"); b.innerHTML = '<a href="#/home" data-r="home"><i>🏠</i>Home</a><a href="#/shop" data-r="shop"><i>🛍️</i>Shop</a><a href="#/wishlist" data-r="wishlist"><i>♡</i>Wishlist</a><a href="#/cart" data-r="cart"><i>🛒</i>Cart<em>0</em></a><a href="#/account" data-r="account"><i>👤</i>Account</a>'; document.body.appendChild(b); }
  var r = (location.hash || "#/home").replace(/^#\/?/, "").split("/")[0] || "home";
  b.querySelectorAll("a").forEach(function (a) { a.classList.toggle("act", a.getAttribute("data-r") === r); });
  var e = b.querySelector("em"), c = String(cartCount()); if (e.textContent !== c) e.textContent = c; e.style.display = cartCount() ? "" : "none";
}
var btt = document.createElement("button"); btt.className = "btt"; btt.setAttribute("aria-label", "Back to top"); btt.textContent = "↑"; btt.onclick = function () { window.scrollTo({ top: 0, behavior: "smooth" }); }; document.body.appendChild(btt);
window.addEventListener("scroll", function () { btt.classList.toggle("on", window.scrollY > 700); }, { passive: true });
/* --- wholesale: live price preview, reorder --- */
function ws2() {
  var t = $("#wst"); if (!t || t.getAttribute("data-x2")) return; t.setAttribute("data-x2", "1"); S.wsRO = 0;
  t.querySelectorAll('input[id^="wq_"]').forEach(function (i) {
    var p = getP(i.id.slice(3)); if (!p) return;
    i.insertAdjacentHTML("afterend", '<small class="wsp" style="display:block;color:var(--mut)"></small>');
    var u = function () { var q = Math.floor(+i.value) || 0, pr = slabPrice("Wholesale", q, Number(p.ws)), nx = null; slabList().forEach(function (s) { if (!nx && q < s[0]) nx = s; }); i.nextSibling.innerHTML = q ? '<b>' + fmt(pr) + '</b> each · ' + fmt(pr * q) + (nx ? '<br>Add ' + (nx[0] - q) + ' more for ' + nx[1] + '% off' : '') : ''; };
    i.addEventListener("input", u); u();
  });
}
function ws3() {
  var w = $("#wsord table:not([data-w])"); if (!w) return;
  if (!S.wsRO) { S.wsRO = 1; loadMyOrders().then(function (a) { S.wsOrd = {}; a.forEach(function (o) { S.wsOrd[o.orderNo] = o; }); enh(); }).catch(function () {}); return; }
  if (!S.wsOrd) return; w.setAttribute("data-w", "1");
  w.querySelectorAll("tr").forEach(function (r, i) { if (!i) return void r.insertAdjacentHTML("beforeend", "<th></th>"); var b = r.querySelector("b"); r.insertAdjacentHTML("beforeend", b && S.wsOrd[b.textContent] ? '<td><button class="btn sm ghost" onclick="PH.wsRe(\'' + esc(b.textContent) + '\')">↻ Reorder</button></td>' : "<td></td>"); });
}
PH.wsRe = function (no) {
  var o = S.wsOrd && S.wsOrd[no]; if (!o) return; var n = 0;
  o.items.forEach(function (i) { var p = getP(i.pid); if (i.size !== "Wholesale" || !p || !p.ws || oos(p)) return; var q = Math.max(p.wsMin || 10, i.qty), f = null; S.cart.forEach(function (x) { if (x.pid === p.id && x.size === "Wholesale") f = x; }); if (f) f.qty = q; else S.cart.push({ pid: p.id, size: "Wholesale", qty: q }); n++; });
  saveCart(); wsCartLine(); toast(n ? n + " product(s) from " + no + " added to cart" : "These products are no longer available.");
};

/* --- reseller: monthly target, customer book, WhatsApp updates, printable catalog --- */
function res() {
  var rx = $("#rx"); if (!rx || !S.rrows) return;
  if (!rx.getAttribute("data-x2")) {
    rx.setAttribute("data-x2", "1");
    var d0 = new Date(), k = d0.getFullYear() + "-" + d0.getMonth(), got = 0, tg = Number(load("am_tg", 0)) || 0;
    S.rrows.forEach(function (x) { var d = new Date(x.o.createdMs); if (d.getFullYear() + "-" + d.getMonth() !== k || x.o.status === "Cancelled") return; x.items.forEach(function (i) { got += i.comm || 0; }); });
    var pc = tg ? Math.min(100, Math.round(got * 100 / tg)) : 0;
    rx.insertAdjacentHTML("afterbegin", '<div class="card" id="rtg" style="margin-bottom:18px"><h3 style="margin-bottom:6px">🎯 Monthly profit target</h3><p>This month: <b>' + fmt(got) + '</b>' + (tg ? ' of <b>' + fmt(tg) + '</b> (' + pc + '%)' : ' · set a goal to track it') + '</p>' + (tg ? '<div style="height:8px;background:#eee;border-radius:8px;overflow:hidden;margin:8px 0"><div style="height:100%;width:' + pc + '%;background:var(--gold)"></div></div>' : '') + '<div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px"><input class="inp" id="tgv" type="number" min="0" placeholder="Target PKR" value="' + (tg || "") + '" style="max-width:160px"/><button class="btn sm" onclick="PH.tgSet()">Save target</button><button class="btn dk sm" onclick="PH.catPrint()">🖨 Print customer catalog</button></div></div>');
  }
  var f = rx.querySelector('form[onsubmit*="roPlace"]');
  if (f && !f.getAttribute("data-x2")) {
    f.setAttribute("data-x2", "1"); var L = load("am_cust", []), g = f.querySelector(".g2");
    if (L.length && g) g.insertAdjacentHTML("beforebegin", '<div class="fld"><label>Saved customers</label><select class="inp" onchange="PH.custFill(this.value)"><option value="">New customer</option>' + L.map(function (c, i) { return '<option value="' + i + '">' + esc(c.n) + " · " + esc(c.p) + '</option>'; }).join("") + '</select></div>');
  }
  var t = $("#rord table:not([data-w])");
  if (t) {
    t.setAttribute("data-w", "1");
    t.querySelectorAll("tr").forEach(function (r, i) { if (!i) return void r.insertAdjacentHTML("beforeend", "<th></th>"); var b = r.querySelector("b"), x = b && S.rrows.filter(function (y) { return y.o.orderNo === b.textContent; })[0]; r.insertAdjacentHTML("beforeend", x && x.o.resold && x.o.customer ? '<td><button class="btn sm ghost" onclick="PH.rwa(\'' + esc(x.o.orderNo) + '\')">💬 Customer</button></td>' : "<td></td>"); });
  }
}
PH.tgSet = function () { save("am_tg", Number($("#tgv").value) || 0); var c = $("#rtg"); if (c) c.remove(); var rx = $("#rx"); if (rx) rx.removeAttribute("data-x2"); enh(); };
PH.custFill = function (i) { var c = load("am_cust", [])[i], f = $('form[onsubmit*="roPlace"]'); if (!c || !f) return; f.name.value = c.n; f.phone.value = c.p; f.city.value = c.c; f.address.value = c.a; };
var _rp = PH.roPlace;
PH.roPlace = function (e) {
  var f = e.target;
  try { var L = load("am_cust", []), c = { n: f.name.value.trim(), p: f.phone.value.trim(), c: f.city.value.trim(), a: f.address.value.trim() }; if (c.n && c.p) { L = L.filter(function (x) { return x.p !== c.p; }); L.unshift(c); save("am_cust", L.slice(0, 30)); } } catch (x) {}
  _rp(e);
};
PH.rwa = function (no) {
  var x = (S.rrows || []).filter(function (y) { return y.o.orderNo === no; })[0]; if (!x) return;
  var p = String(x.o.customer.phone || "").replace(/\D/g, ""); if (p.charAt(0) === "0") p = "92" + p.slice(1);
  window.open("https://wa.me/" + p + "?text=" + encodeURIComponent("Assalam o Alaikum " + x.o.customer.name + ", your order " + no + " from " + SH.name + " is now " + x.o.status + ". Total: " + fmt(x.o.total) + ". Questions? WhatsApp " + SH.phone + "."), "_blank");
};
PH.catPrint = function () {
  var pr = S.profile || {}, rows = S.products.filter(function (p) { return p.active !== false && !oos(p); }).slice(0, 60).map(function (p) { var el = $("#rp_" + p.id), v = el && el.value ? Number(el.value) : minP(p); return '<div class="c">' + (p.image ? '<img src="' + esc(p.image) + '">' : '<div class="e">' + ((CONFIG.catEmoji || {})[p.cat] || "📦") + '</div>') + '<b>' + esc(p.name) + '</b><span>' + fmt(v) + '</span></div>'; }).join("");
  var w = window.open("", "_blank"); if (!w) return toast("Allow pop-ups to print the catalog");
  w.document.write('<!DOCTYPE html><title>' + esc(SH.name) + ' catalog</title>\n<h1>' + esc(SH.name) + ' catalog</h1><p>Order on WhatsApp: ' + SH.phone + (pr.refCode ? ' · Reseller ID: ' + esc(pr.refCode) : '') + '</p><div class="g">' + rows + '</div><script>onload=function(){print()}<\/script>');
  w.document.close();
};
/* --- wholesale credit terms + reseller referrals --- */
var CR_DAYS = CONFIG.creditDays || 15, REF_BONUS = CONFIG.referralBonus || 500;
function crOpen(o) { return String(o.paymentMethod || "").indexOf("Credit") === 0 && o.status !== "Cancelled" && !(/verified|paid|received/i.test(o.paymentStatus || "") && !/pending|reject|unpaid/i.test(o.paymentStatus || "")); }
function crLoad(cb) { loadMyOrders().then(function (a) { var u = 0; a.forEach(function (o) { if (crOpen(o)) u += o.total || 0; }); cb(Number((S.profile || {}).creditLimit) || 0, u, a); }).catch(function () {}); }
function cr() {
  var t = $("#wst"); if (!t || $("#crp") || !Number((S.profile || {}).creditLimit)) return;
  t.parentNode.insertAdjacentHTML("beforebegin", '<div class="card" id="crp" style="margin-bottom:20px"><h3>💳 Credit account</h3><p>Loading...</p></div>');
  crLoad(function (lim, used, a) {
    var c = $("#crp"); if (!c) return; var pc = lim ? Math.min(100, Math.round(used * 100 / lim)) : 0, due = null;
    a.forEach(function (o) { if (crOpen(o)) { var d = o.createdMs + CR_DAYS * 864e5; if (!due || d < due) due = d; } });
    c.innerHTML = '<h3 style="margin-bottom:6px">💳 Credit account</h3><p>Limit <b>' + fmt(lim) + '</b> · Used <b>' + fmt(used) + '</b> · Available <b>' + fmt(Math.max(0, lim - used)) + '</b></p><div style="height:8px;background:#eee;border-radius:8px;overflow:hidden;margin:8px 0"><div style="height:100%;width:' + pc + '%;background:' + (pc > 85 ? "#b3261e" : "var(--gold)") + '"></div></div><p style="color:var(--mut)">' + (used && due ? 'Next payment due: <b>' + new Date(due).toLocaleDateString() + '</b>. ' : "") + 'Choose "Credit (Pay Later)" at checkout and pay within ' + CR_DAYS + ' days.</p>';
  });
}
function ck() {
  var f = $("#chk"); if (!f || f.getAttribute("data-cr")) return; f.setAttribute("data-cr", "1");
  var pr = S.profile || {}; if (!pr.wholesale || !(Number(pr.creditLimit) > 0)) return;
  crLoad(function (lim, used) {
    var box = $("#chk .pay"); if (!box || $("#chk input[value^=Credit]")) return; var av = Math.max(0, lim - used), ok = totals().total <= av;
    box.insertAdjacentHTML("beforeend", '<label><input type="radio" name="pay" value="Credit (Pay Later)" onchange="PH.payUI()"' + (ok ? "" : ' disabled="disabled"') + '/>Credit: pay in ' + CR_DAYS + ' days (available ' + fmt(av) + (ok ? "" : ", not enough for this order") + ')</label>');
  });
}
var _pu = payUI;
payUI = function () {
  var f = $("#chk"), b = $("#payinfo");
  if (f && b && f.pay && String(f.pay.value).indexOf("Credit") === 0) { b.innerHTML = '<div class="note">Your order is placed on credit. No payment is needed now. Please pay within ' + CR_DAYS + ' days by JazzCash, EasyPaisa, bank transfer or cash.</div>'; return; }
  _pu();
};
PH.payUI = payUI;
var _ac = accessCell;
accessCell = function (u) {
  var h = _ac(u), code = u.refCode || String(u.id).slice(0, 8), us = S.adm.users, n = us.filter(function (x) { return x.referredBy && x.referredBy === code; }).length,
    rb = u.referredBy ? us.filter(function (x) { return (x.refCode || String(x.id).slice(0, 8)) === u.referredBy; })[0] : null;
  return h + (u.referredBy ? '<br/><small>Referred by: <b>' + esc(rb ? rb.name || rb.email : u.referredBy) + '</b></small>' : "") + (u.type === "reseller" && n ? '<br/><small>Referrals: <b>' + n + '</b></small>' : "") +
    (u.wholesale ? '<br/><small>Credit limit: <b>' + fmt(u.creditLimit || 0) + '</b></small> <button class="btn sm" onclick="PH.credit(\'' + u.id + '\')">Set credit</button>' : "");
};
PH.credit = function (id) {
  var u = S.adm.users.filter(function (x) { return x.id === id; })[0]; if (!u) return;
  var v = prompt("Credit limit in PKR for " + (u.name || u.email) + " (0 = no credit):", u.creditLimit || 0); if (v === null) return;
  var n = Math.round(Number(v)); if (isNaN(n) || n < 0) return toast("Enter a valid amount");
  db.collection("users").doc(id).update({ creditLimit: n }).then(function () { u.creditLimit = n; drawAdmin(); toast("Credit limit saved"); }).catch(function (x) { toast(x.message); });
};
var rq = /[?&]ref=([A-Za-z0-9_-]+)/.exec(location.search); if (rq) save("am_ref", rq[1]);
function rf() {
  var pr = S.profile; if (!S.user || !pr || S.rfTry || pr.referredBy || !db) return; var c = load("am_ref", ""); if (!c) return; S.rfTry = 1;
  if (c === (pr.refCode || S.user.uid.slice(0, 8))) return;
  db.collection("users").doc(S.user.uid).update({ referredBy: c }).then(function () { pr.referredBy = c; }).catch(function () {});
}
function rr() {
  var rx = $("#rx"); if (!rx || !S.rrows || $("#rrf")) return; var pr = S.profile || {}, code = pr.refCode || S.user.uid.slice(0, 8), link = location.href.split("#")[0].split("?")[0] + "?ref=" + code;
  rx.insertAdjacentHTML("afterbegin", '<div class="card" id="rrf" style="margin-bottom:18px"><h3 style="margin-bottom:6px">👥 Refer a reseller</h3><p style="color:var(--mut);margin-bottom:10px">Invite friends to sell on ' + esc(SH.name) + '. When someone you invited is approved as a reseller, you can earn a <b>' + fmt(REF_BONUS) + '</b> bonus (paid by admin after checking).</p><div class="row" style="gap:8px;flex-wrap:wrap"><input class="inp" id="rfin" readonly value="' + esc(link) + '" style="flex:1 1 240px"/><button class="btn sm" onclick="PH.rfCopy()">Copy link</button><button class="btn dk sm" onclick="PH.rfWa()">Share on WhatsApp</button></div><p id="rfl" style="margin-top:10px">Checking your referrals...</p></div>');
  db.collection("users").where("referredBy", "==", code).get().then(function (q) {
    var n = 0, ap = 0; q.forEach(function (d) { n++; if (d.data().type === "reseller") ap++; }); var el = $("#rfl"); if (el) el.innerHTML = 'Invited: <b>' + n + '</b> · Approved resellers: <b>' + ap + '</b> · Bonus to review: <b>' + fmt(ap * REF_BONUS) + '</b>';
  }).catch(function () { var el = $("#rfl"); if (el) el.textContent = "Your referral count will show after admin review."; });
}
PH.rfCopy = function () { var i = $("#rfin"); if (i && navigator.clipboard) navigator.clipboard.writeText(i.value).then(function () { toast("Referral link copied"); }); };
PH.rfWa = function () { window.open("https://wa.me/?text=" + encodeURIComponent("Join " + SH.name + " as a reseller and earn commission on every sale: " + $("#rfin").value), "_blank"); };
/* --- Order Now popup bridge (Daraz-style order form) --- */
window.AMX = {
  cfg: function () { return { wa: SH.whatsapp, acc: { wallet: [{ n: "JazzCash", title: SH.accountName, no: SH.jazzcash }, { n: "Easypaisa", title: SH.accountName, no: SH.easypaisa }], bank: [{ n: SH.bankName, title: SH.accountName, no: "Account No: " + SH.bankNo }] } }; },
  del: function (city, sub) { if (!sub) return 0; var D = S.delivery || {}, fee = D.fee != null ? Number(D.fee) : (Number(CONFIG.deliveryFee) || 0), c = String(city || "").trim().toLowerCase(); if (D.cities && c && D.cities[c] != null) fee = Number(D.cities[c]); var fa = Number(D.freeAbove) || 0; return fa && sub >= fa ? 0 : fee; },
  coupon: function (code, sub) { return AMX.ensure().then(function () { return db.collection("coupons").doc(code).get(); }).then(function (d) { var c = d.exists ? d.data() : null; if (!c || c.active === false || (c.expiresMs && Date.now() > c.expiresMs) || (c.minOrder && sub < c.minOrder)) return null; return { t: c.type === "percent" ? "percent" : "flat", v: Number(c.value) }; }); },
  ensure: function () { return S.user ? Promise.resolve(S.user) : auth.signInAnonymously().then(function (r) { return r.user; }).catch(function () { return null; }); },
  save: function (d, o, shot) { if (!FB_OK) return; AMX.ensure().then(function (u) { AMX.save2(u, d, o, shot); }).catch(function (e) { console.warn("Guest order not saved", e); }); },
  save2: function (u, d, o, shot) {
    var L = o.items.map(function (i) { var p = getP(i.pid) || {}; return { pid: i.pid || "", name: i.name, size: i.variant || "", qty: i.qty, price: i.price, owner: p.owner || "", comm: p.owner ? Math.round(i.price * i.qty * (Number((S.resellerSettings || {}).commissionPct == null ? CONFIG.commissionPct : S.resellerSettings.commissionPct) || 0) / 100) : 0 }; }), ow = [];
    L.forEach(function (l) { if (l.owner && ow.indexOf(l.owner) < 0) ow.push(l.owner); });
    var m = o.payment === "cod" ? "Cash on Delivery" : o.payment === "wallet" ? "JazzCash / EasyPaisa" : "Bank Transfer";
    (shot ? storeImg(shot, "payments") : Promise.resolve("")).then(function (img) {
      var x = { orderNo: AMX.curNo, userId: u ? u.uid : "guest", userEmail: (u && u.email) || "", customer: { name: d.name, phone: "0" + d.phone, email: (u && u.email) || "", city: d.city, address: d.area + ", " + d.point + ", " + d.address, notes: "Province: " + d.province + " | Order Now popup" },
        items: L, owners: ow, subtotal: o.productsTotal, delivery: o.delivery + o.codFee, discount: o.discount, coupon: o.code || "", total: o.total, paymentMethod: m, txnId: "", screenshot: img || "",
        status: "Pending", paymentStatus: o.payment === "cod" ? "Pay on delivery" : "Pending verification", createdMs: Date.now(), history: [{ s: "Pending", t: Date.now() }] };
      return db.collection("orders").add(x).then(function () { sendMail(SH.email, "NEW ORDER " + x.orderNo + " - " + fmt(x.total), orderText(x), "Online Shah Alami", mailVars(x, "New order received", "a new order was placed by " + x.customer.name + ".")); });
    }).catch(function (e) { console.warn("Order save failed", e); });
  }
};
/* --- login offered only at "Confirm Order" (guest allowed) --- */
(function () {
  var st = document.createElement("style");
  st.textContent = "#amxGate{position:fixed;inset:0;z-index:100003;background:rgba(15,37,64,.6);display:none;align-items:center;justify-content:center;padding:16px}#amxGate.on{display:flex}.amx-g{background:#fff;border-radius:18px;padding:22px;width:min(380px,100%);display:grid;gap:10px}.amx-g h3{margin:0}.amx-g p{margin:0;color:#5B6B7C}.amx-g input{padding:12px;border:1px solid #ccd;border-radius:10px;font:inherit}.amx-g button{padding:12px;border:0;border-radius:10px;font-weight:700;cursor:pointer;font:inherit}#amxMsg{color:#b3261e;font-size:.9rem}#amxLogin,#amxReg{display:block;width:100%;box-sizing:border-box;padding:13px;border:0;border-radius:12px;font-weight:700;text-align:center;cursor:pointer;text-decoration:none;transition:transform .12s,box-shadow .12s}#amxLogin{background:linear-gradient(135deg,#34D27B,#16A34A 55%,#15803D);color:#fff;box-shadow:0 5px 0 #0f6b31,0 10px 18px rgba(22,163,74,.35)}#amxReg{background:#0F2540;color:#fff;box-shadow:0 5px 0 #050d18,0 10px 18px rgba(15,37,64,.4)}#amxLogin:hover,#amxReg:hover{transform:translateY(-2px)}#amxLogin:active{transform:translateY(4px);box-shadow:0 1px 0 #0f6b31,0 3px 8px rgba(22,163,74,.3)}#amxReg:active{transform:translateY(4px);box-shadow:0 1px 0 #050d18,0 3px 8px rgba(15,37,64,.3)}.btn:not(.ghost){box-shadow:0 5px 0 #0f6b31,0 10px 18px rgba(22,163,74,.35)!important;transition:transform .12s,box-shadow .12s!important}.btn.dk{box-shadow:0 5px 0 #050d18,0 10px 18px rgba(15,37,64,.4)!important}.btn.red{box-shadow:0 5px 0 #7a1812,0 10px 18px rgba(179,38,30,.35)!important}.btn:not(.ghost):hover{transform:translateY(-2px)!important}.btn:not(.ghost):active{transform:translateY(4px)!important;box-shadow:0 1px 0 #0f6b31,0 3px 8px rgba(22,163,74,.3)!important}.btn.dk:active{box-shadow:0 1px 0 #050d18,0 3px 8px rgba(15,37,64,.3)!important}#amOrdSubmit{background:linear-gradient(135deg,#34D27B,#16A34A 55%,#15803D)!important;box-shadow:0 5px 0 #0f6b31,0 10px 18px rgba(22,163,74,.35)!important;animation:none!important;transition:transform .12s,box-shadow .12s!important}#amOrdSubmit:hover{transform:translateY(-2px)!important;box-shadow:0 7px 0 #0f6b31,0 14px 22px rgba(22,163,74,.4)!important}#amOrdSubmit:active{transform:translateY(4px)!important;box-shadow:0 1px 0 #0f6b31,0 3px 8px rgba(22,163,74,.3)!important}";
  document.head.appendChild(st);
  var g = document.createElement("div"); g.id = "amxGate";
  g.innerHTML = '<div class="amx-g" role="dialog" aria-modal="true"><h3>Almost done</h3><p>Please log in to confirm your order. Your order details are saved.</p><input id="amxEm" type="email" placeholder="Email" autocomplete="email"/><input id="amxPw" type="password" placeholder="Password" autocomplete="current-password"/><div id="amxMsg"></div><button type="button" id="amxLogin">Log in and confirm order</button><a href="#/login" id="amxReg">Create an account</a></div>';
  document.body.appendChild(g);
  var cb = null, $i = function (i) { return document.getElementById(i); };
  function hide() { g.classList.remove("on"); }
  AMX.passed = false;
  AMX.needGate = function () { return !AMX.passed && !(S.user && !S.user.isAnonymous); };
  AMX.gate = function (fn) { cb = fn; $i("amxMsg").textContent = ""; g.classList.add("on"); };
  
  $i("amxLogin").onclick = function () {
    var em = $i("amxEm").value.trim(), pw = $i("amxPw").value; if (!em || !pw) { $i("amxMsg").textContent = "Enter your email and password."; return; }
    if (!FB_OK) { $i("amxMsg").textContent = "Login is not available right now. Please try again later."; return; }
    $i("amxLogin").disabled = true;
    auth.signInWithEmailAndPassword(em, pw).then(function () { AMX.passed = true; $i("amxLogin").disabled = false; hide(); if (cb) cb(); }).catch(function (x) { $i("amxLogin").disabled = false; $i("amxMsg").textContent = nice(x); });
  };
  $i("amxReg").onclick = function () { hide(); if (window.AnasMartCheckout) AnasMartCheckout.close(); };
  g.addEventListener("click", function (e) { if (e.target === g) hide(); });
  var _pl = PH.place;
  PH.place = function (e) { if (AMX.needGate()) { e.preventDefault(); AMX.gate(function () { _pl(e); }); return; } AMX.passed = false; _pl(e); };
})();

PH.buy = function (b) {
  var c = b.closest("[data-pid]"), p = getP(c.getAttribute("data-pid")), s = c.querySelector(".chip.on"), q = c.querySelector("[data-qty]"), v = p.variants[s ? +s.getAttribute("data-i") : 0] || p.variants[0], im = document.querySelector(".pd .pimg img");
  AnasMartCheckout.add({ name: p.name, price: Number(v.price), img: im ? im.src : "", variant: v.size, qty: q ? +q.value : 1, pid: p.id });
};
var busy = 0;
function enh() { if (busy) return; busy = 1; requestAnimationFrame(function () { busy = 0; try { deco(); pdx(); recent(); bn(); ws2(); ws3(); res(); cr(); ck(); rf(); rr(); } catch (e) { console.warn("enh", e); } }); }
new MutationObserver(enh).observe(document.body, { childList: true, subtree: true }); enh();
} catch (e) { console.warn("Enhancements failed", e); }


/* Public bridge for the additive Online Shah Alami marketplace pages. Keeps the existing app state private. */
window.AnasMartExtension = {
  products: function () { return S.products.slice(); },
  allProducts: function () { return S.all.slice(); },
  config: function () { return CONFIG; },
  card: function (p, wl) { return pcard(p, wl).replace('class="pcard rv"', 'class="pcard rv in"'); },
  minPrice: function (p) { return minP(p); },
  money: function (n) { return fmt(n); },
  escape: function (x) { return esc(x); },
  currentUser: function () { return S.user; },
  profile: function () { return S.profile || {}; },
  loadCoupons: function () {
    if (!db) return Promise.resolve([]);
    return snap(db.collection("coupons")).then(function (a) { return a; }).catch(function () { return []; });
  },
  category: function (c) { if (PH && PH.goCat) PH.goCat(c); else location.hash = "#/shop"; },
  search: function (q) { S.q = String(q || ""); S.cat = "All"; location.hash = "#/shop"; if (location.hash === "#/shop") drawShop(); },
  accountTab: function (t) {
    if (!S.user || S.user.isAnonymous) { location.hash = "#/login"; return; }
    S.accTab = t; location.hash = "#/account"; setTimeout(function () { if (location.hash.indexOf("#/account") === 0) drawAccount(); }, 80);
  },
  startAccess: function (type) {
    type = type === "business" ? "business" : "reseller";
    if (!S.user || S.user.isAnonymous) {
      try { localStorage.setItem("am_selected_account_type", type); } catch (e) {}
      S.authTab = "register"; S.redirect = "account"; location.hash = "#/login";
      setTimeout(function () { if (window.PH && PH.atab) PH.atab("register"); var a = document.querySelector('select[name="atype"]'); if (a) a.value = type; }, 120);
      return;
    }
    if (type === "reseller" && S.profile && S.profile.type === "reseller") { this.accountTab("reseller"); return; }
    if (type === "business" && S.profile && S.profile.wholesale) { this.accountTab("wholesale"); return; }
    if (PH && PH.reqAccess) PH.reqAccess(type);
  }
};


/* Final customer profile and admin workspace enhancement layer. */

(function(){
  'use strict';
  function amEsc(v){return typeof esc==='function'?esc(v):String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function key(part){return 'am_customer_'+part+'_'+((S.user&&S.user.uid)||'guest');}
  function localGet(k,d){try{var x=JSON.parse(localStorage.getItem(k));return x==null?d:x;}catch(e){return d;}}
  function localSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
  function msg(t){if(typeof toast==='function')toast(t);else alert(t);}
  function money(n){return typeof fmt==='function'?fmt(n):('PKR '+Number(n||0).toLocaleString('en-PK'));}
  function userReady(){return !!(S.user&&!S.user.isAnonymous);}
  function addrKey(){return key('addresses');}
  function addrList(){var a=localGet(addrKey(),[]);if(!Array.isArray(a))a=[];var p=S.profile||{};if(!a.length&&p.address){a.push({id:'legacy-default',label:'Default address',name:p.name||S.user.displayName||'',phone:p.phone||'',city:p.city||'',postalCode:p.postalCode||'',address:p.address,isDefault:true,legacy:true});}return a;}
  function saveAddrList(a){return localSet(addrKey(),a);}
  function applyDefault(a){if(!a)return;S.profile=Object.assign({},S.profile||{},{name:a.name||((S.profile||{}).name)||'',phone:a.phone||((S.profile||{}).phone)||'',city:a.city||'',address:a.address||'',postalCode:a.postalCode||'',addressLabel:a.label||'Home'});if(typeof FB_OK!=='undefined'&&FB_OK&&db&&S.user){db.collection('users').doc(S.user.uid).set({name:S.profile.name,phone:S.profile.phone,city:S.profile.city,address:S.profile.address,postalCode:S.profile.postalCode,addressLabel:S.profile.addressLabel,updatedMs:Date.now()},{merge:true}).then(function(){msg('Default delivery address synced to your account.');}).catch(function(){msg('Default selected on this browser. Cloud sync was not available.');});}else msg('Default address selected on this browser.');}
  function accountHeaderName(){var p=S.profile||{};return p.name||S.user.displayName||String(S.user.email||'Customer').split('@')[0];}
  function createTab(id,label){return '<button type="button" data-account-tab="'+id+'" class="'+(S.accTab===id?'on':'')+'" onclick="PH.accTab(\''+id+'\')">'+label+'</button>';}
  accTabs=function(){var t=[['overview','▦ Overview'],['profile','♙ Profile'],['addresses','⌂ Addresses'],['orders','▤ Orders'],['track','⌖ Track order'],['wishlist','♡ Wishlist'],['offers','% Vouchers'],['reviews','★ My reviews'],['notifications','♧ Notifications'],['security','⚿ Security']];if(!S.isAdmin)t.push(['wholesale','▥ Wholesale'],['reseller','↗ Reseller']);t.push(['help','? Help']);return t;};
  pAccount=function(){if(!userReady()){location.hash='#/login';return '';}S.hook=drawAccount;S.accTab=S.accTab||'overview';var p=S.profile||{},badges='<span class="st">Customer</span>'+(p.wholesale?' <span class="st">Wholesale approved</span>':'')+(p.type==='reseller'?' <span class="st">Reseller approved</span>':'')+(p.requestedType==='business'&&!p.wholesale?' <span class="st">Wholesale review pending</span>':'')+(p.requestedType==='reseller'&&p.type!=='reseller'?' <span class="st">Reseller review pending</span>':'')+(S.isAdmin?' <span class="st">Admin</span>':'');var initial=(accountHeaderName().trim().charAt(0)||'A').toUpperCase();return banner('My Online Shah Alami','Manage your shopping account, orders and preferences')+'<section class="sec" style="padding-top:28px"><div class="wrap am-customer-shell"><div class="am-customer-hero"><div class="am-customer-avatar">'+amEsc(initial)+'</div><div><h2>Welcome back, '+amEsc(accountHeaderName())+'</h2><p>'+amEsc(S.user.email||'')+(p.phone?' · '+amEsc(p.phone):'')+'</p><div style="margin-top:8px">'+badges+'</div></div><div class="am-customer-hero-actions"><a class="btn sm" href="#/shop">Continue shopping</a><a class="btn ghost sm" href="#/cart">View cart ('+cartCount()+')</a>'+(S.isAdmin?'<a class="btn dk sm" href="#/admin">Admin</a>':'')+'<button class="btn ghost sm" onclick="PH.logout()">Sign out</button></div></div><div id="atabs2" class="am-customer-tabs" role="tablist" aria-label="Customer account sections"></div><div id="acc" aria-live="polite"></div></div></section>';};
  drawAccount=function(){var tb=$('#atabs2');if(!tb)return;var t=accTabs(),cur=S.accTab||'overview';if(!t.some(function(x){return x[0]===cur;}))cur=S.accTab='overview';tb.innerHTML=t.map(function(x){return createTab(x[0],x[1]);}).join('');var map={overview:amTabOverview,profile:tabProfile,addresses:amTabAddresses,orders:tabOrders,track:tabTrack,wishlist:amTabWishlist,offers:amTabOffers,reviews:amTabReviews,notifications:amTabNotifications,security:amTabSecurity,wholesale:drawWholesale,reseller:drawReseller,help:tabHelp};if(map[cur])map[cur]();};
  PH.accTab=function(t){S.accTab=t;drawAccount();};

  tabProfile=function(){var b=$('#acc'),p=S.profile||{};if(!b)return;b.innerHTML='<div class="am-customer-grid"><form class="am-customer-panel" onsubmit="PH.profSave(event)"><div class="bar"><div><h3>Personal information</h3><p>Update the details used for checkout and order updates.</p></div><span class="am-customer-status">Editable</span></div><div id="pfmsg"></div><div class="g2"><div class="fld"><label>Full name</label><input name="name" autocomplete="name" required value="'+amEsc(p.name||S.user.displayName||'')+'"></div><div class="fld"><label>Phone / WhatsApp</label><input name="phone" autocomplete="tel" required value="'+amEsc(p.phone||'')+'"></div></div><div class="g2"><div class="fld"><label>City</label><input name="city" list="am-account-cities" autocomplete="address-level2" value="'+amEsc(p.city||'')+'"><datalist id="am-account-cities">'+(PK_CITIES||[]).map(function(c){return '<option value="'+amEsc(c)+'"></option>';}).join('')+'</datalist></div><div class="fld"><label>Email address</label><input value="'+amEsc(S.user.email||'')+'" disabled></div></div><div class="fld"><label>Default delivery address</label><textarea name="address" rows="3" autocomplete="street-address">'+amEsc(p.address||'')+'</textarea></div><div class="am-customer-actions"><button class="btn" type="submit">Save personal details</button><button class="btn ghost" type="button" onclick="PH.accTab(\'addresses\')">Manage address book</button></div><div class="am-customer-notice">Your account email is managed by the sign-in provider. Never enter bank passwords or payment-card details into your profile.</div></form><div><div class="am-customer-panel" style="margin-bottom:14px"><h3>Account summary</h3><div class="am-customer-detail-placeholder"></div><table class="info"><tr><th>Member since</th><td>'+(p.createdMs?new Date(p.createdMs).toLocaleDateString():'Not available')+'</td></tr><tr><th>Account type</th><td>'+amEsc([p.type==='reseller'?'Reseller':'',p.wholesale?'Wholesale buyer':'','Customer'].filter(Boolean).join(' · '))+'</td></tr><tr><th>Email verification</th><td>'+(S.user.emailVerified?'Verified':'Not verified / unknown')+'</td></tr><tr><th>Wishlist items</th><td>'+S.wish.length+'</td></tr><tr><th>Cart items</th><td>'+cartCount()+'</td></tr></table></div><div class="am-customer-panel"><h3>Manage your account</h3><div class="am-customer-shortcuts"><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'orders\');return false"><i>📦</i><span><b>Orders</b><small>History and reorders</small></span></a><a class="am-customer-shortcut" href="#/wishlist"><i>♡</i><span><b>Wishlist</b><small>Saved products</small></span></a><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'offers\');return false"><i>🏷️</i><span><b>Vouchers</b><small>Available offers</small></span></a><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'security\');return false"><i>🔐</i><span><b>Security</b><small>Password and sign-in</small></span></a></div></div></div></div>';};

  function amTabOverview(){var b=$('#acc');if(!b)return;var a=S.myo||[];var active=a.filter(function(o){return o.status!=='Cancelled';});var spent=active.reduce(function(n,o){return n+(Number(o.total)||0);},0);b.innerHTML='<div class="am-customer-stat-grid"><div class="am-customer-stat"><span class="am-mini-icon">📦</span><small>Total orders</small><b id="am-cstat-orders">'+a.length+'</b></div><div class="am-customer-stat"><span class="am-mini-icon">💳</span><small>Total spent*</small><b id="am-cstat-spent">'+money(spent)+'</b></div><div class="am-customer-stat"><span class="am-mini-icon">♡</span><small>Wishlist</small><b>'+S.wish.length+'</b></div><div class="am-customer-stat"><span class="am-mini-icon">🛒</span><small>Cart lines</small><b>'+cartCount()+'</b></div></div><div class="am-customer-grid"><div class="am-customer-panel"><div class="bar"><div><h3>Recent orders</h3><p>Latest activity from your Online Shah Alami account.</p></div><button class="btn ghost sm" onclick="PH.accTab(\'orders\')">All orders</button></div><div id="am-account-recent-orders">'+(a.length?a.slice(0,4).map(amOrderLine).join(''):'<div class="empty"><div class="big">📦</div><p>No orders found yet.</p><a class="btn sm" href="#/shop">Explore products</a></div>')+'</div><p class="am-customer-muted" style="margin-top:9px">*Spend is calculated from the order history currently available to your account.</p></div><div class="am-customer-panel"><h3>Quick actions</h3><div class="am-customer-shortcuts"><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'addresses\');return false"><i>📍</i><span><b>Address book</b><small>Delivery addresses</small></span></a><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'track\');return false"><i>🚚</i><span><b>Track order</b><small>Delivery progress</small></span></a><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'reviews\');return false"><i>⭐</i><span><b>My reviews</b><small>Submitted feedback</small></span></a><a class="am-customer-shortcut" href="#/account" onclick="PH.accTab(\'help\');return false"><i>💬</i><span><b>Help centre</b><small>Chat and FAQs</small></span></a></div><div class="am-customer-notice">'+amEsc((S.profile&&S.profile.address)?('Default delivery: '+S.profile.address+', '+(S.profile.city||'')):'Add a delivery address to speed up your next checkout.')+'</div></div></div>';if(!S.myo){loadMyOrders().then(function(orders){var node=$('#am-account-recent-orders');if(!node)return;var good=orders.filter(function(o){return o.status!=='Cancelled';});$('#am-cstat-orders').textContent=orders.length;$('#am-cstat-spent').textContent=money(good.reduce(function(n,o){return n+(Number(o.total)||0);},0));node.innerHTML=orders.length?orders.slice(0,4).map(amOrderLine).join(''):'<div class="empty"><div class="big">📦</div><p>No orders found yet.</p><a class="btn sm" href="#/shop">Explore products</a></div>';}).catch(function(){});}}
  function amOrderLine(o){return '<div class="am-customer-order"><div><b>'+amEsc(o.orderNo||o.id||'Order')+'</b><small>'+new Date(Number(o.createdMs)||Date.now()).toLocaleDateString()+' · '+(o.items||[]).length+' line(s) · '+money(o.total)+'</small><small>Payment: '+amEsc(o.paymentMethod||'Not recorded')+'</small></div><div style="text-align:right"><span class="am-customer-status">'+amEsc(o.status||'Pending')+'</span><div style="margin-top:8px"><button type="button" class="btn ghost sm" onclick="PH.track(\''+amEsc(o.id||'')+'\')">Track</button></div></div></div>';}
  function amTabAddresses(){var b=$('#acc');if(!b)return;var a=addrList();b.innerHTML='<div class="am-customer-grid"><div class="am-customer-panel"><div class="bar"><div><h3>Address book</h3><p>Save different destinations for home, work or business deliveries.</p></div><span class="am-customer-status">'+a.length+' saved</span></div>'+(a.length?a.map(function(x){return '<article class="am-customer-address '+(x.isDefault?'default':'')+'"><div class="am-customer-address-head"><b>'+amEsc(x.label||'Delivery address')+'</b>'+(x.isDefault?'<span class="am-customer-status">Default</span>':'')+'</div><p style="margin:8px 0 0"><b>'+amEsc(x.name||'')+'</b><br>'+amEsc(x.phone||'')+'<br>'+amEsc(x.address||'')+'<br>'+amEsc([x.city,x.postalCode].filter(Boolean).join(', '))+'</p><div class="am-customer-actions">'+(!x.isDefault?'<button class="btn sm" onclick="AMCustomerUI.setDefault(\''+amEsc(x.id)+'\')">Set default</button>':'')+'<button class="btn ghost sm" onclick="AMCustomerUI.editAddress(\''+amEsc(x.id)+'\')">Edit</button><button class="btn red sm" onclick="AMCustomerUI.deleteAddress(\''+amEsc(x.id)+'\')">Delete</button></div></article>';}).join(''):'<div class="empty"><div class="big">📍</div><p>No saved addresses yet. Add an address using the form.</p></div>')+'<div class="am-customer-notice">Multiple addresses are stored on this browser. Selecting a default also attempts to sync the primary address to your signed-in profile when Firebase is available.</div></div><form class="am-customer-panel" onsubmit="AMCustomerUI.saveAddress(event)"><h3>Add a new address</h3><div class="fld"><label>Address label</label><select name="label"><option>Home</option><option>Work</option><option>Business</option><option>Other</option></select></div><div class="fld"><label>Recipient name</label><input name="name" required value="'+amEsc((S.profile||{}).name||S.user.displayName||'')+'"></div><div class="fld"><label>Phone</label><input name="phone" required value="'+amEsc((S.profile||{}).phone||'')+'"></div><div class="fld"><label>City</label><input name="city" list="am-account-cities" required value="'+amEsc((S.profile||{}).city||'')+'"></div><div class="fld"><label>Postal code (optional)</label><input name="postalCode" inputmode="numeric" maxlength="16"></div><div class="fld"><label>Full address</label><textarea name="address" rows="3" required placeholder="House / building, street, area"></textarea></div><label class="row" style="gap:8px;margin-bottom:15px"><input type="checkbox" name="isDefault" style="width:auto" '+(!a.some(function(x){return x.isDefault;})?'checked':'')+'> Make this my default delivery address</label><button class="btn" type="submit">Save address</button></form></div>';}
  function amTabWishlist(){var b=$('#acc');if(!b)return;var items=(S.wish||[]).map(function(id){return (S.all||[]).filter(function(p){return String(p.id)===String(id);})[0];}).filter(Boolean);b.innerHTML='<div class="am-customer-panel"><div class="bar"><div><h3>Your wishlist</h3><p>Products you saved to consider later.</p></div><a href="#/shop" class="btn sm">Find more products</a></div>'+(items.length?'<div class="grid">'+items.map(function(p){return '<article class="pcard"><a href="#/product/'+encodeURIComponent(p.id)+'"><div class="pimg">'+(typeof pimg==='function'?pimg(p,hueOf(p)):'<div class="ptile">🛍️</div>')+'</div></a><div class="pbody"><span class="pcat">'+amEsc(p.cat||'General')+'</span><h3><a href="#/product/'+encodeURIComponent(p.id)+'">'+amEsc(p.name)+'</a></h3><div class="price">'+money(minP(p))+'</div><div class="am-customer-actions"><a class="btn sm" href="#/product/'+encodeURIComponent(p.id)+'">View product</a><button class="btn red sm" onclick="AMCustomerUI.removeWishlist(\''+amEsc(p.id)+'\')">Remove</button></div></div></article>';}).join('')+'</div>':'<div class="empty"><div class="big">♡</div><p>Your wishlist is empty.</p><a class="btn" href="#/shop">Explore products</a></div>')+'</div>';}
  function amTabOffers(){var b=$('#acc');if(!b)return;b.innerHTML='<div class="am-customer-panel"><h3>Vouchers and offers</h3><p>Available discount codes from Online Shah Alami. Codes are validated again at checkout.</p><div id="am-account-coupons"><p>Checking active offers…</p></div></div>';var box=$('#am-account-coupons');if(!(typeof FB_OK!=='undefined'&&FB_OK&&db)){box.innerHTML='<div class="am-customer-notice">Connect Firebase to retrieve active vouchers. You can still enter a coupon code at checkout if Online Shah Alami has issued one.</div>';return;}db.collection('coupons').where('active','==',true).get().then(function(s){var coupons=[];s.forEach(function(d){var c=d.data();c.id=d.id;c.code=c.code||d.id;if(!c.expiresMs||c.expiresMs>Date.now())coupons.push(c);});if(!$('#am-account-coupons'))return;$('#am-account-coupons').innerHTML=coupons.length?coupons.map(function(c){return '<div class="am-customer-coupon"><div><code>'+amEsc(c.code)+'</code><b style="display:block;margin-top:5px">'+(c.type==='percent'?Number(c.value)+'% off':money(c.value)+' off')+'</b><small>Minimum order: '+(c.minOrder?money(c.minOrder):'No minimum listed')+' · '+(c.expiresMs?'Expires '+new Date(c.expiresMs).toLocaleDateString():'No expiry listed')+'</small></div><div class="am-customer-actions"><button class="btn sm" onclick="AMCustomerUI.copyCoupon(\''+amEsc(c.code)+'\')">Copy code</button><a class="btn ghost sm" href="#/checkout">Shop / checkout</a></div></div>';}).join(''):'<div class="empty"><div class="big">🏷️</div><p>No active vouchers are available at the moment.</p><a class="btn" href="#/shop">Explore deals</a></div>';}).catch(function(){var x=$('#am-account-coupons');if(x)x.innerHTML='<div class="am-customer-notice">We could not load vouchers for this account. Please try again later or use the coupon code sent by Online Shah Alami.</div>';});}
  function amTabReviews(){var b=$('#acc');if(!b)return;b.innerHTML='<div class="am-customer-panel"><h3>My reviews</h3><p>Reviews you submitted for products, including pending moderation status.</p><div id="am-my-review-list"><p>Loading your reviews…</p></div></div>';var box=$('#am-my-review-list');if(!(typeof FB_OK!=='undefined'&&FB_OK&&db)){box.innerHTML='<div class="am-customer-notice">Sign in with the configured Firebase project to retrieve saved reviews.</div>';return;}db.collection('reviews').where('userId','==',S.user.uid).get().then(function(s){var a=[];s.forEach(function(d){var x=d.data();x.id=d.id;a.push(x);});a.sort(function(x,y){return (y.createdMs||0)-(x.createdMs||0);});if(!$('#am-my-review-list'))return;$('#am-my-review-list').innerHTML=a.length?'<div class="tw"><table><tr><th>Product</th><th>Rating</th><th>Your review</th><th>Status</th><th>Date</th></tr>'+a.map(function(r){return '<tr><td>'+amEsc(r.productName||'Product')+'</td><td>'+stars(r.rating)+'</td><td>'+amEsc(r.text||'')+'</td><td><span class="am-customer-status">'+(r.approved?'Published':'Pending review')+'</span></td><td>'+new Date(r.createdMs||Date.now()).toLocaleDateString()+'</td></tr>';}).join('')+'</table></div>':'<div class="empty"><div class="big">⭐</div><p>You have not submitted any reviews yet.</p><a class="btn" href="#/shop">Shop products</a></div>';}).catch(function(){if($('#am-my-review-list'))$('#am-my-review-list').innerHTML='<div class="am-customer-notice">Reviews could not be loaded. Check the reviews collection permissions.</div>';});}
  function amTabNotifications(){var b=$('#acc');if(!b)return;var p=localGet(key('preferences'),{orderUpdates:true,promotions:false,preferredChannel:'Email'});b.innerHTML='<div class="am-customer-grid"><form class="am-customer-panel" onsubmit="AMCustomerUI.savePreferences(event)"><h3>Notification preferences</h3><p>Choose which updates you prefer. These choices are saved locally in this browser until account preferences are connected to the backend.</p><label class="row" style="gap:10px;margin:16px 0"><input name="orderUpdates" type="checkbox" style="width:auto" '+(p.orderUpdates?'checked':'')+'> Order status and delivery updates</label><label class="row" style="gap:10px;margin:16px 0"><input name="promotions" type="checkbox" style="width:auto" '+(p.promotions?'checked':'')+'> Promotions and new product announcements</label><div class="fld"><label>Preferred contact channel</label><select name="preferredChannel"><option '+(p.preferredChannel==='Email'?'selected':'')+'>Email</option><option '+(p.preferredChannel==='SMS / Phone'?'selected':'')+'>SMS / Phone</option><option '+(p.preferredChannel==='WhatsApp'?'selected':'')+'>WhatsApp</option></select></div><button class="btn" type="submit">Save preferences</button><div id="am-pref-result" class="am-customer-notice" style="display:none"></div></form><div class="am-customer-panel"><h3>Recent account activity</h3><div id="am-account-activity"><p>Loading orders and activity…</p></div></div></div>';loadMyOrders().then(function(a){var x=$('#am-account-activity');if(!x)return;x.innerHTML=a.length?a.slice(0,6).map(amOrderLine).join(''):'<p>No order updates to show yet.</p>';}).catch(function(){});}
  function amTabSecurity(){var b=$('#acc');if(!b)return;b.innerHTML='<div class="am-customer-grid"><div class="am-customer-panel"><h3>Sign-in and security</h3><p>Manage the sign-in address and password for your account.</p><table class="info"><tr><th>Account email</th><td>'+amEsc(S.user.email||'')+'</td></tr><tr><th>Email verification</th><td>'+(S.user.emailVerified?'Verified':'Not verified')+'</td></tr><tr><th>Sign-in provider</th><td>Configured account provider</td></tr></table><div class="am-customer-actions"><button class="btn" onclick="PH.pwReset()">Send password reset email</button>'+(S.user.emailVerified?'':'<button class="btn ghost" onclick="AMCustomerUI.verifyEmail()">Send verification email</button>')+'<button class="btn red" onclick="PH.logout()">Sign out</button></div></div><div class="am-customer-panel"><h3>Privacy and payment safety</h3><p>Your password is handled by the authentication provider. This profile does not store full payment card numbers or wallet passwords.</p><div class="am-customer-notice">For account deletion, payment disputes, data correction, or privacy requests, contact Online Shah Alami support so the request can be verified before action.</div><a class="btn ghost sm" href="#/policies/privacy">Read privacy policy</a> <a class="btn ghost sm" href="#/contact">Contact support</a></div></div>';}
  window.AMCustomerUI={saveAddress:function(e){e.preventDefault();var f=e.target,a={id:'addr-'+Date.now(),label:f.elements['label'].value,name:f.elements['name'].value.trim(),phone:f.elements['phone'].value.trim(),city:f.elements['city'].value.trim(),postalCode:f.elements['postalCode'].value.trim(),address:f.elements['address'].value.trim(),isDefault:!!f.elements['isDefault'].checked,createdMs:Date.now()};if(!a.name||!a.phone||!a.city||!a.address){msg('Fill in recipient, phone, city and full address.');return;}var list=addrList();if(a.isDefault||!list.some(function(x){return x.isDefault;}))list.forEach(function(x){x.isDefault=false;});if(a.isDefault||!list.length)a.isDefault=true;list.push(a);saveAddrList(list);if(a.isDefault)applyDefault(a);amTabAddresses();msg('Address saved.');},setDefault:function(id){var list=addrList(),a=list.filter(function(x){return String(x.id)===String(id);})[0];if(!a)return;list.forEach(function(x){x.isDefault=String(x.id)===String(id);});saveAddrList(list);applyDefault(a);amTabAddresses();},deleteAddress:function(id){if(!confirm('Delete this saved address?'))return;var list=addrList().filter(function(x){return String(x.id)!==String(id);});if(list.length&&!list.some(function(x){return x.isDefault;}))list[0].isDefault=true;saveAddrList(list);if(list[0]&&list[0].isDefault)applyDefault(list[0]);amTabAddresses();msg('Address deleted.');},editAddress:function(id){var a=addrList().filter(function(x){return String(x.id)===String(id);})[0];if(!a)return;modal('<h3 style="margin-bottom:12px">Edit saved address</h3><form onsubmit="AMCustomerUI.updateAddress(event,\''+amEsc(id)+'\')"><div class="fld"><label>Address label</label><input name="label" value="'+amEsc(a.label||'Home')+'" required></div><div class="fld"><label>Recipient name</label><input name="name" value="'+amEsc(a.name||'')+'" required></div><div class="fld"><label>Phone</label><input name="phone" value="'+amEsc(a.phone||'')+'" required></div><div class="g2"><div class="fld"><label>City</label><input name="city" value="'+amEsc(a.city||'')+'" required></div><div class="fld"><label>Postal code</label><input name="postalCode" value="'+amEsc(a.postalCode||'')+'"></div></div><div class="fld"><label>Full address</label><textarea name="address" rows="3" required>'+amEsc(a.address||'')+'</textarea></div><label class="row" style="gap:8px;margin-bottom:12px"><input name="isDefault" type="checkbox" style="width:auto" '+(a.isDefault?'checked':'')+'> Default address</label><button class="btn" type="submit">Save address</button></form>');},updateAddress:function(e,id){e.preventDefault();var f=e.target,list=addrList(),a=list.filter(function(x){return String(x.id)===String(id);})[0];if(!a)return;a.label=f.elements['label'].value.trim();a.name=f.elements['name'].value.trim();a.phone=f.elements['phone'].value.trim();a.city=f.elements['city'].value.trim();a.postalCode=f.elements['postalCode'].value.trim();a.address=f.elements['address'].value.trim();a.isDefault=!!f.elements['isDefault'].checked;if(a.isDefault)list.forEach(function(x){x.isDefault=x.id===a.id;});saveAddrList(list);if(a.isDefault)applyDefault(a);closeModal();amTabAddresses();msg('Address updated.');},removeWishlist:function(id){if(window.PH&&PH.wish)PH.wish(String(id));setTimeout(amTabWishlist,40);},copyCoupon:function(code){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(code).then(function(){msg('Coupon copied: '+code);}).catch(function(){prompt('Copy coupon code',code);});else prompt('Copy coupon code',code);},savePreferences:function(e){e.preventDefault();var f=e.target,p={orderUpdates:!!f.elements['orderUpdates'].checked,promotions:!!f.elements['promotions'].checked,preferredChannel:f.elements['preferredChannel'].value,updatedMs:Date.now()};localSet(key('preferences'),p);var x=$('#am-pref-result');if(x){x.style.display='block';x.textContent='Preferences saved on this browser.';}msg('Notification preferences saved.');},verifyEmail:function(){if(!FB_OK||!auth||!auth.currentUser||!auth.currentUser.sendEmailVerification){msg('Email verification is not available until Firebase Auth is configured.');return;}auth.currentUser.sendEmailVerification().then(function(){msg('Verification email sent. Check your inbox and spam folder.');}).catch(function(e){msg(nice(e));});}};

  /* Professional admin layout with the existing working operational tabs. */
  var adminTabs=[['dashboard','▦','Overview'],['revenue','▥','Revenue & analytics'],['products','▣','Products & inventory'],['categories','◈','Categories'],['orders','▤','Orders & delivery'],['discounts','%','Discounts & vouchers'],['delivery','🚚','Delivery settings'],['customers','♙','Customers & profiles'],['reviews','★','Reviews'],['payouts','↗','Reseller payouts'],['resellerSettings','🤝','Reseller rules'],['chat','◌','Live chat'],['faq','?','FAQ & chat questions'],['messages','✉','Messages'],['pages','▧','Pages & content'],['site','⚙','Store settings']];
  pAdmin=function(){if(!S.isAdmin&&auth&&auth.currentUser&&isAdminEmail(auth.currentUser.email)){S.user=auth.currentUser;S.isAdmin=true;}if(!S.isAdmin){if(!S.user)S.redirect='admin';location.hash=S.user?'#/account':'#/login';return '';}S.hook=function(){if(S.adm.loaded)drawAdmin();else loadAdmin();};var nav=adminTabs.map(function(t){return '<button type="button" data-tab="'+t[0]+'" data-label="'+amEsc(t[2].toLowerCase())+'" class="'+(S.tab===t[0]?'on':'')+'" onclick="PH.tab(\''+t[0]+'\')"><span>'+t[1]+'</span><b>'+t[2]+'</b></button>';}).join('')+'<button type="button" data-tab="refresh" onclick="PH.refresh()"><span>⟳</span><b>Refresh data</b></button><button type="button" data-tab="logout" onclick="PH.logout()"><span>↪</span><b>Sign out</b></button>';return banner('Online Shah Alami Admin Workspace','Orders, customers, revenue, merchandising and support operations')+'<section class="sec" style="padding-top:26px"><div class="am-admin-workspace"><aside class="am-admin-sidebar"><div class="am-admin-brand"><div class="am-admin-brand-mark">AM</div><div><b>Online Shah Alami</b><small>STORE OPERATIONS</small></div></div><label for="am-admin-nav-search">Find an admin section</label><input id="am-admin-nav-search" type="search" placeholder="Search tools…" oninput="AMAdminUI.navFilter(this.value)"><nav id="atabs" aria-label="Administration sections">'+nav+'</nav></aside><main class="am-admin-main"><div class="am-admin-mainhead"><div><h2 id="am-admin-current-title">'+amEsc((adminTabs.filter(function(t){return t[0]===S.tab;})[0]||adminTabs[0])[2])+'</h2><p>Signed in as '+amEsc(S.user.email||'Authorized administrator')+' · Use the left navigation to manage the store.</p></div><div class="am-admin-head-actions"><button class="btn ghost sm" onclick="PH.refresh()">⟳ Refresh</button><a class="btn ghost sm" href="#/home" target="_blank">View storefront ↗</a></div></div><div id="adm"><p>Loading admin data…</p></div></main></div></section>';};

  var _amDrawAdmin=drawAdmin;
  drawAdmin=function(){_amDrawAdmin();var nav=$('#atabs');if(nav){nav.querySelectorAll('button[data-tab]').forEach(function(bt){bt.classList.toggle('on',bt.getAttribute('data-tab')===S.tab);});}var title=$('#am-admin-current-title');if(title){var item=adminTabs.filter(function(t){return t[0]===S.tab;})[0];title.textContent=item?item[2]:'Admin tools';}var b=$('#adm');if(!b)return;
    if(S.tab==='dashboard'){var q='<div class="am-admin-shortcuts">'+[['orders','📦','Manage orders','Fulfillment and status'],['customers','👥','Customer profiles','Contacts and access'],['revenue','📈','Revenue reports','Sales and payment split'],['discounts','🏷️','Discounts','Coupons and offers'],['delivery','🚚','Delivery rules','Fees and city rates'],['reviews','⭐','Review moderation','Approve or hide feedback'],['payouts','💸','Payout requests','Review settlements'],['chat','💬','Live chat','Reply to customers'],['faq','❔','FAQ questions','Manage chat suggestions'],['messages','✉️','Message inbox','Reply to enquiries'],['products','📦','Products','Catalog and stock'],['categories','🗂️','Categories','Merchandising']].map(function(t){return '<button class="am-admin-shortcut" type="button" onclick="PH.tab(\''+t[0]+'\')"><span>'+t[1]+'</span><span><b>'+t[2]+'</b><small>'+t[3]+'</small></span></button>';}).join('')+'</div>';var first=b.querySelector('.stat-grid');if(first)first.insertAdjacentHTML('afterend',q);else b.insertAdjacentHTML('afterbegin',q);}
    var filterTabs=['customers','orders','products','discounts','reviews','messages','payouts'];if(filterTabs.indexOf(S.tab)>-1){var tw=b.querySelector('.tw');if(tw&&!b.querySelector('.am-admin-table-tools')){var tools=document.createElement('div');tools.className='am-admin-table-tools';tools.innerHTML='<input class="inp" type="search" placeholder="Search this table…" aria-label="Search current admin table" oninput="AMAdminUI.tableFilter(this.value)"><small>Filter visible rows; source records are unchanged.</small>';tw.parentNode.insertBefore(tools,tw);}}
    if(S.tab==='customers'){var rows=b.querySelectorAll('.tw table tr');for(var i=1;i<rows.length;i++){var u=(S.adm.users||[])[i-1],cell=rows[i].lastElementChild;if(!u||!cell||cell.querySelector('[data-am-user-details]'))continue;var bt=document.createElement('button');bt.type='button';bt.className='btn ghost sm';bt.textContent='Details';bt.setAttribute('data-am-user-details','1');bt.addEventListener('click',(function(id){return function(){PH.userDetails(id);};})(u.id));cell.insertBefore(bt,cell.firstChild);}}
  };
  PH.tab=function(t){if(t==='refresh'){PH.refresh();return;}if(t==='logout'){PH.logout();return;}S.tab=t;drawAdmin();};
  window.AMAdminUI={navFilter:function(q){q=String(q||'').toLowerCase().trim();var n=$('#atabs');if(!n)return;n.querySelectorAll('button[data-tab]').forEach(function(b){var label=(b.getAttribute('data-label')||b.textContent||'').toLowerCase();b.style.display=(!q||label.indexOf(q)>-1)?'':'none';});},tableFilter:function(q){q=String(q||'').toLowerCase().trim();var t=$('#adm table');if(!t)return;var rows=t.querySelectorAll('tr'),shown=0;for(var i=1;i<rows.length;i++){var ok=!q||rows[i].textContent.toLowerCase().indexOf(q)>-1;rows[i].style.display=ok?'':'none';if(ok)shown++;}var n=$('.am-admin-table-tools small');if(n)n.textContent=shown+' matching row(s) · source records are unchanged.';}};
  PH.userDetails=function(id){var u=(S.adm.users||[]).filter(function(x){return String(x.id)===String(id);})[0];if(!u)return;var orders=(S.adm.orders||[]).filter(function(o){return String(o.userId||'')===String(id)||String(o.userEmail||'').toLowerCase()===String(u.email||'').toLowerCase()||String((o.customer||{}).email||'').toLowerCase()===String(u.email||'').toLowerCase();});orders.sort(function(a,b){return (b.createdMs||0)-(a.createdMs||0);});var spent=orders.filter(function(o){return o.status!=='Cancelled';}).reduce(function(n,o){return n+(Number(o.total)||0);},0);var phone=String(u.phone||'').replace(/[^0-9]/g,'');var role=[u.type==='reseller'?'Reseller':'',u.wholesale?'Wholesale buyer':'',u.requestedType?'Requested: '+u.requestedType:''].filter(Boolean).join(' · ')||'Customer';var details=[['Full name',u.name],['Email',u.email],['Phone / WhatsApp',u.phone],['City',u.city],['Default address',u.address],['Postal code',u.postalCode],['Account role',role],['Joined',u.createdMs?new Date(u.createdMs).toLocaleString():'Not recorded'],['Company',u.companyName||u.company||'Not recorded'],['Business type',u.buyerType||'Not recorded'],['Access review',u.requestedType&&((u.type==='reseller')||(u.wholesale))?'Review approved access and any remaining requests':(u.requestedType?'Requested access may need review':'No pending access request')]];var html='<h3 style="margin-bottom:5px">Customer profile</h3><p style="color:var(--mut);margin-bottom:16px">Customer details and order summary from the currently loaded store records.</p><div class="stat-grid"><div class="stat"><b>'+orders.length+'</b>Orders</div><div class="stat"><b>'+money(spent)+'</b>Non-cancelled order value</div><div class="stat"><b>'+orders.filter(function(o){return o.status==='Delivered';}).length+'</b>Delivered</div></div><div class="am-admin-customer-detail-grid">'+details.map(function(x){return '<div class="am-admin-customer-detail"><small>'+amEsc(x[0])+'</small><b>'+amEsc(x[1]||'Not recorded')+'</b></div>';}).join('')+'</div><div class="am-customer-actions" style="margin:14px 0 20px">'+(u.email?'<a class="btn sm" href="mailto:'+amEsc(u.email)+'?subject='+encodeURIComponent('Online Shah Alami customer support')+'">Email customer</a>':'')+(phone?'<a class="btn ghost sm" target="_blank" rel="noopener" href="https://wa.me/'+phone+'">WhatsApp customer</a>':'')+'</div><h4 style="margin-bottom:10px">Recent order history</h4>'+(orders.length?'<div class="tw"><table><tr><th>Order</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th></tr>'+orders.slice(0,12).map(function(o){return '<tr><td>'+amEsc(o.orderNo||o.id)+'</td><td>'+new Date(o.createdMs||Date.now()).toLocaleDateString()+'</td><td>'+money(o.total)+'</td><td>'+amEsc(o.paymentMethod||'—')+'</td><td>'+amEsc(o.status||'Pending')+'</td></tr>';}).join('')+'</table></div>':'<div class="empty"><p>No orders matched this customer record.</p></div>')+'<div class="am-customer-notice">Personal details shown here are limited to records returned by the configured database. Sensitive identity documents or full payment credentials should not be displayed in this dashboard.</div>';modal(html);};
  /* Add richer customer detail context to existing order view without changing order-state logic. */
})();

/* Re-render the current route after replacing account/admin renderers. */
render();

})();


/* ===== Extracted inline script 0 ===== */

(function(){
  // Ensure the thank-you screen has no WhatsApp CTA and always offers a shopping path.
  function patchThanks(){
    var wa=document.getElementById('amTkWa');
    if(wa){var a=document.createElement('a');a.id='amTkExplore';a.className=wa.className||'am-btn';a.href='#/home';a.textContent='Explore More Items';a.addEventListener('click',function(){var modal=document.getElementById('amThanks');if(modal)modal.classList.remove('on');document.body.style.overflow='';});wa.replaceWith(a);}
    document.querySelectorAll('.wa, a[href*="wa.me"]').forEach(function(el){
      if(el.id==='amTkWa'||el.closest('#amThanks'))el.remove();
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',patchThanks);else patchThanks();
  document.addEventListener('click',function(e){
    var b=e.target.closest('.am-product-thumbnails img');
    if(!b)return;
    var wrap=b.closest('.am-product-gallery');var main=wrap&&wrap.querySelector('.am-product-main-image');
    if(main)main.src=b.src;
  });
  // Product records can carry image, images[], and variant-specific images[]/image.
  // Normalize these fields for compatible renderers without overwriting existing data.
  window.AMNormalizeProductImages=function(p){
    p=p||{};p.images=Array.isArray(p.images)?p.images:(p.image?[p.image]:[]);
    p.variants=Array.isArray(p.variants)?p.variants:[];
    p.variants.forEach(function(v){if(!Array.isArray(v.images))v.images=v.image?[v.image]:[];});
    return p;
  };
})();


/* ===== Extracted inline script 2 ===== */
(function(){
function vOf(c){return c&&c.querySelector&&c.querySelector("video.hv")}
function go(c){var v=vOf(c);if(!v)return;v.muted=true;v.defaultMuted=true;if(v.paused){var p=v.play();if(p&&p.catch)p.catch(function(){})}}
function stop(c){var v=vOf(c);if(v){v.pause();v.currentTime=0}}
document.addEventListener("mouseover",function(e){var c=e.target.closest&&e.target.closest(".pcard");if(c)go(c)});
document.addEventListener("mouseout",function(e){var c=e.target.closest&&e.target.closest(".pcard");if(c&&!c.contains(e.relatedTarget))stop(c)});
document.addEventListener("touchstart",function(e){var c=e.target.closest&&e.target.closest(".pcard");document.querySelectorAll(".pcard").forEach(function(x){if(x!==c)stop(x)});if(c)go(c)},{passive:true});
})();

/* ===== Extracted inline script 3 ===== */

(function(){
  /* ================= SETTINGS ================= */
  var SELLER_WHATSAPP = (window.AMX ? AMX.cfg().wa : ''); // <-- Apna WhatsApp number (92 se shuru, bina + aur space)
  var STORE_NAME      = 'Online Shah Alami';
  var WEBHOOK_URL     = '';             // Optional: Google Apps Script / Sheet URL (khali chhor dein to skip)
  var HOOK_BUY_NOW    = false;          // true karein to "Buy Now" buttons seedha ye form kholein
  var BUY_SEL = '.buy-now,.btn-buy,.buy-btn,button[class*="buy"]';

  /* ---- Price / charges (Rs.) ---- */
  var DEFAULT_PRICE = 1500;      // jab button par data-price na ho
  var DELIVERY = 200;            // Delivery charges
  var COD_FEE = 80;             // Cash on Delivery charges (PKR)
  var FREE_DELIVERY_ABOVE = 0;   // is raqam se upar delivery free (0 = band)
  /* ---- Discount codes: t = 'percent' ya 'flat' ---- */
  var DISCOUNTS = {};
  /* ---- Payment account details (apni asal details likhein) ---- */
  var ACCOUNTS = {
    wallet:[{n:'JazzCash',title:'Account Title',no:'03XX-XXXXXXX'},{n:'Easypaisa',title:'Account Title',no:'03XX-XXXXXXX'}],
    bank:[{n:'Bank Name',title:'Account Title',no:'Account No: XXXXXXXXXXXXXX',iban:'PK00XXXX0000000000000000'}]
  };

  /* ================= PAKISTAN DATA ================= */
  /* Province -> Cities */
  var RAW = {
    "Punjab":"Lahore,Faisalabad,Rawalpindi,Multan,Gujranwala,Sialkot,Bahawalpur,Sargodha,Sahiwal,Gujrat,Sheikhupura,Jhang,Rahim Yar Khan,Kasur,Okara,Dera Ghazi Khan,Chiniot,Mandi Bahauddin,Hafizabad,Narowal,Jhelum,Attock,Chakwal,Khanewal,Vehari,Lodhran,Pakpattan,Toba Tek Singh,Bhakkar,Mianwali,Khushab,Layyah,Muzaffargarh,Rajanpur,Bahawalnagar,Nankana Sahib,Burewala,Wazirabad,Kamoke,Hasilpur,Taxila,Wah Cantt,Murree,Daska,Sambrial,Muridke,Gojra,Kamalia,Arifwala,Chishtian,Khanpur,Sadiqabad,Ahmedpur East,Jaranwala,Samundri,Dina,Kharian,Mian Channu,Haroonabad,Fort Abbas,Liaquatpur,Kot Addu,Taunsa,Shorkot,Bhalwal,Pindi Bhattian,Chunian,Pattoki,Depalpur,Mailsi,Dunyapur,Kabirwala,Jahanian,Alipur,Jatoi,Chowk Azam,Fateh Jang,Pind Dadan Khan,Talagang,Lalamusa,Phalia,Ferozewala,Raiwind,Shakargarh,Pasrur,Gojar Khan,Kallar Syedan,Ahmadpur Sial,Yazman,Jauharabad,Noor Pur Thal,Chichawatni,Sangla Hill,Chenab Nagar (Rabwah),Pir Mahal,Kundian,Bhera,Piplan,Darya Khan,Kallur Kot,Haveli Lakha,Renala Khurd,Hujra Shah Muqeem,Basirpur,Raja Jang,Shahkot,Lalian,Bhowana,Athara Hazari,Tandlianwala,Chak Jhumra,Sidhar,Hassan Abdal,Hazro,Jand,Pindi Gheb,Kahuta,Kotli Sattian,Choa Saidan Shah,Kallar Kahar,Sohawa,Safdarabad,Sharaqpur Sharif,Nowshera Virkan,Qila Didar Singh,Eminabad,Jalalpur Jattan,Sarai Alamgir,Malakwal,Khairpur Tamewali,Karor Lal Esan,Jampur,Rojhan,Kehror Pakka,Gaggo Mandi,Tulamba,Isa Khel,Shujabad,Jalalpur Pirwala,Mamu Kanjan",
    "Sindh":"Karachi,Hyderabad,Sukkur,Larkana,Nawabshah (Shaheed Benazirabad),Mirpur Khas,Jacobabad,Shikarpur,Khairpur,Dadu,Thatta,Badin,Sanghar,Umerkot,Tando Allahyar,Tando Muhammad Khan,Tando Adam,Kotri,Jamshoro,Ghotki,Kashmore,Matiari,Naushahro Feroze,Mithi,Moro,Rohri,Kandiaro,Sehwan,Shahdadkot,Kamber,Daharki,Mehar,Gambat,Hala,Digri,Kunri,Sakrand,Ratodero,Johi,Mirpur Mathelo,Pano Aqil,Ubauro,Khipro,Jati,Sujawal,Mirpur Bathoro,Diplo,Nagarparkar,Golarchi,Tando Jam,Lakhi Ghulam Shah,Garhi Yasin,Ranipur,Thul,Khairpur Nathan Shah,Warah,Setharja,Shahpur Chakar,Sinjhoro,Jam Nawaz Ali,Tando Bago,Talhar,Kot Ghulam Muhammad,Islamkot,Chhachhro,Dokri,Gharo,Jhimpir,Keti Bandar,Samaro,Pithoro,Ghorabari,Mirpur Sakro,Bhan Syedabad,Qambar,Madeji,Kot Diji,Faiz Ganj",
    "Khyber Pakhtunkhwa":"Peshawar,Mardan,Abbottabad,Swat (Mingora),Kohat,Mansehra,Dera Ismail Khan,Nowshera,Charsadda,Swabi,Bannu,Haripur,Lakki Marwat,Karak,Hangu,Chitral,Upper Dir,Lower Dir (Timergara),Buner,Shangla,Battagram,Tank,Malakand,Batkhela,Havelian,Takht Bhai,Kulachi,Topi,Besham,Oghi,Thall,Tangi,Shabqadar,Pabbi,Jehangira,Risalpur,Khanpur,Kabal,Matta,Khwazakhela,Daggar,Alpuri,Kalam,Dargai,Tordher,Ghazi,Nathia Gali,Balakot,Dassu (Kohistan),Pattan (Kohistan),Kolai,Palas,Judbah (Torghar),Mastuj,Drosh,Madyan,Bahrain,Saidu Sharif,Chakdara,Barikot,Katlang,Lahor,Razzar,Akora Khattak,Umerzai,Shinkiari,Garhi Habibullah,Naran,Sarai Saleh,Kot Najibullah,Nawansher,Lachi,Paharpur,Daraban,Parova,Paniala,Naurang,Banda Daud Shah,Takht-e-Nasrati,Doaba",
    "Balochistan":"Quetta,Gwadar,Turbat,Khuzdar,Chaman,Sibi,Zhob,Loralai,Hub,Dera Murad Jamali,Dera Allah Yar,Usta Muhammad,Kharan,Mastung,Nushki,Panjgur,Pishin,Kalat,Uthal (Lasbela),Bela,Jaffarabad,Awaran,Qila Saifullah,Qila Abdullah,Ziarat,Washuk,Dalbandin,Barkhan,Kohlu,Musakhel,Harnai,Sohbatpur,Dera Bugti,Sui,Pasni,Ormara,Jiwani,Surab,Nasirabad,Lehri,Gandava,Mach,Duki,Muslim Bagh,Dhadar,Bolan,Nokkundi,Taftan,Besima,Hoshab,Tump,Mand,Gadani,Winder,Kuchlak,Khanozai,Spezand,Mangochar",
    "Islamabad Capital Territory":"Islamabad",
    "Azad Kashmir":"Muzaffarabad,Mirpur,Kotli,Bhimber,Rawalakot,Bagh,Neelum (Athmuqam),Haveli (Kahuta),Sudhnoti (Pallandri),Hattian Bala,Dadyal,Samahni,Forward Kahuta,Chakswari,Khuiratta,Nakyal,Sehnsa,Kel,Sharda,Abbaspur,Hajira,Thorar,Trarkhal,Garhi Dupatta,Chinari",
    "Gilgit-Baltistan":"Gilgit,Skardu,Hunza (Karimabad),Chilas,Ghanche (Khaplu),Ghizer (Gahkuch),Astore,Nagar,Shigar,Diamer,Kharmang,Gupis,Aliabad,Sost,Gulmit,Passu,Jaglot,Bunji,Dainyor,Yasin,Ishkoman,Phander,Darel,Tangir,Rondu,Hushe",
    "Merged Districts (ex-FATA)":"Khyber (Landi Kotal),Bajaur (Khar),Mohmand (Ghalanai),Orakzai (Kalaya),Kurram (Parachinar),North Waziristan (Miranshah),South Waziristan (Wana),Jamrud,Bara,Sadda,Alizai,Mir Ali,Razmak,Spinwam,Datta Khel,Jandola,Ladha,Makin"
  };

  /* City -> Areas -> Points.   Format:  "Area=Point|Point|Point;Area2=Point|Point"
     Jis city ka data yahan nahi, wahan customer Area/Point khud likhta hai.
     Naya city add karne ke liye neeche ek line jodein - city ka naam upar wali list jaisa hi likhein. */
  var AREAS = {
    "Lahore":
      "Gulberg=Liberty Market|MM Alam Road|Main Boulevard Gulberg|Gulberg II Market|Gulberg III|Kalma Chowk|Hafeez Center;" +
      "DHA Lahore=Phase 1|Phase 2|Phase 3|Phase 4|Phase 5|Phase 6|Phase 7|Phase 8|Y Block Commercial;" +
      "Johar Town=Block A|Block B|Block C|Block D|Block E|Block F|Block G|Block H|Block J|Block K|Block L|Block M|Block N|Block P|Block Q|Block R|Expo Centre|Emporium Mall;" +
      "Model Town=Link Road|Model Town Market|C Block|F Block|G Block|K Block|Q Block;" +
      "Bahria Town Lahore=Sector A|Sector B|Sector C|Sector D|Sector E|Sector F|Bahria Orchard|Jinnah Block|Iqbal Block;" +
      "Wapda Town=Phase 1|Phase 2|Wapda Town Round About|Wapda Town Market;" +
      "Allama Iqbal Town=Karim Block|Gulshan Block|Hunza Block|Sikandar Block|Nishtar Block|Jahanzeb Block|Moon Market;" +
      "Faisal Town=Block A|Block B|Block C|Block D|Faisal Town Market;" +
      "Lahore Cantt=Sarwar Road|Cavalry Ground|Askari 5|Askari 10|Walton Road|Sadar Bazaar;" +
      "Garden Town=Garden Town Main Market|Sunset Boulevard|Barkat Market;" +
      "Samanabad=Samanabad Main Bazaar|Gulshan-e-Ravi|Moon Market Samanabad;" +
      "Township=Sector A1|Sector A2|Sector B1|Sector B2|Sector C1|Sector C2|Township More;" +
      "Shahdara=Shahdara Chowk|Shahdara Bazaar|Ravi Road;" +
      "Anarkali / Mall Road=Anarkali Bazaar|Mall Road|Lahore Railway Station|Data Darbar|Landa Bazaar;" +
      "Ferozepur Road=Qainchi|Kahna|Thokar Niaz Baig|Chungi Amar Sidhu|Ichhra;" +
      "Raiwind Road=Lake City|Bahria Orchard|Raiwind Bypass|Park View City|Central Park;Walled City=Delhi Gate|Bhati Gate|Lohari Gate|Mochi Gate|Taxali Gate|Akbari Gate|Shah Alami|Mori Gate|Roshnai Gate|Kashmiri Gate|Yakki Gate;Mughalpura=Mughalpura Main|Dharampura|Baghbanpura|Shalimar Garden;Sabzazar=Sabzazar Scheme|Multan Road|Chauburji|Nawan Kot;Valencia Town=Block A|Block B|Block C|Block D|Valencia Main;Shadman=Shadman Market|Shadman Chowk|Jail Road|Race Course Park|Zaman Park",
    "Karachi":
      "Gulshan-e-Iqbal=Block 1|Block 2|Block 3|Block 4|Block 5|Block 6|Block 7|Block 10-A|Block 13-D|NIPA Chowrangi|Aladin Park|Disco Bakery;" +
      "Gulistan-e-Johar=Block 1|Block 7|Block 12|Block 13|Block 14|Block 15|Block 16|Johar Mor|Johar Chowrangi;" +
      "DHA Karachi=Phase 1|Phase 2|Phase 4|Phase 5|Phase 6|Phase 7|Phase 8|Khayaban-e-Shamsheer|Khayaban-e-Bukhari|Zamzama;" +
      "Clifton=Block 2|Block 4|Block 5|Block 7|Block 8|Block 9|Teen Talwar|Do Talwar|Boat Basin|Dolmen Mall;" +
      "North Nazimabad=Block A|Block B|Block C|Block D|Block F|Block H|Block I|Block L|Five Star Chowrangi|Hyderi Market|Board Office;" +
      "Nazimabad=Nazimabad No. 1|Nazimabad No. 2|Nazimabad No. 3|Super Market|Abbasi Shaheed Hospital;" +
      "Saddar=Empress Market|Zainab Market|Bohri Bazaar|Tibet Center|Regal Chowk|Frere Hall;" +
      "PECHS / Tariq Road=Block 2|Block 6|Tariq Road|Bahadurabad|Shahrah-e-Faisal;" +
      "Malir=Malir Halt|Malir Cantt|Model Colony|Saudabad|Malir City|Quaidabad;" +
      "Korangi=Korangi Crossing|Korangi Industrial Area|Landhi|Shah Faisal Colony;" +
      "Orangi Town=Sector 5|Sector 8|Sector 11|Orangi Chowk;" +
      "Liaquatabad=Liaquatabad No. 10|Teen Hatti|Lalu Khet;" +
      "Federal B Area=Aisha Manzil|Karimabad|Water Pump|Block 16|Block 7;" +
      "Scheme 33=Sector 33|Super Highway|Gulzar-e-Hijri|Abul Hasan Isphahani Road;" +
      "Bahria Town Karachi=Precinct 1|Precinct 2|Precinct 10|Precinct 11|Precinct 19|Precinct 27|Precinct 31;SITE Area=SITE Industrial Area|Metroville|Banaras Chowk;North Karachi=Sector 5-C|Sector 11-A|Sector 11-B|Sector 11-C|Nagan Chowrangi|Power House Chowrangi;Lyari=Chakiwara|Baghdadi|Kalakot|Nawa Lane",
    "Islamabad":
      "F-6=Super Market|Jinnah Avenue|Margalla Road|Aabpara side;" +
      "F-7=Jinnah Super Market|F-7 Markaz|Kohsar Market|Melody side;" +
      "F-8=F-8 Markaz|Centaurus Mall side|Jinnah Avenue;" +
      "F-10=F-10 Markaz|Street 1-5|Street 6-10;" +
      "F-11=F-11 Markaz|Grand Mall|Street 1-5;" +
      "G-6=Melody Market|Aabpara Market|G-6 Markaz;" +
      "G-9=Karachi Company|G-9 Markaz|Street 1-5;" +
      "G-10=G-10 Markaz|Street 1-5|Street 6-10;" +
      "G-11=G-11 Markaz|Street 1-5|Street 6-10;" +
      "G-13=G-13 Markaz|Street 1-5|Street 6-10;" +
      "I-8=I-8 Markaz|Street 1-5|Street 6-10;" +
      "I-9=I-9 Markaz|I-9 Industrial Area|Street 1-5;" +
      "I-10=I-10 Markaz|Street 1-5|Street 6-10;" +
      "E-11=E-11 Markaz|Street 1-5|Street 6-10;" +
      "Blue Area=Jinnah Avenue|Kashmir Highway side|Fazl-e-Haq Road;" +
      "Bani Gala=Bani Gala Main Road|Chak Shahzad Road side;" +
      "DHA Islamabad=Phase 1|Phase 2|Phase 5|Phase 6;" +
      "Bahria Town=Phase 1|Phase 2|Phase 3|Phase 4|Phase 5|Phase 6|Phase 7|Phase 8;G-8=G-8 Markaz|PIMS Hospital|Street 1-5;E-7=E-7 Markaz|Street 1-5;H-8=H-8 Markaz|Street 1-5;H-9=H-9 Markaz|Street 1-5;D-12=D-12 Markaz|Street 1-5;PWD Housing Society=Block A|Block B|Block C|Main Boulevard;Park Road=Park Road Main|Chak Shahzad|Rawal Lake View",
    "Rawalpindi":
      "Saddar=Mall Road|Adamjee Road|Bank Road|Murree Road|Saddar Bazaar;" +
      "Raja Bazaar=Raja Bazaar|Moti Bazaar|Bohar Bazaar;" +
      "Satellite Town=Block A|Block B|Block C|Block D|Commercial Market|6th Road;" +
      "Chaklala=Chaklala Scheme 1|Chaklala Scheme 2|Chaklala Scheme 3|Chaklala Railway Station;" +
      "Bahria Town=Phase 1|Phase 2|Phase 3|Phase 4|Phase 5|Phase 6|Phase 7|Phase 8|Civic Centre;" +
      "DHA Rawalpindi=Phase 1|Phase 2;" +
      "Westridge=Westridge 1|Westridge 2|Westridge 3;" +
      "Peshawar Road=Faizabad side|Ammar Chowk|Dhoke Kala Khan;" +
      "Adiala Road=Adiala Road Main|Gulzar-e-Quaid|Khayaban-e-Sir Syed;" +
      "Committee Chowk=Committee Chowk|Liaquat Bagh|Murree Road side",
    "Faisalabad":
      "People's Colony No. 1=D Ground|Main Market|Block A|Block B;" +
      "People's Colony No. 2=Main Market|Block A|Block B|Block C;" +
      "Madina Town=Madina Town Main|Block A|Block B|Block C;" +
      "Susan Road=Susan Road Main|Mall of Faisalabad side|Gulistan Colony;" +
      "Jinnah Colony=Jinnah Colony Main|Kohinoor City side;" +
      "Millat Town=Millat Chowk|Block A|Block B;" +
      "Ghulam Muhammad Abad=Block A|Block B|Main Chowk;" +
      "Satiana Road=Satiana Road Main|Eden Valley|Millat Road side;" +
      "Jaranwala Road=Jaranwala Road Main|Canal Road side|Samundri Road side;" +
      "Clock Tower=Clock Tower|Katchery Bazaar|Rail Bazaar|Aminpur Bazaar",
    "Multan":
      "Cantt=Cantt Main|Abdali Road|Bosan Road side|Nusrat Road;" +
      "Gulgasht Colony=Gulgasht Main Market|Gulgasht Chowk;" +
      "Shah Rukn-e-Alam Colony=Main Market|Shah Rukn-e-Alam Chowk;" +
      "Bosan Road=Bosan Road Main|Bosan Chowk|Gulgasht side;" +
      "Nawan Shehr=Nawan Shehr Main|Chowk Nawan Shehr;" +
      "Hussain Agahi=Hussain Agahi Bazaar|Chowk Hussain Agahi;" +
      "Chowk Kumharanwala=Chowk Kumharanwala|Kumharanwala Main Road;" +
      "Vehari Road=Vehari Road Main|Chungi No. 9|Chungi No. 14;" +
      "DHA Multan=Phase 1|Phase 2|Phase 3",
    "Peshawar":
      "Hayatabad=Phase 1|Phase 2|Phase 3|Phase 4|Phase 5|Phase 6|Phase 7;" +
      "University Town=University Road|Board Bazaar|Jamrud Road side;" +
      "Saddar=Saddar Bazaar|Khyber Bazaar|Sher Shah Suri Road;" +
      "Gulbahar=Gulbahar Chowk|Gulbahar Main Bazaar;" +
      "Cantonment=Cantt Main|Fort Road|Mall Road;" +
      "Qissa Khwani=Qissa Khwani Bazaar|Namak Mandi|Chowk Yadgar;" +
      "Ring Road=Ring Road Main|Charsadda Road side|Warsak Road side;" +
      "Dalazak Road=Dalazak Road Main|Dalazak Chowk;" +
      "Kohat Road=Kohat Road Main|Bara Road side",
    "Quetta":
      "Jinnah Road=Liaquat Bazaar|Mission Road|Kandahari Bazaar|Fatima Jinnah Road;" +
      "Sariab Road=Sariab Chowk|Sariab Stand|Sariab Bazaar;" +
      "Satellite Town=Satellite Town Main|Satellite Town Chowk;" +
      "Brewery Road=Brewery Road Main|Brewery Chowk;" +
      "Airport Road=Airport Road Main|Samungli Road side;" +
      "Zarghoon Road=Zarghoon Road Main|Shahrah-e-Zarghoon;" +
      "Hazar Ganji=Hazar Ganji Main|Sabzi Mandi",
    "Hyderabad":
      "Latifabad=Unit 1|Unit 2|Unit 3|Unit 4|Unit 5|Unit 6|Unit 7|Unit 8|Unit 9|Unit 10|Unit 11|Unit 12;" +
      "Qasimabad=Qasimabad Main Road|Qasimabad Chowk;" +
      "Hirabad=Hirabad Main Road|Hirabad Chowk;" +
      "Saddar=Saddar Bazaar|Tower Market|Resham Gali|Station Road"
  };

  /* ================= Data tayyar karein ================= */
  var TOP = ["Karachi","Lahore","Islamabad","Rawalpindi","Faisalabad","Multan","Peshawar","Quetta","Hyderabad","Gujranwala","Sialkot"];
  var PROV = {};
  Object.keys(RAW).forEach(function(p){
    var list = RAW[p].split(',').filter(function(v,i,a){return v && a.indexOf(v)===i;}).sort(function(a,b){return a.localeCompare(b);});
    var top = TOP.filter(function(c){return list.indexOf(c)>-1;});
    PROV[p] = top.concat(list.filter(function(c){return top.indexOf(c)===-1;}));
  });
  function areasOf(city){
    var s = AREAS[city]; if(!s) return null;
    var o = {}, order = [];
    s.split(';').forEach(function(chunk){
      var i = chunk.indexOf('='); if(i<0) return;
      var name = chunk.slice(0,i).trim(); order.push(name);
      o[name] = chunk.slice(i+1).split('|').map(function(x){return x.trim();}).filter(Boolean);
    });
    return {names:order.sort(function(a,b){return a.localeCompare(b);}), pts:o};
  }

  /* ================= Elements ================= */
  var $ = function(id){return document.getElementById(id);};
  var overlay=$('amOrdOverlay'), nameI=$('amName'), phoneI=$('amPhone'),
      prov=$('amProv'), city=$('amCity'), area=$('amArea'), point=$('amPoint'),
      areaO=$('amAreaOther'), pointO=$('amPointOther'), addr=$('amAddr'),
      submit=$('amOrdSubmit'), 
      formWrap=$('amOrdFormWrap'), done=$('amOrdDone');
  var OTHER = '__other__', productText = '', cur = null;

  /* ================= Bill / Discount / Payment ================= */
  var disc = null, pay = '', shot = '', lastTotal = 0;
  var items = [], MAX_QTY = 20;   /* items: [{name,price,img,variant,qty}] - MAX_QTY: ek product ki zyada se zyada quantity */
  function he(t){ return String(t).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function itemsQty(){ return items.reduce(function(a,i){ return a + i.qty; }, 0); }
  function itemsSub(){ return items.reduce(function(a,i){ return a + i.price*i.qty; }, 0); }
  var rs = function(n){ return 'Rs. ' + Math.round(n).toLocaleString('en-US'); };
  function calc(){
    var gross = itemsSub(),
        off = disc ? (disc.t==='percent' ? Math.round(gross*disc.v/100) : Math.min(disc.v, gross)) : 0,
        sub = gross - off,
        del = !items.length ? 0 : (window.AMX ? AMX.del(city.value, sub) : ((FREE_DELIVERY_ABOVE && sub >= FREE_DELIVERY_ABOVE) ? 0 : DELIVERY)),
        cod = pay==='cod' ? COD_FEE : 0;
    return {gross:gross, off:off, sub:sub, del:del, cod:cod, total:sub+del+cod};
  }
  function renderAcc(c){
    $('amOnline').style.display = (pay==='wallet'||pay==='bank') ? 'block' : 'none';
    if(pay!=='wallet' && pay!=='bank') return;
    $('amAcc').innerHTML = '<b>' + (pay==='wallet' ? 'Send payment to JazzCash / Easypaisa' : 'Send payment to this bank account') + '</b>' +
      (window.AMX ? AMX.cfg().acc : ACCOUNTS)[pay].map(function(a){ return '<p><b>' + a.n + '</b> - ' + a.title + '<br>' + a.no + (a.iban ? '<br>IBAN: ' + a.iban : '') + '</p>'; }).join('') +
      '<p>Amount to send (Products + Delivery): <b>' + rs(c.total) + '</b></p>';
  }
  function renderBill(showOld){
    var c = calc(), from = lastTotal || c.total;
    var h = items.map(function(it){
      return '<div class="li"><span>' + he(it.name) + (it.variant ? ' (' + he(it.variant) + ')' : '') + ' &times; ' + it.qty + '</span><b>' + rs(it.price*it.qty) + '</b></div>';
    }).join('');
    if(items.length > 1) h += '<div><span>Products Total (' + itemsQty() + ' items)</span><b>' + rs(c.gross) + '</b></div>';
    if(c.off) h += '<div class="disc"><span>Discount (' + disc.code + ')</span><b>- ' + rs(c.off) + '</b></div>';
    h += '<div><span>Delivery Charges</span><b>' + (c.del ? rs(c.del) : 'FREE') + '</b></div>';
    if(pay==='cod' && c.cod) h += '<div><span>COD Charges</span><b>' + rs(c.cod) + '</b></div>';
    h += '<div class="tot"><span>Total Bill</span><span>' + (showOld && from!==c.total ? '<s>' + rs(from) + '</s> ' : '') + '<b id="amTot">' + rs(from) + '</b></span></div>';
    $('amBill').innerHTML = h;
    $('amPrice').innerHTML = c.off ? '<s>' + rs(c.gross) + '</s> ' + rs(c.sub) : rs(c.gross);
    var el = $('amTot'), t0 = performance.now();
    (function step(t){ var k = Math.min(1,(t-t0)/600); el.textContent = rs(from + (c.total-from)*(1-Math.pow(1-k,3))); if(k<1) requestAnimationFrame(step); })(t0);
    lastTotal = c.total; renderAcc(c); updFab();
  }
  function orderInfo(){ var c = calc(); return {items:items.map(function(i){ return {pid:i.pid, name:i.name, variant:i.variant, qty:i.qty, price:i.price, lineTotal:i.price*i.qty}; }), totalQty:itemsQty(), productsTotal:c.gross, code:disc?disc.code:'', discount:c.off, delivery:c.del, codFee:c.cod, total:c.total, payment:pay}; }

  /* Discount code */
  var codeI = $('amCode'), codeMsg = $('amCodeMsg'), applyB = $('amApply');
  function codeSay(t, cls){ codeMsg.textContent = t; codeMsg.className = cls||''; codeMsg.style.animation='none'; void codeMsg.offsetWidth; codeMsg.style.animation=''; }
  applyB.addEventListener('click', function(){
    if(disc){ disc=null; codeI.value=''; codeI.disabled=false; applyB.textContent='Apply'; codeSay(''); renderBill(true); return; }
    var k = codeI.value.trim().toUpperCase(), d = DISCOUNTS[k];
    if(!d && k && window.AMX){ applyB.disabled = true; AMX.coupon(k, itemsSub()).then(function(r){ applyB.disabled = false; if(r){ DISCOUNTS[k] = r; applyB.click(); } else codeSay('This discount code is not valid.', 'bad'); }).catch(function(){ applyB.disabled = false; codeSay('Could not check this code. Please try again.', 'bad'); }); return; }
 if(!d){ codeSay(k ? 'This discount code is not valid.' : 'Enter a discount code first.', 'bad'); return; }
    disc = {t:d.t, v:d.v, code:k}; codeI.disabled = true; applyB.textContent = 'Remove';
    codeSay('Code applied! You saved ' + rs(calc().off) + '.', 'ok'); renderBill(true);
  });
  codeI.addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); applyB.click(); } });

  /* Payment method */
  Array.prototype.forEach.call(document.querySelectorAll('input[name=amPay]'), function(r){
    r.addEventListener('change', function(){
      pay = r.value;
      Array.prototype.forEach.call(document.querySelectorAll('.am-pc'), function(l){ l.classList.toggle('on', l.querySelector('input').checked); });
      $('fPay').classList.remove('am-err'); renderBill();
    });
  });

  /* Screenshot (compress karke memory mein rakhta hai) */
  $('amShot').addEventListener('change', function(){
    var f = this.files[0]; if(!f) return;
    if(!/^image\//.test(f.type)){ alert('Please select an image (screenshot) only.'); this.value=''; return; }
    var rd = new FileReader();
    rd.onload = function(){
      var im = new Image();
      im.onload = function(){
        var s = Math.min(1, 1000/Math.max(im.width, im.height)), cv = document.createElement('canvas');
        cv.width = im.width*s; cv.height = im.height*s; cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);
        shot = cv.toDataURL('image/jpeg', .7);
        $('amShotImg').src = shot; $('amShotImg').style.display = 'block';
        $('amDropTxt').textContent = '\u2714 Screenshot attached (click again to change it)';
        $('fShot').classList.remove('am-err');
      };
      im.src = rd.result;
    };
    rd.readAsDataURL(f);
  });

  /* Thank-you full screen */
  function showThanks(d, url){
    var c = calc(), cf = $('amCf'), cols = ['#fde047','#fff','#86efac','#fb923c','#38bdf8','#f472b6'];
    cf.innerHTML = '';
    for(var i=0;i<60;i++){
      var s = document.createElement('i'); s.className = 'am-cf';
      s.style.cssText = 'left:'+(Math.random()*100)+'%;background:'+cols[i%6]+';animation-duration:'+(2.5+Math.random()*2.5)+'s;animation-delay:'+(Math.random()*1.2)+'s';
      cf.appendChild(s);
    }
    $('amTkName').textContent = 'Thank you, ' + d.name.split(' ')[0] + '!';
    $('amTkSub').innerHTML = 'We have received your order. Total Bill: <b>' + rs(c.total) + '</b>' + (pay==='cod' ? ' (Cash on Delivery)' : '');
    var tkItems = $('amTkItems');
    tkItems.innerHTML = items.map(function(it, idx){
      var pic = it.img ? '<img src="' + he(it.img) + '" alt="' + he(it.name) + '">' : '<span class="am-tk-noimg" aria-hidden="true">📦</span>';
      return '<div class="am-tk-item" style="animation-delay:' + (0.08*idx) + 's">' + pic + '<span><b>' + he(it.name) + '</b><small>' + (it.variant ? he(it.variant) + ' · ' : '') + 'Qty: ' + it.qty + ' · ' + rs(it.price*it.qty) + '</small></span></div>';
    }).join('');
    tkItems.style.display = items.length ? 'flex' : 'none';
    $('amTkPay').style.display = pay==='cod' ? 'none' : 'block';
    $('amThanks').classList.add('on'); document.body.style.overflow = 'hidden';
  }
  $('amTkClose').addEventListener('click', function(){ $('amThanks').classList.remove('on'); document.body.style.overflow=''; });

  /* Ripple: tamam .am-btn buttons par */
  document.addEventListener('click', function(e){
    var b = e.target.closest('.am-btn'); if(!b) return;
    var r = b.getBoundingClientRect(), s = Math.max(r.width, r.height), d = document.createElement('span');
    d.className = 'am-rip';
    d.style.cssText = 'width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left-s/2)+'px;top:'+(e.clientY-r.top-s/2)+'px';
    b.appendChild(d); setTimeout(function(){ d.remove(); }, 650);
  });

  function opt(sel, value, label){ var o=document.createElement('option'); o.value=value; o.textContent=label; sel.appendChild(o); }
  function reset(sel, ph, disabled){ sel.innerHTML=''; opt(sel,'',ph); sel.disabled = !!disabled; }

  Object.keys(PROV).forEach(function(p){ opt(prov,p,p); });

  function onProv(){
    reset(city,'Select City',!prov.value);
    if(prov.value) PROV[prov.value].forEach(function(c){ opt(city,c,c); });
    onCity();
  }
  function onCity(){
    cur = null; areaO.style.display='none'; areaO.value=''; pointO.style.display='none'; pointO.value='';
    reset(area,'Select Area',!city.value); reset(point,'Select Point',true); mapSay('');
    if(!city.value) return;
    cur = areasOf(city.value) || {names:[],pts:{}};
    reset(area,'Select Area',false);
    cur.names.forEach(function(a){ opt(area,a,a); });
    opt(area,OTHER,'Other (type your area)');
    if(!cur.names.length){ area.value = OTHER; onArea(); }
    loadAreas(city.value);
  }
  function onArea(){
    pointO.style.display='none'; pointO.value='';
    areaO.style.display = (area.value===OTHER) ? 'block' : 'none';
    if(area.value!==OTHER) areaO.value='';
    reset(point,'Select Point',!area.value);
    if(!area.value) return;
    if(area.value===OTHER){ opt(point,OTHER,'Type your point'); point.value=OTHER; point.disabled=true; pointO.style.display='block'; return; }
    (cur.pts[area.value]||[]).forEach(function(p){ opt(point,p,p); });
    opt(point,OTHER,'Other (type your point)');
    loadPoints(area.value);
  }
  function onPoint(){
    pointO.style.display = (point.value===OTHER) ? 'block' : 'none';
    if(point.value!==OTHER) pointO.value='';
  }

  /* ---- OpenStreetMap (map) se mazeed Areas / Points ---- */
  function esc(s){ return String(s).replace(/["\\]/g,''); }
  function mapSay(t){ $('amMapMsg').textContent = t; }
  function osm(q, key){
    try{ var c = sessionStorage.getItem('am_'+key); if(c) return Promise.resolve(JSON.parse(c)); }catch(x){}
    var ctl = window.AbortController ? new AbortController() : null, tm = setTimeout(function(){ if(ctl) ctl.abort(); }, 22000);
    return fetch('https://overpass-api.de/api/interpreter', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'data=' + encodeURIComponent('[out:json][timeout:25];area["ISO3166-1"="PK"]->.pk;' + q), signal: ctl ? ctl.signal : undefined})
      .then(function(r){ clearTimeout(tm); if(!r.ok) throw 0; return r.json(); })
      .then(function(j){ try{ sessionStorage.setItem('am_'+key, JSON.stringify(j)); }catch(x){} return j; });
  }
  function cityHead(c){ return 'rel["boundary"="administrative"]["name"="' + esc(c.replace(/\s*\(.*$/,'').trim()) + '"](area.pk);map_to_area->.a;'; }
  function addOpts(sel, list, seen){
    var other = sel.querySelector('option[value="' + OTHER + '"]'), n = 0;
    list.forEach(function(v){
      v = (v||'').trim(); if(!v || seen[v.toLowerCase()]) return; seen[v.toLowerCase()] = 1; n++;
      var o = document.createElement('option'); o.value = v; o.textContent = v; sel.insertBefore(o, other);
    });
    return n;
  }
  function loadAreas(c){
    mapSay('\uD83D\uDDFA\uFE0F Loading more areas from the map...');
    osm(cityHead(c) + '(node(area.a)["place"~"^(suburb|neighbourhood|quarter|village)$"]["name"];way(area.a)["place"~"^(suburb|neighbourhood|quarter)$"]["name"];);out tags 2500;', 'a_' + c)
    .then(function(j){
      if(city.value !== c) return;
      var seen = {}, names = [];
      cur.names.forEach(function(n){ seen[n.toLowerCase()] = 1; });
      j.elements.forEach(function(e){ names.push(e.tags && e.tags.name); });
      names = names.filter(Boolean).sort(function(a,b){ return a.localeCompare(b); });
      var onlyText = !cur.names.length, n = addOpts(area, names, seen);
      if(n){
        cur.names = cur.names.concat(names.filter(function(v){ return !cur.pts[v]; }));
        if(onlyText && area.value===OTHER && !areaO.value){ area.value=''; onArea(); }
        mapSay('\u2714 Found ' + n + ' more areas on the map.');
      } else mapSay(onlyText ? 'No areas found on the map for this city. Please type your area.' : '');
    }).catch(function(){ if(city.value===c) mapSay(''); });
  }
  function loadPoints(a){
    var c = city.value, nm = esc(a);
    mapSay('\uD83D\uDDFA\uFE0F Loading points from the map...');
    osm(cityHead(c) + '(node(area.a)["place"]["name"="' + nm + '"];way(area.a)["place"]["name"="' + nm + '"];rel(area.a)["place"]["name"="' + nm + '"];);out center 1;', 'c_' + c + '_' + a)
    .then(function(j){
      var e = j.elements[0]; if(!e) throw 0;
      var la = e.lat || e.center.lat, lo = e.lon || e.center.lon, R = '(around:1500,' + la + ',' + lo + ')';
      return osm('(node' + R + '["place"~"^(neighbourhood|quarter|suburb|hamlet|locality)$"]["name"];node' + R + '["amenity"~"^(marketplace|hospital|university|college|bank)$"]["name"];nwr' + R + '["shop"~"^(mall|supermarket)$"]["name"];nwr' + R + '["leisure"="park"]["name"];node' + R + '["tourism"~"^(hotel|attraction)$"]["name"];);out tags center 120;', 'p_' + la + '_' + lo);
    }).then(function(j){
      if(area.value !== a) return;
      var seen = {}; seen[a.toLowerCase()] = 1;
      (cur.pts[a]||[]).forEach(function(p){ seen[p.toLowerCase()] = 1; });
      var names = j.elements.map(function(e){ return e.tags && e.tags.name; }).filter(Boolean).sort(function(x,y){ return x.localeCompare(y); });
      var n = addOpts(point, names, seen);
      mapSay(n ? '\u2714 Found ' + n + ' points / landmarks on the map.' : '');
    }).catch(function(){ if(area.value===a) mapSay(''); });
  }

  /* ---- Product picture ---- */
  function cardVariant(el){
    var cd = el.closest('[class*="product"],[class*="card"],article'); if(!cd) return '';
    var s = cd.querySelector('select');
    if(s && s.selectedIndex >= 0 && s.value) return s.options[s.selectedIndex].text.trim();
    var a = cd.querySelector('[class*="variant"].active,[class*="variant"].selected,[class*="size"].active,[class*="size"].selected,[aria-pressed="true"],input[type=radio]:checked');
    return a ? (a.value || a.textContent || '').trim() : '';
  }
  function cardImg(el){ var cd = el.closest('[class*="product"],[class*="card"],article'), im = cd && cd.querySelector('img'); return im ? (im.currentSrc || im.src) : ''; }
  function rowTot(it){ return rs(it.price*it.qty) + (it.qty>1 ? '' : ''); }
  function renderCart(newIdx){
    var box = $('amCart'); box.innerHTML = '';
    items.forEach(function(it, i){
      var w = document.createElement('div'); w.className = 'am-ci' + (i===newIdx ? ' new' : ''); w.setAttribute('data-i', i);
      w.innerHTML = (it.img ? '<img alt="">' : '<div class="am-noimg">&#128717;</div>') +
        '<div class="am-ci-info"><b></b><small></small>' +
        '<div class="am-ci-bot"><div class="am-qty" role="group" aria-label="Quantity">' +
        '<button type="button" class="am-btn am-qb" data-act="m" aria-label="Decrease quantity">&minus;</button>' +
        '<span class="am-qn"></span>' +
        '<button type="button" class="am-btn am-qb" data-act="p" aria-label="Increase quantity">+</button></div>' +
        '<div class="am-ci-tot"></div></div></div>' +
        '<button type="button" class="am-ci-rm" data-act="x" aria-label="Remove product">&times;</button>';
      w.querySelector('b').textContent = it.name || 'Product';
      var sm = w.querySelector('small');
      if(it.variant){ sm.className = 'v'; sm.textContent = 'Variant / Size: ' + it.variant; } else sm.textContent = 'Your selected product';
      var im = w.querySelector('img');
      if(im){ im.src = it.img; im.onerror = function(){ im.outerHTML = '<div class="am-noimg">&#128717;</div>'; }; }
      box.appendChild(w); rowUpd(w, i);
    });
  }
  function rowUpd(w, i, pop){
    var it = items[i], q = w.querySelector('.am-qn');
    q.textContent = it.qty;
    w.querySelector('[data-act=m]').disabled = it.qty <= 1;
    w.querySelector('[data-act=p]').disabled = it.qty >= MAX_QTY;
    w.querySelector('.am-ci-tot').textContent = it.qty + ' × ' + rs(it.price) + ' = ' + rs(it.price*it.qty);
    if(pop){ q.classList.remove('pop'); void q.offsetWidth; q.classList.add('pop'); }
  }
  $('amCart').addEventListener('click', function(e){
    var b = e.target.closest('[data-act]'); if(!b) return;
    var w = b.closest('.am-ci'), i = +w.getAttribute('data-i'), it = items[i]; if(!it) return;
    var a = b.getAttribute('data-act');
    if(a==='x'){
      items.splice(i,1);
      if(!items.length){ lastTotal = 0; close(); return; }
      renderCart(); renderBill(true); return;
    }
    it.qty = Math.max(1, Math.min(MAX_QTY, it.qty + (a==='p' ? 1 : -1)));
    rowUpd(w, i, true); renderBill(true);
  });
  $('amAddMore').addEventListener('click', function(){ close(); });
  var fab = $('amFab');
  function updFab(){
    var show = items.length && !overlay.classList.contains('am-open');
    fab.classList.toggle('on', !!show);
    if(show) fab.innerHTML = '&#128722; Order (' + itemsQty() + ' items) &middot; ' + rs(calc().total);
  }
  fab.addEventListener('click', function(){ showForm(); });

  prov.addEventListener('change', onProv);
  city.addEventListener('change', function(){ onCity(); renderBill(true); });
  area.addEventListener('change', onArea);
  point.addEventListener('change', onPoint);

  /* ================= Phone ================= */
  function normPhone(v){
    var d = (v||'').replace(/\D/g,'');
    if(d.indexOf('0092')===0) d = d.slice(4);
    else if(d.indexOf('92')===0 && d.length>10) d = d.slice(2);
    if(d.charAt(0)==='0') d = d.slice(1);
    return /^3\d{9}$/.test(d) ? d : null;
  }
  phoneI.addEventListener('input', function(){ phoneI.value = phoneI.value.replace(/[^\d\s\-]/g,''); });

  /* ================= Validation ================= */
  function flag(id, bad){ $(id).classList.toggle('am-err', !!bad); return !!bad; }
  function clearErr(){ ['fName','fPhone','fProv','fCity','fArea','fPoint','fAddr','fPay','fShot'].forEach(function(i){ $(i).classList.remove('am-err'); }); }
  [nameI,phoneI,prov,city,area,point,areaO,pointO,addr].forEach(function(el){
    el.addEventListener('input', clearErrSoft); el.addEventListener('change', clearErrSoft);
  });
  function clearErrSoft(e){ var f = e.target.closest('.am-f'); if(f) f.classList.remove('am-err'); }

  function collect(){
    var areaVal = area.value===OTHER ? areaO.value.trim() : area.value;
    var pointVal = point.value===OTHER ? pointO.value.trim() : point.value;
    return { name:nameI.value.trim(), phone:normPhone(phoneI.value), province:prov.value, city:city.value, area:areaVal, point:pointVal, address:addr.value.trim() };
  }
  function validate(d){
    var bad = false, first = null;
    function chk(id, cond){ if(flag(id, cond)){ bad = true; if(!first) first = id; } }
    chk('fName',  d.name.length < 3);
    chk('fPhone', !d.phone);
    chk('fProv',  !d.province);
    chk('fCity',  !d.city);
    chk('fArea',  !d.area);
    chk('fPoint', !d.point);
    chk('fAddr',  d.address.length < 10);
    chk('fPay',   !pay);
    chk('fShot',  (pay==='wallet'||pay==='bank') && !shot);
    if(first) $(first).scrollIntoView({behavior:'smooth', block:'center'});
    return !bad;
  }

  /* ================= Submit ================= */
  function buildMsg(d){
    var L = [];
    L.push('*New Order - ' + STORE_NAME + '*'); if(window.AMX && AMX.curNo) L.push('*Order No:* ' + AMX.curNo);
    L.push('*Products (' + itemsQty() + ' items):*');
    items.forEach(function(it, i){
      L.push((i+1) + '. ' + it.name + (it.variant ? ' | Variant / Size: ' + it.variant : '') + ' | Qty: ' + it.qty + ' x ' + rs(it.price) + ' = ' + rs(it.price*it.qty));
    });
    L.push('');
    L.push('*Name:* ' + d.name);
    L.push('*WhatsApp:* +92' + d.phone);
    L.push('*Province:* ' + d.province);
    L.push('*City:* ' + d.city);
    L.push('*Area:* ' + d.area);
    L.push('*Point:* ' + d.point);
    L.push('*Address:* ' + d.address);
    var c = calc(); L.push('');
    L.push('*Products Total:* ' + rs(c.gross));
    if(c.off) L.push('*Discount Code:* ' + disc.code + ' (-' + rs(c.off) + ')');
    L.push('*Delivery:* ' + (c.del ? rs(c.del) : 'FREE'));
    if(pay==='cod') L.push('*COD Charges:* ' + rs(c.cod));
    L.push('*Total Bill:* ' + rs(c.total));
    L.push('*Payment:* ' + ({cod:'Cash on Delivery', wallet:'JazzCash / Easypaisa', bank:'Bank Account'})[pay] + (pay==='cod' ? '' : ' (screenshot sent - verification pending)'));
    return L.join('\n');
  }
  submit.addEventListener('click', function(e){
    /* ripple */
    var r = submit.getBoundingClientRect(), s = Math.max(r.width,r.height), dot = document.createElement('span');
    dot.className='am-rip'; dot.style.width=dot.style.height=s+'px';
    dot.style.left=(e.clientX-r.left-s/2)+'px'; dot.style.top=(e.clientY-r.top-s/2)+'px';
    submit.appendChild(dot); setTimeout(function(){dot.remove();},650);

    var d = collect(); if(!validate(d)) return; if(window.AMX && AMX.needGate()){ AMX.gate(function(){ submit.click(); }); return; }

    if(/X/i.test(SELLER_WHATSAPP)){
      alert('The store WhatsApp number is not set yet.');
      return;
    }
    try{ localStorage.setItem('amCustomer', JSON.stringify({name:d.name, phone:d.phone, province:d.province, city:d.city, area:d.area, point:d.point, address:d.address})); }catch(x){}

    if(WEBHOOK_URL){
      try{ fetch(WEBHOOK_URL,{method:'POST',mode:'no-cors',headers:{'Content-Type':'text/plain'},body:JSON.stringify({store:STORE_NAME,product:items.map(function(i){return i.name;}).join(", "),time:new Date().toISOString(),customer:d,order:orderInfo(),screenshot:shot})}); }catch(x){}
    }
    if(window.AMX){ AMX.curNo = 'AM-' + Date.now().toString(36).toUpperCase(); AMX.passed = false; try{ AMX.save(d, orderInfo(), shot); }catch(x){} }
 var url = 'https://wa.me/' + SELLER_WHATSAPP + '?text=' + encodeURIComponent(buildMsg(d));
    close(); showThanks(d, url);
    items = []; disc = null; lastTotal = 0; codeI.value=''; codeI.disabled=false; applyB.textContent='Apply'; codeSay(''); updFab();
    window.open(url,'_blank');
    document.dispatchEvent(new CustomEvent('am-order-submit',{detail:d}));
  });

  /* ================= Open / Close ================= */
  function restore(){
    var s; try{ s = JSON.parse(localStorage.getItem('amCustomer')||'null'); }catch(x){ s=null; }
    if(!s) return;
    nameI.value = s.name||''; phoneI.value = s.phone||''; addr.value = s.address||'';
    if(s.province){ prov.value=s.province; onProv();
      if(s.city){ city.value=s.city; onCity();
        if(cur && s.area && cur.pts[s.area]){ area.value=s.area; onArea();
          if(s.point && cur.pts[s.area].indexOf(s.point)>-1) point.value=s.point;
          else if(s.point){ point.value=OTHER; onPoint(); pointO.value=s.point; }
        } else if(s.area){
          if(cur){ area.value=OTHER; onArea(); }
          areaO.value=s.area; pointO.value=s.point||'';
        }
      }
    }
  }
  function showForm(){
    Array.prototype.forEach.call(document.querySelectorAll('#amOrdBox .am-f'), function(f,i){ f.style.animationDelay = (i*55) + 'ms'; });
    lastTotal = 0; renderCart(items.length-1); renderBill();
    formWrap.style.display='block'; done.style.display='none';
    clearErr();
    if(!nameI.value && !addr.value) restore();
    overlay.classList.add('am-open'); document.body.style.overflow='hidden'; updFab();
  }
  /* Product cart mein add karta hai (same product + same variant dobara ho to alag line nahi banti) */
  function open(text, p, img, v){
    var name = text || 'Product', vr = v || '', pr = (+p > 0) ? +p : DEFAULT_PRICE;
    var f = items.filter(function(i){ return i.name===name && i.variant===vr; })[0];
    if(!f) items.push({name:name, price:pr, img:img||'', variant:vr, qty:1});
    showForm();
  }
  function close(){ overlay.classList.remove('am-open'); document.body.style.overflow=''; updFab(); }

  $('amOrdClose').addEventListener('click', close);
  $('amOrdDoneBtn').addEventListener('click', close);
  overlay.addEventListener('click', function(e){ if(e.target===overlay) close(); });
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') close(); });

  /* Koi bhi button jis par class "am-order-trigger" ho (optional data-product="Product ka naam") */
  document.addEventListener('click', function(e){
    var t = e.target.closest('.am-order-trigger');
    if(t){ e.preventDefault(); open(t.getAttribute('data-product') || '', t.getAttribute('data-price'), t.getAttribute('data-img') || cardImg(t), t.getAttribute('data-variant') || t.getAttribute('data-size') || cardVariant(t)); }
  });

  /* Optional: Buy Now buttons ko seedha hook karein */
  if(HOOK_BUY_NOW){
    document.addEventListener('click', function(e){
      var b = e.target.closest(BUY_SEL); if(!b) return;
      e.preventDefault(); e.stopImmediatePropagation();
      var name = b.getAttribute('data-product');
      if(!name){
        var card = b.closest('[class*="product"],[class*="card"],article');
        var t = card && card.querySelector('h1,h2,h3,h4,[class*="title"],[class*="name"]');
        name = t ? t.textContent.trim() : '';
      }
      var pr = b.getAttribute('data-price');
      if(!pr){ var cd = b.closest('[class*="product"],[class*="card"],article'), pe = cd && cd.querySelector('[class*="price"]'); pr = pe ? ((pe.textContent.match(/[\d,]+/)||[''])[0]).replace(/,/g,'') : ''; }
      open(name, pr, b.getAttribute('data-img') || cardImg(b), b.getAttribute('data-variant') || b.getAttribute('data-size') || cardVariant(b));
    }, true);
  }

  window.AnasMartCheckout = { open: open, close: close, add: function(o){ var f = items.filter(function(i){ return i.pid===o.pid && i.variant===o.variant; })[0]; if(f) f.qty = Math.min(MAX_QTY, f.qty + o.qty); else items.push({name:o.name, price:o.price, img:o.img, variant:o.variant, qty:Math.min(MAX_QTY,o.qty), pid:o.pid}); showForm(); } };
})();


/* ===== Extracted inline script 4 ===== */

/* AM_MARKETPLACE_EXPANSION_V1: extra marketplace workflows in the existing Online Shah Alami theme. */
(function(){
  'use strict';
  if (window.AMMarket) return;
  var STORAGE_COMPARE='am_market_compare_v1', STORAGE_VIEWED='am_market_viewed_v1';
  var compareIds=[], viewedIds=[], loadedMyRequests=[];
  function read(key, fallback){try{var v=JSON.parse(localStorage.getItem(key));return Array.isArray(v)?v:fallback;}catch(e){return fallback;}}
  function write(key, value){try{localStorage.setItem(key,JSON.stringify(value));}catch(e){}}
  function safe(v){return typeof esc==='function'?esc(String(v==null?'':v)):String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function money(v){return typeof fmt==='function'?fmt(Number(v)||0):('Rs. '+(Number(v)||0).toLocaleString());}
  function pby(id){return typeof getP==='function'?getP(id):((window.S&&S.products)||[]).filter(function(p){return p.id===id;})[0];}
  function currentUser(){return window.S&&S.user&&!S.user.isAnonymous?S.user:null;}
  function tell(msg){if(typeof toast==='function')toast(msg);else alert(msg);}
  function itemsMinPrice(p){var vs=p&&Array.isArray(p.variants)?p.variants:[];if(!vs.length)return 0;return Math.min.apply(null,vs.map(function(v){return Number(v.price)||0;}));}
  function mainImage(p){return p&&(p.image||p.image2||(Array.isArray(p.images)&&p.images[0]))||'';}
  function productCardImage(p){var im=mainImage(p);return im?'<img src="'+safe(im)+'" alt="'+safe(p.name)+'" loading="lazy">':'<div style="height:100px;display:grid;place-items:center;font-size:38px">📦</div>';}
  function mount(){
    if(!document.getElementById('amCompareDock')){var d=document.createElement('div');d.id='amCompareDock';d.innerHTML='<span id="amCompareCount">Compare products</span><button type="button" onclick="AMMarket.openCompare()">Compare now</button><button type="button" class="am-clear-compare" onclick="AMMarket.clearCompare()" aria-label="Clear compare list">Clear</button>';document.body.appendChild(d);}
    if(!document.getElementById('amMarketModal')){var m=document.createElement('div');m.id='amMarketModal';m.className='am-market-overlay';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Marketplace details');m.innerHTML='<div class="am-market-dialog"><div class="am-market-dialog-head"><h3 id="amMarketModalTitle">Online Shah Alami</h3><button type="button" class="am-market-close" onclick="AMMarket.closeModal()" aria-label="Close">×</button></div><div class="am-market-dialog-body" id="amMarketModalBody"></div></div>';m.addEventListener('click',function(e){if(e.target===m)closeMarketModal();});document.body.appendChild(m);}
  }
  function closeMarketModal(){var m=document.getElementById('amMarketModal');if(m)m.classList.remove('on');}
  function openMarketModal(title,body){mount();var m=document.getElementById('amMarketModal');document.getElementById('amMarketModalTitle').textContent=title;document.getElementById('amMarketModalBody').innerHTML=body;m.classList.add('on');document.body.style.overflow='hidden';var reset=function(e){if(e.key==='Escape'){closeMarketModal();document.body.style.overflow='';document.removeEventListener('keydown',reset);}};document.addEventListener('keydown',reset);}
  function refreshDock(){mount();var d=document.getElementById('amCompareDock'),n=document.getElementById('amCompareCount');compareIds=compareIds.filter(function(id){return !!pby(id);});write(STORAGE_COMPARE,compareIds);if(n){var label=compareIds.length+' product'+(compareIds.length===1?'':'s')+' selected';if(n.textContent!==label)n.textContent=label;}if(d)d.classList.toggle('on',compareIds.length>0);document.querySelectorAll('[data-am-compare]').forEach(function(b){var on=compareIds.indexOf(b.getAttribute('data-am-compare'))>-1;b.classList.toggle('is-on',on);b.textContent=on?'✓ Added to compare':'⇄ Compare';});}
  function toggleCompare(id){var p=pby(id);if(!p)return;var i=compareIds.indexOf(id);if(i>-1){compareIds.splice(i,1);tell('Removed from compare');}else{if(compareIds.length>=4){tell('Compare up to 4 products at a time.');return;}compareIds.push(id);tell('Added to compare');}write(STORAGE_COMPARE,compareIds);refreshDock();}
  function clearCompare(){compareIds=[];write(STORAGE_COMPARE,compareIds);refreshDock();}
  function openCompare(){var a=compareIds.map(pby).filter(Boolean);if(a.length<2){tell('Add at least 2 products to compare.');return;}var cards='<div class="am-market-grid">'+a.map(function(p){return '<div class="am-market-mini">'+productCardImage(p)+'<h4>'+safe(p.name)+'</h4><strong>'+money(itemsMinPrice(p))+'</strong><p>'+safe(p.cat||'General')+'</p><button class="am-market-action primary" type="button" onclick="AMMarket.addFirstVariant('+JSON.stringify(p.id).replace(/</g,'\\u003c')+')">Add to cart</button></div>';}).join('')+'</div>';
    var rows=[['Category',function(p){return safe(p.cat||'General');}],['Brand',function(p){return safe(p.brand||'—');}],['Price',function(p){return money(itemsMinPrice(p));}],['Variants',function(p){return (p.variants||[]).map(function(v){return safe(v.size)+': '+money(v.price);}).join('<br>')||'—';}],['Description',function(p){return safe(p.desc||p.description||'—');}],['Stock status',function(p){return (typeof oos==='function'&&oos(p))?'Out of stock':'Available';}]];
    openMarketModal('Compare products',cards+'<div class="am-market-table-wrap"><table class="am-market-table"><tbody>'+rows.map(function(row){return '<tr><th>'+row[0]+'</th>'+a.map(function(p){return '<td>'+row[1](p)+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>');}
  function addFirstVariant(id){var p=pby(id);if(!p)return;if(typeof addItem==='function')addItem(id,0,1);closeMarketModal();document.body.style.overflow='';}
  function recordView(id){if(!id||window._amMarketLastView===id)return;window._amMarketLastView=id;viewedIds=[id].concat(viewedIds.filter(function(x){return x!==id;})).slice(0,12);write(STORAGE_VIEWED,viewedIds);}
  function section(title,subtitle,ids,key){var ps=ids.map(pby).filter(Boolean);if(!ps.length)return '';return '<section class="am-market-block" data-am-extra-block="'+key+'"><div class="am-market-heading"><div><h2>'+title+'</h2><p>'+subtitle+'</p></div></div><div class="grid">'+ps.map(function(p){return typeof pcard==='function'?pcard(p):'<article class="pcard"><a href="#/product/'+safe(p.id)+'">'+productCardImage(p)+'</a><h3>'+safe(p.name)+'</h3><b>'+money(itemsMinPrice(p))+'</b></article>';}).join('')+'</div></section>';}
  function relatedIds(p){var all=(window.S&&S.products)||[];var a=all.filter(function(x){return x.id!==p.id&&(x.cat===p.cat||relatedMatch(x,p));});a.sort(function(x,y){return (x.cat===p.cat?-1:0)-(y.cat===p.cat?-1:0);});return a.slice(0,8).map(function(x){return x.id;});}
  function relatedMatch(x,p){var words=((p.name||'')+' '+(p.cat||'')+' '+(p.searchKeywords||'')).toLowerCase().split(/[^a-z0-9]+/).filter(function(w){return w.length>3;});var text=((x.name||'')+' '+(x.cat||'')+' '+(x.searchKeywords||'')).toLowerCase();return words.some(function(w){return text.indexOf(w)>-1;});}
  function qnaMarkup(pid){var u=currentUser();return '<section class="am-qna" id="amMarketQna"><h3>Questions & answers</h3><p class="am-qna-intro">Ask a question about this product. Our team will publish an answer when it is ready.</p>'+(u?'<form class="am-qna-form" onsubmit="AMMarket.askQuestion(event,'+JSON.stringify(pid).replace(/</g,'\\u003c')+')"><textarea class="inp" name="question" required maxlength="600" placeholder="Ask about size, material, use, delivery or warranty…"></textarea><button class="am-market-action primary" type="submit">Ask question</button></form>':'<p class="am-market-muted"><a href="#/login">Log in</a> to ask a product question.</p>')+'<div class="am-qna-list" id="amQnaList"><p class="am-market-muted">Loading product questions…</p></div></section>';}
  function loadQuestions(pid){var box=document.getElementById('amQnaList');if(!box)return;if(!window.FB_OK||!window.db){box.innerHTML='<p class="am-market-muted">Questions will appear when the store database is connected.</p>';return;}db.collection('productQuestions').where('productId','==',pid).where('status','==','Answered').get().then(function(s){var a=[];s.forEach(function(d){var q=d.data();q.id=d.id;if(q.status==='Answered'&&q.answer)a.push(q);});a.sort(function(x,y){return (y.answeredMs||0)-(x.answeredMs||0);});box.innerHTML=a.length?a.map(function(q){return '<div class="am-qna-item"><div class="am-q">Q: '+safe(q.question)+'</div><small>Answered by Online Shah Alami</small><p class="am-a"><b>A:</b> '+safe(q.answer)+'</p></div>';}).join(''):'<p class="am-market-muted">No answered questions yet. Be the first to ask.</p>';}).catch(function(){if(box)box.innerHTML='<p class="am-market-muted">Questions are temporarily unavailable.</p>';});}
  function askQuestion(e,pid){e.preventDefault();var u=currentUser();if(!u){location.hash='#/login';return;}if(!window.FB_OK||!window.db){tell('Connect Firebase before asking a question.');return;}var form=e.target,question=(form.question.value||'').trim();if(question.length<8){tell('Please enter a little more detail.');return;}var b=form.querySelector('button[type=submit]');b.disabled=true;b.textContent='Submitting…';db.collection('productQuestions').add({productId:pid,productName:(pby(pid)||{}).name||'',userId:u.uid,userEmail:u.email||'',userName:(S.profile&&S.profile.name)||u.displayName||'Customer',question:question,status:'Pending',createdMs:Date.now()}).then(function(){form.reset();b.disabled=false;b.textContent='Ask question';var box=document.getElementById('amQnaList');if(box)box.insertAdjacentHTML('afterbegin','<p class="am-market-muted">Your question was submitted for review.</p>');tell('Question submitted for review.');}).catch(function(err){b.disabled=false;b.textContent='Ask question';tell('Could not submit question. Check Firestore rules.');console.warn(err);});}
  function extraSections(root,p){if(!root||document.getElementById('amMarketExtra'))return;var viewed=viewedIds.filter(function(x){return x!==p.id&&!!pby(x);}).slice(0,8);var related=relatedIds(p);var html='<div id="amMarketExtra">'+section('You may also like','More products selected from related categories.',related,'related')+section('Recently viewed','Products you opened recently on this device.',viewed,'viewed')+'</div>'+qnaMarkup(p.id);root.insertAdjacentHTML('beforeend',html);loadQuestions(p.id);}
  function decorateCards(){document.querySelectorAll('#view .pcard[data-pid]').forEach(function(card){if(card.querySelector('[data-am-compare]'))return;var id=card.getAttribute('data-pid'),body=card.querySelector('.pbody')||card;var b=document.createElement('button');b.type='button';b.className='am-market-action am-compare-card';b.setAttribute('data-am-compare',id);b.textContent='⇄ Compare';b.setAttribute('onclick','AMMarket.toggleCompare('+JSON.stringify(id).replace(/</g,'\\u003c')+')');body.appendChild(b);});}
  function decorate(){if(!document.getElementById('view'))return;decorateCards();var pd=document.querySelector('#view .pd[data-pid]');if(pd){var id=pd.getAttribute('data-pid'),p=pby(id);recordView(id);if(p){var actionRow=pd.querySelector('.row');if(actionRow&&!actionRow.querySelector('.am-detail-compare')){var b=document.createElement('button');b.type='button';b.className='btn dk am-detail-compare';b.textContent='⇄ Compare';b.setAttribute('onclick','AMMarket.toggleCompare('+JSON.stringify(id).replace(/</g,'\\u003c')+')');actionRow.appendChild(b);}extraSections(document.querySelector('#view'),p);}}refreshDock();}
  function renderMyRequests(){var user=currentUser();if(!user||!window.FB_OK||!window.db)return;db.collection('returnRequests').where('userId','==',user.uid).get().then(function(s){loadedMyRequests=[];s.forEach(function(d){var r=d.data();r.id=d.id;loadedMyRequests.push(r);});var box=document.getElementById('amMyRequests');if(!box)return;loadedMyRequests.sort(function(a,b){return (b.createdMs||0)-(a.createdMs||0);});box.innerHTML=loadedMyRequests.length?'<h3 style="margin:20px 0 10px">Returns, refunds & cancellation requests</h3><div class="am-market-grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">'+loadedMyRequests.slice(0,20).map(function(r){var status=(r.status||'Pending').toLowerCase();return '<div class="am-request-card"><h4>'+safe(r.type||'Request')+' · '+safe(r.orderNo||'')+'</h4><p>'+safe(r.reason||'')+'</p><p>Submitted '+(r.createdMs?new Date(r.createdMs).toLocaleDateString():'recently')+'</p><span class="am-return-status '+(status.indexOf('reject')>-1?'rejected':status.indexOf('refund')>-1?'refunded':status.indexOf('complete')>-1?'completed':'')+'">'+safe(r.status||'Pending')+'</span></div>';}).join('')+'</div>':'';setTimeout(decorateOrderList,30);}).catch(function(){var box=document.getElementById('amMyRequests');if(box)box.innerHTML='<p class="am-market-muted">Request history is not available yet. Check your Firestore access rules.</p>';});}
  function requestModal(orderId){var u=currentUser();if(!u){location.hash='#/login';return;}var o=(S.myo||[]).filter(function(x){return x.id===orderId;})[0];if(!o){tell('Order not found. Refresh your account orders and try again.');return;}var delivered=/^(delivered|completed)$/i.test(o.status||'');var opts=delivered?'<option value="Return">Return item</option><option value="Refund">Refund request</option><option value="Exchange">Exchange item</option>':'<option value="Cancellation">Request cancellation</option>';var items=(o.items||[]).map(function(i,index){return '<option value="'+index+'">'+safe(i.name)+' — '+safe(i.size||i.variant||'Standard')+' × '+(Number(i.qty)||1)+'</option>';}).join('');
    openMarketModal(delivered?'Return / refund request':'Cancel an order','<p class="am-market-muted" style="margin:0 0 16px">Order <b>'+safe(o.orderNo)+'</b>. Requests are reviewed by the Online Shah Alami team; submitting a request does not automatically cancel or refund an order.</p><form id="amRequestForm" onsubmit="AMMarket.submitRequest(event,'+JSON.stringify(orderId).replace(/</g,'\\u003c')+')"><div class="fld"><label>Request type</label><select class="inp" name="type">'+opts+'</select></div><div class="fld"><label>Product (if the request concerns one item)</label><select class="inp" name="item"><option value="all">Whole order / all items</option>'+items+'</select></div><div class="fld"><label>Reason</label><select class="inp" name="reason" required><option value="">Choose a reason</option><option>Damaged item</option><option>Wrong item received</option><option>Missing item</option><option>Not as described</option><option>Size or fit issue</option><option>Changed my mind</option><option>Late delivery</option><option>Other</option></select></div><div class="fld"><label>Explain the issue</label><textarea class="inp" name="details" rows="4" maxlength="1200" required placeholder="Tell us what happened and what resolution you are requesting."></textarea></div><div class="fld"><label>Photo evidence (optional)</label><input class="inp" name="photo" type="file" accept="image/*"/><small>Upload one photo showing the issue.</small></div><div id="amRequestMsg" class="am-market-muted" style="margin:8px 0"></div><button class="am-market-action primary" type="submit">Submit request</button></form>');}
  function submitRequest(e,orderId){e.preventDefault();var u=currentUser();if(!u||!window.FB_OK||!window.db){tell('Please sign in and make sure Firebase is connected.');return;}var o=(S.myo||[]).filter(function(x){return x.id===orderId;})[0];if(!o)return;var f=e.target,btn=f.querySelector('button[type=submit]'),type=f.type.value,idx=f.item.value,chosen=idx==='all'?null:(o.items||[])[Number(idx)],details=f.details.value.trim();if(details.length<10){document.getElementById('amRequestMsg').textContent='Please provide at least 10 characters of detail.';return;}var file=f.photo&&f.photo.files&&f.photo.files[0];btn.disabled=true;btn.textContent='Submitting…';var photoPromise=file&&typeof compress==='function'&&typeof storeImg==='function'?compress(file,800,.7).then(function(data){return storeImg(data,'return-requests');}):Promise.resolve('');photoPromise.then(function(photo){return db.collection('returnRequests').add({userId:u.uid,userEmail:u.email||'',customerName:(o.customer&&o.customer.name)||u.displayName||'',orderId:o.id,orderNo:o.orderNo||'',orderStatus:o.status||'',type:type,reason:f.reason.value,details:details,item:chosen?{pid:chosen.pid||'',name:chosen.name||'',variant:chosen.size||chosen.variant||'',qty:chosen.qty||1}:null,photo:photo||'',status:'Pending',createdMs:Date.now(),updatedMs:Date.now()});}).then(function(){closeMarketModal();document.body.style.overflow='';tell('Request sent. The team will review it.');renderMyRequests();}).catch(function(err){btn.disabled=false;btn.textContent='Submit request';var msg=document.getElementById('amRequestMsg');if(msg)msg.textContent='Unable to submit. Check Firebase configuration and Firestore rules for returnRequests.';console.warn(err);});}
  function decorateOrderList(){var table=document.querySelector('#myo table');if(!table||!currentUser())return;var rows=Array.prototype.slice.call(table.querySelectorAll('tr')).slice(1);rows.forEach(function(tr){if(tr.querySelector('.am-order-request'))return;var no=(tr.cells[0]&&tr.cells[0].textContent||'').trim(),o=(S.myo||[]).filter(function(x){return String(x.orderNo||'')===no;})[0];if(!o||!tr.cells.length)return;var td=tr.cells[tr.cells.length-1];var delivered=/^(delivered|completed)$/i.test(o.status||'');var cancellable=/^(pending|confirmed|processing)$/i.test(o.status||'');if(!delivered&&!cancellable)return;var pending=loadedMyRequests.filter(function(r){return r.orderId===o.id&&(/^(pending|in review|approved)$/i.test(r.status||''));})[0];var b=document.createElement('button');b.type='button';b.className='am-market-action am-order-request';b.style.marginTop='6px';b.textContent=pending?'Request submitted':(delivered?'Return / Refund':'Request cancel');b.disabled=!!pending;b.onclick=function(){requestModal(o.id);};td.appendChild(b);});}
  function adminReturns(){var b=document.getElementById('adm');if(!b)return;if(!window.FB_OK||!window.db){b.innerHTML='<div class="msg err">Firebase must be configured to manage return requests.</div>';return;}b.innerHTML='<div class="card"><h3>Returns, refunds & cancellation requests</h3><p class="am-market-muted">Review customer submissions, approve/reject them and update the request status. This does not trigger an automatic money transfer.</p><div id="amReturnsAdminList" class="am-admin-feature-grid"><p>Loading requests…</p></div></div>';db.collection('returnRequests').get().then(function(s){var a=[];s.forEach(function(d){var r=d.data();r.id=d.id;a.push(r);});a.sort(function(x,y){return (y.createdMs||0)-(x.createdMs||0);});var box=document.getElementById('amReturnsAdminList');if(!box)return;box.innerHTML=a.length?a.map(function(r){var st=(r.status||'Pending').toLowerCase();var statusClass=st.indexOf('reject')>-1?'rejected':st.indexOf('refund')>-1?'refunded':st.indexOf('complete')>-1?'completed':'';return '<div class="am-request-card"><div style="display:flex;align-items:start;justify-content:space-between;gap:8px"><h4>'+safe(r.type||'Request')+' · '+safe(r.orderNo||'')+'</h4><span class="am-return-status '+statusClass+'">'+safe(r.status||'Pending')+'</span></div><p><b>Customer:</b> '+safe(r.customerName||'')+' '+(r.userEmail?'('+safe(r.userEmail)+')':'')+'</p><p><b>Reason:</b> '+safe(r.reason||'')+'</p><p><b>Details:</b> '+safe(r.details||'')+'</p>'+(r.item?'<p><b>Item:</b> '+safe(r.item.name||'')+' / '+safe(r.item.variant||'')+' × '+safe(r.item.qty||1)+'</p>':'')+(r.photo?'<p><a target="_blank" rel="noopener" href="'+safe(r.photo)+'">View evidence photo</a></p>':'')+'<p><small>'+new Date(r.createdMs||Date.now()).toLocaleString()+'</small></p><div class="am-request-actions"><button class="am-market-action" onclick="AMMarket.setReturnStatus('+JSON.stringify(r.id).replace(/</g,'\\u003c')+',\'Approved\')">Approve</button><button class="am-market-action" onclick="AMMarket.setReturnStatus('+JSON.stringify(r.id).replace(/</g,'\\u003c')+',\'Rejected\')">Reject</button><button class="am-market-action" onclick="AMMarket.setReturnStatus('+JSON.stringify(r.id).replace(/</g,'\\u003c')+',\'Refunded\')">Mark refunded</button><button class="am-market-action primary" onclick="AMMarket.setReturnStatus('+JSON.stringify(r.id).replace(/</g,'\\u003c')+',\'Completed\')">Complete</button></div></div>';}).join(''):'<p class="am-market-muted">No requests have been submitted yet.</p>';}).catch(function(err){var box=document.getElementById('amReturnsAdminList');if(box)box.innerHTML='<p class="msg err">Could not load requests. Check returnRequests Firestore rules. '+safe(err.message||'')+'</p>';});}
  function setReturnStatus(id,status){if(!window.FB_OK||!window.db)return;db.collection('returnRequests').doc(id).update({status:status,updatedMs:Date.now(),updatedBy:(currentUser()&&currentUser().email)||''}).then(function(){tell('Request updated: '+status);adminReturns();}).catch(function(err){tell('Could not update. Check Firestore rules.');console.warn(err);});}
  function adminQA(){var b=document.getElementById('adm');if(!b)return;if(!window.FB_OK||!window.db){b.innerHTML='<div class="msg err">Firebase must be configured to manage product Q&A.</div>';return;}b.innerHTML='<div class="card"><h3>Product questions & answers</h3><p class="am-market-muted">Answer pending customer questions. Published answers appear on the relevant product page.</p><div id="amQAAdminList"><p>Loading questions…</p></div></div>';db.collection('productQuestions').get().then(function(s){var a=[];s.forEach(function(d){var q=d.data();q.id=d.id;a.push(q);});a.sort(function(x,y){return (y.createdMs||0)-(x.createdMs||0);});var box=document.getElementById('amQAAdminList');if(!box)return;box.innerHTML=a.length?a.map(function(q){return '<form class="am-request-card" onsubmit="AMMarket.answerQuestion(event,'+JSON.stringify(q.id).replace(/</g,'\\u003c')+')"><h4>'+safe(q.productName||'Product')+' · '+safe(q.status||'Pending')+'</h4><p><b>Customer:</b> '+safe(q.userName||'')+' '+safe(q.userEmail||'')+'</p><p><b>Question:</b> '+safe(q.question||'')+'</p><div class="fld"><label>Answer (will be public)</label><textarea class="inp" name="answer" rows="3" maxlength="1200" required>'+safe(q.answer||'')+'</textarea></div><div class="am-request-actions"><button class="am-market-action primary" type="submit">'+(q.status==='Answered'?'Update published answer':'Publish answer')+'</button><button class="am-market-action" type="button" onclick="AMMarket.deleteQuestion('+JSON.stringify(q.id).replace(/</g,'\\u003c')+')">Delete</button></div></form>';}).join(''):'<p class="am-market-muted">No customer questions yet.</p>';}).catch(function(err){var box=document.getElementById('amQAAdminList');if(box)box.innerHTML='<p class="msg err">Could not load questions. Check productQuestions Firestore rules.</p>';});}
  function answerQuestion(e,id){e.preventDefault();var f=e.target,answer=f.answer.value.trim();if(answer.length<3){tell('Please write an answer.');return;}var b=f.querySelector('button[type=submit]');b.disabled=true;db.collection('productQuestions').doc(id).update({answer:answer,status:'Answered',answeredMs:Date.now(),answeredBy:(currentUser()&&currentUser().email)||''}).then(function(){tell('Answer published.');adminQA();}).catch(function(err){b.disabled=false;tell('Could not publish answer. Check Firestore rules.');console.warn(err);});}
  function deleteQuestion(id){if(!confirm('Delete this product question?'))return;db.collection('productQuestions').doc(id).delete().then(function(){tell('Question deleted.');adminQA();}).catch(function(){tell('Could not delete question.');});}
  function adminTabButtons(){var old=window.pAdmin;if(typeof old!=='function')return;window.pAdmin=function(){var html=old.apply(this,arguments);if(typeof html==='string'&&html.indexOf('id="atabs"')>-1&&html.indexOf('PH.tab(\'returns\')')<0){html=html.replace('<button onclick="PH.refresh()">⟳ Refresh</button>','<button onclick="PH.tab(\'returns\')">Returns &amp; Refunds</button><button onclick="PH.tab(\'productQA\')">Product Q&amp;A</button><button onclick="PH.refresh()">⟳ Refresh</button>');}return html;};}
  function adminDrawWrapper(){var old=window.drawAdmin;if(typeof old!=='function')return;window.drawAdmin=function(){if(window.S&&S.tab==='returns'){adminReturns();var tabs=document.getElementById('atabs');if(tabs)tabs.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',/Returns/.test(b.textContent));});return;}if(window.S&&S.tab==='productQA'){adminQA();var tabs2=document.getElementById('atabs');if(tabs2)tabs2.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',/Product Q/.test(b.textContent));});return;}return old.apply(this,arguments);};}
  function orderListWrapper(){var old=window.drawOrdersList;if(typeof old!=='function')return;window.drawOrdersList=function(){old.apply(this,arguments);if(!currentUser())return;var m=document.getElementById('myo');if(m&&!document.getElementById('amMyRequests'))m.insertAdjacentHTML('afterend','<div id="amMyRequests"></div>');renderMyRequests();setTimeout(decorateOrderList,80);};}
  var api={toggleCompare:toggleCompare,openCompare:openCompare,clearCompare:clearCompare,closeModal:function(){closeMarketModal();document.body.style.overflow='';},addFirstVariant:addFirstVariant,askQuestion:askQuestion,requestReturn:requestModal,submitRequest:submitRequest,setReturnStatus:setReturnStatus,answerQuestion:answerQuestion,deleteQuestion:deleteQuestion,adminReturns:adminReturns,adminQA:adminQA};
  window.AMMarket=api;
  compareIds=read(STORAGE_COMPARE,[]);viewedIds=read(STORAGE_VIEWED,[]);
  mount();adminTabButtons();adminDrawWrapper();orderListWrapper();
  function enhance(){try{decorate();}catch(e){console.warn('Online Shah Alami marketplace enhancement:',e);}}
  if(document.body){var viewObserver=new MutationObserver(function(){if(window._amMarketRaf)return;window._amMarketRaf=requestAnimationFrame(function(){window._amMarketRaf=0;enhance();});});viewObserver.observe(document.body,{childList:true,subtree:true});}
  window.addEventListener('hashchange',function(){setTimeout(enhance,70);});document.addEventListener('keydown',function(e){if(e.key==='Escape'){closeMarketModal();document.body.style.overflow='';}});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',enhance);else setTimeout(enhance,50);
})();


/* ===== Extracted inline script 5 ===== */

(function(){
  'use strict';
  var API = window.AnasMartExtension;
  if (!API) return;
  var CUSTOM = ['deals','stores','store','vouchers','seller-center','wholesale','reseller-center','wholesale-center','help-center'];
  function esc(x){return API.escape(x==null?'':x)}
  function money(n){return API.money(n)}
  function products(){return API.products()||[]}
  function config(){return API.config()||{}}
  function liveRoute(){return (location.hash||'#/home').replace(/^#\/?/,'').split('/').filter(Boolean)}
  function rootExists(route){var r=document.getElementById('am-mkt-custom-root');return !!(r&&r.getAttribute('data-route')===route)}
  function frame(route,title,sub,body){return '<div id="am-mkt-custom-root" data-route="'+esc(route)+'"><section class="phead"><div class="wrap"><button class="back" type="button" onclick="PH.back()">← Back</button><h1>'+esc(title)+'</h1><p>'+esc(sub||'')+'</p></div></section>'+body+'</div>'}
  function pageWrap(body){return '<section class="am-market-page"><div class="wrap">'+body+'</div></section>'}
  function btn(href,text,cls){return '<a class="btn '+(cls||'')+'" href="'+href+'">'+text+'</a>'}
  function currentMin(p){return API.minPrice(p)}
  function discounted(p){return Number(p.oldPrice)>currentMin(p)&&currentMin(p)>0}
  function offerProducts(){var a=products().filter(function(p){return discounted(p)||p.badge||p.isNew||p.hot;});return (a.length?a:products()).slice(0,8)}
  function tileIcon(cat){var c=config();return (c.catEmoji&&c.catEmoji[cat])||'🛍️'}
  function homeModules(){
    var view=document.getElementById('view'), trust=view&&view.querySelector('.trust');
    if(!trust||document.getElementById('amMarketplaceHomeModules'))return;
    var cats=(config().categories||[]).slice(0,10), ps=offerProducts();
    var cathtml=cats.map(function(c){return '<button class="am-market-category" type="button" onclick="AnasMartExtension.category('+JSON.stringify(c).replace(/</g,'\\u003c')+')"><span>'+tileIcon(c)+'</span>'+esc(c)+'</button>'}).join('');
    var cards=ps.map(function(p){return API.card(p)}).join('');
    var module='<div id="amMarketplaceHomeModules">'+
      '<section class="am-market-section"><div class="am-market-panel"><div class="am-market-head"><div><h2>Shop by category</h2><p>Browse your favourite departments without leaving Online Shah Alami.</p></div><a class="am-market-link" href="#/shop">All products →</a></div><div class="am-market-categories">'+cathtml+'</div></div></section>'+
      '<section class="am-market-section"><div class="am-market-panel"><div class="am-market-head"><div><h2>Deals &amp; popular picks</h2><p>Explore featured products, newly added items and any sale prices currently listed.</p></div><a class="am-market-link" href="#/deals">Explore offers →</a></div>'+(cards?'<div class="grid">'+cards+'</div>':'<div class="am-market-empty">Products will appear here when the catalog is published.</div>')+'</div></section>'+
      '<section class="am-market-section"><div class="am-market-panel"><div class="am-market-head"><div><h2>More ways to shop</h2><p>Useful marketplace tools, built into the Online Shah Alami theme.</p></div></div><div class="am-market-feature-grid">'+
      '<a class="am-market-feature" href="#/stores"><span>🏬</span><div><b>Stores &amp; brands</b><small>Explore product brands and independent seller listings.</small></div></a>'+
      '<a class="am-market-feature" href="#/vouchers"><span>🎟️</span><div><b>Vouchers</b><small>See active discount codes published by the store.</small></div></a>'+
      '<a class="am-market-feature" href="#/account"><span>📦</span><div><b>Orders &amp; returns</b><small>Track orders, reorder items and submit supported return requests.</small></div></a>'+
      '<a class="am-market-feature" href="#/help-center"><span>💬</span><div><b>Help centre</b><small>Find FAQs, policies and customer-support links.</small></div></a>'+
      '</div></div></section>'+
      '<section class="am-market-section"><div class="am-market-panel"><div class="am-market-sell-grid">'+
      '<div class="am-market-sell-card"><h3>🏭 Buy wholesale</h3><p>Request business access for approved bulk prices, minimum quantities and bulk-order tools.</p>'+btn('#/wholesale-center','Open wholesale portal','')+'</div>'+
      '<div class="am-market-sell-card"><h3>🤝 Sell &amp; earn</h3><p>Apply for reseller access, promote approved products, track commissions and request payouts.</p>'+btn('#/reseller-center','Open reseller portal','')+'</div>'+
      '</div></div></section></div>';
    trust.insertAdjacentHTML('afterend',module);
  }
  function addShortcutNav(){
    var cat=document.querySelector('.catbar'); if(!cat||document.querySelector('.am-market-quicknav'))return;
    cat.insertAdjacentHTML('afterend','<nav class="am-market-quicknav" aria-label="Marketplace shortcuts">'+
      '<a href="#/deals">🔥 Deals</a><a href="#/stores">🏬 Stores &amp; brands</a><a href="#/vouchers">🎟️ Vouchers</a><a href="#/wholesale-center">🏭 Wholesale portal</a><a href="#/reseller-center">🤝 Reseller portal</a><a href="#/seller-center">Business centre</a><a href="#/help-center">💬 Help centre</a></nav>');
    var f=null;
    if(f&&!f.querySelector('[data-am-extra-footer]'))f.insertAdjacentHTML('beforeend','<div data-am-extra-footer="1" style="margin-top:8px"><a href="#/deals">Deals &amp; offers</a><a href="#/stores">Stores &amp; brands</a><a href="#/vouchers">Vouchers</a><a href="#/wholesale-center">Wholesale portal</a><a href="#/reseller-center">Reseller portal</a><a href="#/seller-center">Business centre</a><a href="#/help-center">Help centre</a></div>');
  }
  function dealsPage(){
    var ps=offerProducts();
    var cards=ps.map(function(p){var off=discounted(p)?Math.round((1-currentMin(p)/Number(p.oldPrice))*100):0;return API.card(p)}).join('');
    return frame('deals','Deals & popular picks','Browse current sale prices, featured products and new arrivals.',pageWrap('<div class="am-market-statrow"><span>💳 COD, JazzCash &amp; EasyPaisa</span><span>🚚 Delivery across Pakistan</span><span>🔄 Store return policy applies</span></div><div class="am-market-head"><div><h2>Featured offers</h2><p class="am-market-muted">Discount labels are based on product prices and tags currently saved in the Online Shah Alami catalog.</p></div><a class="am-market-link" href="#/shop">Browse full shop →</a></div>'+(cards?'<div class="grid">'+cards+'</div>':'<div class="am-market-empty">No products are published yet.</div>')));
  }
  function storeGroups(){
    var map={};
    products().forEach(function(p){
      var owner=String(p.owner||'').trim(), brand=String(p.brand||p.storeName||p.sellerName||'').trim();
      var key=owner?'seller:'+owner.toLowerCase():(brand?'brand:'+brand.toLowerCase():'store:online-shah-alami');
      var label=String(p.sellerName||p.storeName||p.brand||'').trim()||(owner?'Independent seller':'Online Shah Alami');
      if(!map[key])map[key]={key:key,label:label,products:[],categories:[]};
      map[key].products.push(p); if(p.cat&&map[key].categories.indexOf(p.cat)<0)map[key].categories.push(p.cat);
    });
    return Object.keys(map).map(function(k){return map[k]}).sort(function(a,b){return a.label.localeCompare(b.label)});
  }
  function storesPage(){
    var groups=storeGroups();
    var html=groups.map(function(g){return '<a class="am-market-store" data-am-store-card="1" data-store-search="'+esc((g.label+' '+g.categories.join(' ')).toLowerCase())+'" href="#/store/'+encodeURIComponent(g.key)+'"><div class="am-market-store-icon">'+(g.key.indexOf('seller:')===0?'🤝':(g.key.indexOf('brand:')===0?'🏷️':'🛍️'))+'</div><h3>'+esc(g.label)+'</h3><p class="am-market-muted">'+g.products.length+' product'+(g.products.length===1?'':'s')+' · '+esc(g.categories.slice(0,3).join(', ')||'Multiple categories')+'</p><span class="am-market-link">View store →</span></a>'}).join('');
    return frame('stores','Stores & brands','Discover the Online Shah Alami catalog by brand and seller.',pageWrap('<div class="bar"><input class="inp" id="amStoreSearch" style="max-width:420px" placeholder="Search stores or categories…" oninput="AMarketUI.filterStores(this.value)"/><a class="am-market-link" href="#/shop">Shop every product →</a></div><div class="am-market-statrow"><span>'+groups.length+' store grouping'+(groups.length===1?'':'s')+'</span><span>Seller products appear after publication</span></div>'+(html?'<div class="am-market-grid">'+html+'</div>':'<div class="am-market-empty">No stores are listed yet. Browse the main shop or return later.</div>')));
  }
  function storePage(encodedKey){
    var key;try{key=decodeURIComponent(encodedKey||'')}catch(e){key=encodedKey||''}
    var groups=storeGroups(), g=groups.filter(function(x){return x.key===key})[0];
    if(!g)return frame('store','Store not found','This storefront may have changed or its products may no longer be published.',pageWrap('<div class="am-market-empty"><p>We could not find that store.</p><p style="margin-top:12px"><a class="btn" href="#/stores">Browse stores</a></p></div>'));
    return frame('store:'+key,g.label,'Products currently listed under this storefront.',pageWrap('<div class="am-market-statrow"><span>🏬 '+g.products.length+' products</span><span>'+esc(g.categories.join(', ')||'General')+'</span><a class="am-market-link" href="#/stores">← All stores</a></div><div class="grid">'+g.products.map(function(p){return API.card(p)}).join('')+'</div>'));
  }
  function vouchersPage(){
    var html=frame('vouchers','Vouchers & discount codes','Codes published by Online Shah Alami can be entered at checkout.',pageWrap('<div class="am-market-muted" style="margin-bottom:16px">Voucher availability depends on the code status, expiry date and minimum order amount.</div><div id="am-voucher-list" class="am-market-grid"><div class="am-market-empty">Checking available vouchers…</div></div>'));
    setTimeout(function(){API.loadCoupons().then(function(a){var box=document.getElementById('am-voucher-list');if(!box||location.hash.indexOf('#/vouchers')!==0)return;var now=Date.now();a=a.filter(function(c){return c.active!==false&&(!c.expiresMs||now<=Number(c.expiresMs))});box.innerHTML=a.length?a.map(function(c){var code=String(c.code||c.id||'').toUpperCase(),discount=c.type==='percent'?(Number(c.value)||0)+'% off':money(c.value||0)+' off',exp=c.expiresMs?'Expires '+new Date(c.expiresMs).toLocaleDateString():'No expiry date saved',min=Number(c.minOrder)>0?'Minimum order '+money(c.minOrder):'No minimum order saved';return '<div class="am-voucher"><span>🎟️ Online Shah Alami voucher</span><strong>'+esc(discount)+'</strong><div class="am-voucher-code">'+esc(code)+'</div><small class="am-market-muted">'+esc(min)+' · '+esc(exp)+'</small><button class="btn sm" type="button" onclick="AMarketUI.copyVoucher('+JSON.stringify(code).replace(/</g,'\\u003c')+')">Copy code</button></div>'}).join(''):'<div class="am-market-empty"><h3>No active vouchers published</h3><p style="margin-top:8px">New codes will show here when the store publishes them in Admin → Discounts.</p></div>'}).catch(function(){var box=document.getElementById('am-voucher-list');if(box)box.innerHTML='<div class="am-market-empty">Voucher information is unavailable right now. Please check back later.</div>'})},0);
    return html;
  }
  /* Advanced reseller + wholesale business portals. These are Online Shah Alami experiences inspired by common marketplace workflows, not copies of other platforms. */
  function bizArg(v){return "'"+String(v==null?'':v).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/[\r\n]/g,'').replace(/</g,'\\x3c')+"'";}
  function bizUid(){var u=API.currentUser();return u&&u.uid?String(u.uid):(u&&u.email?String(u.email):'guest');}
  function bizLogged(){var u=API.currentUser();return !!(u&&!u.isAnonymous);}
  function bizRead(key,fallback){try{var v=localStorage.getItem('am_biz_'+key+'_'+bizUid());return v?JSON.parse(v):fallback;}catch(e){return fallback;}}
  function bizWrite(key,value){try{localStorage.setItem('am_biz_'+key+'_'+bizUid(),JSON.stringify(value));return true;}catch(e){return false;}}
  function bizProfiles(){return bizRead('company-profile',{});}
  function bizApproved(kind){var p=API.profile()||{};return kind==='reseller'?p.type==='reseller':!!p.wholesale;}
  function bizEscapeAttr(v){return esc(v==null?'':v);}
  function bizDomId(v){return String(v==null?'x':v).replace(/[^A-Za-z0-9_-]/g,'_');}
  function bizActiveProducts(){return products().filter(function(p){return p&&p.active!==false;});}
  function bizWholesaleProducts(){return bizActiveProducts().filter(function(p){return Number(p.ws)>0;});}
  function bizProductImage(p){var src=String((p&&p.image)||'');if(/^https?:\/\//i.test(src)||/^data:image\/(?:png|jpeg|jpg|webp|gif);base64,/i.test(src))return '<img src="'+esc(src)+'" alt="'+esc(p.name||'Product')+'" loading="lazy"/>';return '<div class="am-biz-placeholder">🛍️</div>';}
  function bizProductCard(p,kind){
    var id=String(p.id||''),dom=bizDomId(id),retail=Number(API.minPrice(p))||0,ws=Number(p.ws)||0,cost=ws>0?ws:retail,mn=Math.max(1,Number(p.wsMin)||10),saving=retail>ws&&ws>0?Math.round((retail-ws)*100/retail):0;
    var category=String(p.cat||'General'),tags=(p.name+' '+category+' '+(p.brand||'')).toLowerCase();
    if(kind==='reseller')return '<article class="am-biz-product" data-am-reseller-card="1" data-search="'+esc(tags)+'" data-category="'+esc(category)+'"><div class="am-biz-product-photo">'+bizProductImage(p)+'<span class="am-biz-badge">'+esc(category)+'</span></div><div class="am-biz-product-info"><h3>'+esc(p.name||'Unnamed product')+'</h3><div class="am-biz-price-row"><strong>'+money(retail)+'</strong><span>'+(ws>0?'Wholesale cost available':'Retail reference price')+'</span></div><div class="am-biz-calculator"><label for="am-rprice-'+dom+'">Your selling price (PKR)</label><input id="am-rprice-'+dom+'" type="number" min="0" step="1" placeholder="Enter your price" oninput="AMarketBusinessUI.resellerProfit('+bizArg(id)+',this.value)"/><p id="am-rprofit-'+dom+'">Reference cost: '+money(cost)+' · Enter your price to estimate margin.</p></div><div class="am-biz-actions"><button type="button" class="btn sm" onclick="AMarketBusinessUI.resellerShare('+bizArg(id)+',\'copy\')">Copy product link</button><button type="button" class="btn ghost sm" onclick="AMarketBusinessUI.resellerShare('+bizArg(id)+',\'wa\')">Share on WhatsApp</button></div></div></article>';
    return '<article class="am-biz-product" data-am-wholesale-card="1" data-pid="'+esc(id)+'" data-search="'+esc(tags)+'" data-category="'+esc(category)+'" data-price="'+ws+'" data-saving="'+saving+'"><div class="am-biz-product-photo">'+bizProductImage(p)+'<span class="am-biz-badge">'+(saving?saving+'% less than retail':'Bulk pricing')+'</span></div><div class="am-biz-product-info"><h3>'+esc(p.name||'Unnamed product')+'</h3><div class="am-biz-price-row"><strong>'+money(ws)+'/unit</strong><span>Retail: '+money(retail)+'</span></div><div class="am-biz-meta"><span>📦 Minimum: <b>'+mn+'</b></span><span>💰 Est. saving/unit: <b>'+money(Math.max(0,retail-ws))+'</b></span></div><div class="am-biz-qty-row"><label><input type="checkbox" data-am-ws-select="1" aria-label="Select '+esc(p.name||'product')+' for purchase list"/> Select for list</label><input id="wq_'+esc(id)+'" type="number" min="'+mn+'" step="1" value="'+mn+'" aria-label="Quantity for '+esc(p.name||'product')+'"/></div><div class="am-biz-actions"><button type="button" class="btn sm" onclick="AMarketBusinessUI.wholesaleAdd('+bizArg(id)+')">Add bulk quantity</button><a class="btn ghost sm" href="#/product/'+encodeURIComponent(id)+'">Product details</a></div></div></article>';
  }
  function bizCategories(list){var a=[];list.forEach(function(p){var c=String(p.cat||'General');if(a.indexOf(c)<0)a.push(c);});return a.sort(function(x,y){return x.localeCompare(y);});}
  function bizSelectOptions(items,current){return items.map(function(x){return '<option value="'+esc(x)+'"'+(x===current?' selected':'')+'>'+esc(x)+'</option>';}).join('');}
  function bizGate(kind){var approved=bizApproved(kind),type=kind==='reseller'?'reseller':'business',label=kind==='reseller'?'Reseller':'Wholesale business',profile=API.profile()||{},pending=profile.requestedType===type;
    if(approved)return '<div class="am-biz-access am-biz-approved"><span class="am-biz-access-icon">✓</span><div><b>'+label+' access approved</b><small>Your account can use the relevant protected actions. Order, payout and payment processing still follow configured store rules.</small></div></div>';
    return '<div class="am-biz-access"><span class="am-biz-access-icon">🔐</span><div><b>'+(pending?'Your access request is under review':'Activate your '+label.toLowerCase()+' account')+'</b><small>'+(bizLogged()?'Submit an access request. The Online Shah Alami administrator must approve it before protected selling or bulk-buy actions are enabled.':'Sign in or create an account, then request access. Approval is required for protected actions.')+'</small></div><button class="btn sm" type="button" onclick="AMarketBusinessUI.requestAccess('+bizArg(type)+')">'+(pending?'View account status':'Request access')+'</button></div>';
  }
  function bizSectionNav(items){return '<nav class="am-biz-section-nav" aria-label="Business portal sections">'+items.map(function(it){return '<button type="button" onclick="AMarketBusinessUI.scrollTo('+bizArg(it[0])+')"><span>'+it[1]+'</span></button>';}).join('')+'</nav>';}
  function bizMetric(icon,value,label,detail){return '<div class="am-biz-metric"><span class="am-biz-metric-icon">'+icon+'</span><div><b>'+value+'</b><span>'+label+'</span><small>'+detail+'</small></div></div>';}
  function bizPortalHero(kind,title,desc,stats){return '<section class="am-biz-hero am-biz-'+kind+'-hero"><div class="am-biz-hero-copy"><span class="am-biz-eyebrow">Online Shah Alami · BUSINESS PORTAL</span><h2>'+title+'</h2><p>'+desc+'</p><div class="am-biz-hero-actions">'+stats+'</div></div><div class="am-biz-orbit-art" aria-hidden="true"><div class="am-biz-orbit am-biz-orbit-one"></div><div class="am-biz-orbit am-biz-orbit-two"></div><div class="am-biz-cube"><i>AM</i><i>✦</i><i>📦</i><i>✓</i><i>↗</i><i>💼</i></div></div></section>';}
  function resellerCampaignHtml(){var list=bizRead('reseller-campaigns',[]);if(!list.length)return '<div class="am-biz-empty">No campaign drafts saved on this device yet. Create a campaign above to prepare product copy for your channels.</div>';return '<div class="am-biz-campaign-list">'+list.slice().reverse().map(function(c){return '<article class="am-biz-campaign"><div><span class="am-biz-tag">'+esc(c.channel||'Social')+'</span><h4>'+esc(c.name||'Campaign draft')+'</h4><p>'+esc(c.productName||'Product')+' · '+new Date(c.createdMs||Date.now()).toLocaleDateString()+'</p></div><div class="am-biz-campaign-actions"><button class="btn sm" type="button" onclick="AMarketBusinessUI.campaignCopy('+bizArg(c.id)+')">Copy message</button><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.campaignWhatsApp('+bizArg(c.id)+')">Open WhatsApp</button></div></article>';}).join('')+'</div>';}
  function resellerCenterPage(){
    var p=API.profile()||{},u=API.currentUser()||{},approved=bizApproved('reseller'),all=bizActiveProducts(),uid=String(u.uid||''),owned=(API.allProducts?API.allProducts():[]).filter(function(x){return uid&&x.owner===uid;}),settings=(window.S&&window.S.resellerSettings)||((API.config()||{}).resellerDefaults||{}),rate=Number(settings.commissionPct==null?10:settings.commissionPct),cats=bizCategories(all),profile=bizProfiles();
    var productCards=all.length?all.map(function(x){return bizProductCard(x,'reseller');}).join(''):'<div class="am-biz-empty">The catalog is empty. Published products will appear here once the store has products.</div>';
    var mine=owned.length?'<div class="am-biz-table-wrap"><table class="am-biz-table"><thead><tr><th>Product</th><th>Price</th><th>Status</th><th>Action</th></tr></thead><tbody>'+owned.map(function(x){return '<tr><td><b>'+esc(x.name||'Product')+'</b><small>'+esc(x.cat||'General')+'</small></td><td>'+money(API.minPrice(x))+'</td><td><span class="am-biz-tag">'+(x.active===false?'Pending / inactive':'Published')+'</span></td><td><button class="btn sm" onclick="AMarketBusinessUI.openResellerAccount()" type="button">Manage listing</button></td></tr>';}).join('')+'</tbody></table></div>':'<div class="am-biz-empty">Your own listings will be shown here when available. Use “Add my product” to open the existing Online Shah Alami product editor; new or edited listings remain subject to admin review.</div>';
    var html=bizPortalHero('reseller','Build your reseller business','Discover products, calculate your retail margin, plan campaigns, share listings and manage sales from one workspace.','<a class="btn" href="#am-r-catalog" onclick="return AMarketBusinessUI.scrollTo(\'am-r-catalog\')">Explore catalog</a><button class="btn ghost" type="button" onclick="AMarketBusinessUI.openResellerAccount()">Earnings &amp; payouts</button>')+
      bizGate('reseller')+
      '<div class="am-biz-metric-grid">'+bizMetric('🛍️',String(all.length),'Products to explore','Current published catalog')+bizMetric('📦',String(owned.length),'My own listings','Loaded from available product data')+bizMetric('💸',rate+'%','Configured commission','Admin-configured setting; applies only where eligible')+bizMetric('🔐',approved?'Approved':(p.requestedType==='reseller'?'In review':'Not active'),'Access status','Protected reseller actions require approval')+'</div>'+
      bizSectionNav([['am-r-overview','◈ Overview'],['am-r-catalog','🛍️ Product catalog'],['am-r-campaigns','📣 Campaign studio'],['am-r-listings','📦 My listings'],['am-r-earnings','💸 Earnings & payouts'],['am-r-growth','🎓 Growth centre']])+
      '<section class="am-biz-section" id="am-r-overview"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">YOUR WORKSPACE</span><h3>Daily overview</h3><p>Key tasks and account setup in one place.</p></div><span class="am-biz-live-tag"><i></i> '+(approved?'Account active':'Preview mode')+'</span></div><div class="am-biz-task-grid"><button class="am-biz-task" onclick="AMarketBusinessUI.scrollTo(\'am-r-catalog\')"><span>🔎</span><b>Find products</b><small>Review product prices and estimate your margin.</small></button><button class="am-biz-task" onclick="AMarketBusinessUI.scrollTo(\'am-r-campaigns\')"><span>📣</span><b>Plan a campaign</b><small>Save a reusable promotion message draft.</small></button><button class="am-biz-task" onclick="AMarketBusinessUI.openResellerAccount()"><span>📊</span><b>Review sales</b><small>Open the existing order, commission and payout dashboard.</small></button><button class="am-biz-task" onclick="AMarketBusinessUI.openResellerProductEditor()"><span>➕</span><b>Add my listing</b><small>Create a product for admin review.</small></button></div><div class="am-biz-checklist"><div class="am-biz-section-heading"><div><h4>Business setup checklist</h4><p>Use this to keep your account launch-ready.</p></div></div><div class="am-biz-check-row"><span>✓</span><div><b>Create an account and request reseller access</b><small>Admin review controls access to reseller-only actions.</small></div><em>'+(approved?'Complete':(p.requestedType==='reseller'?'In review':'To do'))+'</em></div><div class="am-biz-check-row"><span>2</span><div><b>Review product details and selling prices</b><small>Use the catalog and margin estimator before sharing.</small></div><em>Recommended</em></div><div class="am-biz-check-row"><span>3</span><div><b>Prepare a promotion and contact method</b><small>Use the campaign studio and your configured contact details.</small></div><em>Recommended</em></div><div class="am-biz-check-row"><span>4</span><div><b>Review payout details in your account</b><small>Payout requests are reviewed by Online Shah Alami and are not automatic transfers.</small></div><em>Before payout</em></div></div></section>'+
      '<section class="am-biz-section" id="am-r-catalog"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">PRODUCT SOURCING</span><h3>Product catalog &amp; margin estimator</h3><p>Explore current products, share product pages and estimate your price margin. Product links here do not by themselves guarantee referral attribution.</p></div><a class="am-biz-text-link" href="#/shop">Open customer storefront ↗</a></div><div class="am-biz-filterbar"><input id="am-reseller-search" type="search" class="inp" placeholder="Search products, brands or categories…" oninput="AMarketBusinessUI.filterReseller(this.value)"/><select class="inp" id="am-reseller-cat" onchange="AMarketBusinessUI.filterReseller()"><option value="">All categories</option>'+bizSelectOptions(cats,'')+'</select><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.openResellerAccount()">Manage my listings</button></div><div class="am-biz-product-grid" id="am-reseller-catalog">'+productCards+'</div></section>'+
      '<section class="am-biz-section" id="am-r-campaigns"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">MARKETING WORKSPACE</span><h3>Campaign studio</h3><p>Create reusable social-selling drafts for WhatsApp, Facebook, Instagram or your own customer list.</p></div></div><div class="am-biz-two-col"><form class="am-biz-form" onsubmit="AMarketBusinessUI.saveCampaign(event)"><div class="fld"><label>Campaign name</label><input name="campaignName" required placeholder="e.g. Eid home essentials" maxlength="90"/></div><div class="g2"><div class="fld"><label>Promotion channel</label><select name="channel"><option>WhatsApp</option><option>Facebook</option><option>Instagram</option><option>Customer list</option></select></div><div class="fld"><label>Product</label><select name="productId" required>'+all.map(function(x){return '<option value="'+esc(x.id)+'">'+esc(x.name||'Product')+'</option>';}).join('')+'</select></div></div><div class="fld"><label>Offer or message angle</label><input name="offer" placeholder="e.g. New arrival, bundle, seasonal pick" maxlength="120"/></div><div class="fld"><label>Personal note (optional)</label><textarea name="message" rows="3" placeholder="A short message for your customers"></textarea></div><button class="btn" type="submit">Save draft &amp; prepare share text</button><small class="am-biz-form-note">Drafts are saved in this browser only. Publishing ads and tracking clicks require backend integrations.</small></form><div class="am-biz-panel"><h4>Campaign checklist</h4><div class="am-biz-check-row"><span>1</span><div><b>Choose a catalog product</b><small>Confirm stock, description and current price.</small></div></div><div class="am-biz-check-row"><span>2</span><div><b>Set a clear customer message</b><small>Avoid claims or discounts that are not configured in the store.</small></div></div><div class="am-biz-check-row"><span>3</span><div><b>Share to your selected channel</b><small>Use the buttons on your saved draft.</small></div></div><div id="am-r-campaign-output" class="am-biz-output" aria-live="polite">Your generated campaign copy will appear here.</div></div></div><div class="am-biz-section-heading" style="margin-top:24px"><div><h4>Saved campaign drafts</h4><p>Stored on this device for this signed-in profile.</p></div><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.clearCampaigns()">Clear drafts</button></div><div id="am-r-campaign-list">'+resellerCampaignHtml()+'</div></section>'+
      '<section class="am-biz-section" id="am-r-listings"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">CATALOG MANAGEMENT</span><h3>My product listings</h3><p>Manage your own products through Online Shah Alami’s existing listing workflow.</p></div><button class="btn" type="button" onclick="AMarketBusinessUI.openResellerProductEditor()">+ Add my product</button></div>'+mine+'</section>'+
      '<section class="am-biz-section" id="am-r-earnings"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">FINANCE WORKSPACE</span><h3>Earnings, orders &amp; payouts</h3><p>Use the connected Online Shah Alami account dashboard for actual orders, order-level commission, eligible balance, payout requests and downloadable statements.</p></div></div><div class="am-biz-finance-grid"><div class="am-biz-panel"><span class="am-biz-bigicon">📈</span><h4>Sales &amp; commissions</h4><p>Review delivered versus pending orders, commission records and your product listing performance in your account dashboard.</p><button class="btn" type="button" onclick="AMarketBusinessUI.openResellerAccount()">Open live earnings</button></div><div class="am-biz-panel"><span class="am-biz-bigicon">💳</span><h4>Payout centre</h4><p>Submit supported payout requests and review the rules configured by the store administrator. A request is not a confirmed transfer.</p><button class="btn ghost" type="button" onclick="AMarketBusinessUI.openResellerAccount()">Manage payout request</button></div><div class="am-biz-panel"><span class="am-biz-bigicon">⬇️</span><h4>Statement export</h4><p>Export the statement generated by your current Online Shah Alami reseller dashboard.</p><button class="btn ghost" type="button" onclick="AMarketBusinessUI.exportReseller()">Download statement</button></div></div></section>'+
      '<section class="am-biz-section" id="am-r-growth"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">SELLER LEARNING</span><h3>Growth centre &amp; support</h3><p>Operational checklists commonly found in marketplace seller tools.</p></div></div><div class="am-biz-resource-grid"><a href="#/help-center" class="am-biz-resource"><span>📘</span><b>Seller basics</b><small>Product accuracy, honest descriptions, customer messaging and service.</small></a><a href="#/policies/returns" class="am-biz-resource"><span>↩️</span><b>Returns &amp; disputes</b><small>Understand the published store policies before promising customers an outcome.</small></a><a href="#/contact" class="am-biz-resource"><span>💬</span><b>Contact Online Shah Alami</b><small>Ask about access, product availability, commissions or payout status.</small></a><a href="#/wholesale-center" class="am-biz-resource"><span>🏭</span><b>Wholesale sourcing</b><small>Explore bulk buying if you need inventory for your own business.</small></a></div><p class="am-biz-disclaimer">Data accuracy note: catalog and approved listing information is read from Online Shah Alami where available. Campaigns and the business workspace profile are local drafts. Actual advertising, click attribution, external-channel orders and payment transfers need dedicated backend/API integration.</p></section>';
    return frame('reseller-center','Reseller business centre','A richer social-selling and reseller workspace, integrated with your existing Online Shah Alami product, order and payout tools.',pageWrap(html));
  }
  function wholesaleCartSummary(){var cart=(window.S&&Array.isArray(S.cart))?S.cart:[],all=bizWholesaleProducts(),map={};all.forEach(function(p){map[p.id]=p;});var qty=0,total=0,saving=0,items=0;cart.forEach(function(c){if(c.size!=='Wholesale')return;var p=map[c.pid];if(!p)return;var n=Number(c.qty)||0;qty+=n;items++;total+=n*(Number(p.ws)||0);saving+=n*Math.max(0,(Number(API.minPrice(p))||0)-(Number(p.ws)||0));});return {qty:qty,total:total,saving:saving,items:items};}
  function savedWholesaleListsHtml(){var lists=bizRead('wholesale-lists',[]);if(!lists.length)return '<div class="am-biz-empty">No saved purchase lists yet. Select products in the catalog and save a list to make reordering faster.</div>';return '<div class="am-biz-saved-lists">'+lists.map(function(l,i){return '<article class="am-biz-saved-list"><div><span class="am-biz-tag">'+(l.items||[]).length+' products</span><h4>'+esc(l.name||'Purchase list')+'</h4><small>Saved '+new Date(l.createdMs||Date.now()).toLocaleDateString()+'</small></div><div class="am-biz-campaign-actions"><button class="btn sm" type="button" onclick="AMarketBusinessUI.loadWholesaleList('+i+')">Load quantities</button><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.deleteWholesaleList('+i+')">Delete</button></div></article>';}).join('')+'</div>';}
  function quoteHistoryHtml(){var q=bizRead('wholesale-quotes',[]);if(!q.length)return '<div class="am-biz-empty">No quote drafts have been submitted from this browser yet. Successful requests sent to the store are also sent through the configured Online Shah Alami message workflow.</div>';return '<div class="am-biz-table-wrap"><table class="am-biz-table"><thead><tr><th>Request</th><th>Quantity</th><th>City</th><th>Requested</th><th>Local status</th></tr></thead><tbody>'+q.slice().reverse().slice(0,10).map(function(x){return '<tr><td><b>'+esc(x.item||'Quote')+'</b><small>'+esc(x.company||'Business buyer')+'</small></td><td>'+esc(x.qty||'—')+'</td><td>'+esc(x.city||'—')+'</td><td>'+new Date(x.createdMs||Date.now()).toLocaleDateString()+'</td><td><span class="am-biz-tag">'+esc(x.displayStatus||'Request sent')+'</span></td></tr>';}).join('')+'</tbody></table><p class="am-biz-form-note">This history is a browser-side convenience record; check with Online Shah Alami for the authoritative quote status.</p></div>';}
  function wholesaleCenterPage(){
    var p=API.profile()||{},approved=bizApproved('wholesale'),all=bizWholesaleProducts(),cats=bizCategories(all),co=bizProfiles(),sum=wholesaleCartSummary(),allProds=bizActiveProducts(),sellerNames=[];
    allProds.forEach(function(x){var s=String(x.sellerName||x.storeName||x.brand||'').trim();if(s&&sellerNames.indexOf(s)<0)sellerNames.push(s);});
    var cards=all.length?all.map(function(x){return bizProductCard(x,'wholesale');}).join(''):'<div class="am-biz-empty">No products with wholesale prices are listed yet. You can still request a custom quote for product sourcing or a larger quantity.</div>';
    var html=bizPortalHero('wholesale','Wholesale purchasing workspace','Source bulk-priced products, build repeat purchase lists, request custom quotes and manage your company buying preferences.','<button class="btn" type="button" onclick="AMarketBusinessUI.scrollTo(\'am-w-catalog\')">Browse bulk catalog</button><button class="btn ghost" type="button" onclick="AMarketBusinessUI.openWholesaleAccount()">Orders &amp; invoices</button>')+
      bizGate('wholesale')+
      '<div class="am-biz-metric-grid">'+bizMetric('🏷️',String(all.length),'Bulk-priced products','Current catalog with a wholesale price')+bizMetric('📦',String(sum.qty),'Units in wholesale cart','Current cart quantity')+bizMetric('💰',money(sum.saving),'Potential cart savings','Estimate versus current retail prices')+bizMetric('🏢',co.companyName?esc(co.companyName):'Not set','Business profile','Saved locally in this browser')+'</div>'+
      bizSectionNav([['am-w-overview','◈ Overview'],['am-w-catalog','🛒 Bulk catalog'],['am-w-quickorder','⚡ Quick order'],['am-w-quotes','🧾 Quote requests'],['am-w-lists','🔁 Purchase lists'],['am-w-company','🏢 Company profile'],['am-w-orders','🚚 Orders & payments']])+
      '<section class="am-biz-section" id="am-w-overview"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">BUYER WORKSPACE</span><h3>Procurement overview</h3><p>Common tools for purchasing teams, retailers and small businesses.</p></div><span class="am-biz-live-tag"><i></i> '+(approved?'Approved business':'Preview mode')+'</span></div><div class="am-biz-task-grid"><button class="am-biz-task" type="button" onclick="AMarketBusinessUI.scrollTo(\'am-w-catalog\')"><span>🔎</span><b>Find bulk products</b><small>Search wholesale prices and minimum quantities.</small></button><button class="am-biz-task" type="button" onclick="AMarketBusinessUI.scrollTo(\'am-w-quickorder\')"><span>⚡</span><b>Bulk quick order</b><small>Paste product names and quantities to prepare a list.</small></button><button class="am-biz-task" type="button" onclick="AMarketBusinessUI.scrollTo(\'am-w-quotes\')"><span>🧾</span><b>Request a quote</b><small>Discuss quantities, lead times and target price with the team.</small></button><button class="am-biz-task" type="button" onclick="AMarketBusinessUI.openWholesaleAccount()"><span>📦</span><b>Orders &amp; invoices</b><small>Open connected wholesale order history and tracking.</small></button></div><div class="am-biz-note"><b>Wholesale access and commercial terms</b><p>Product-specific price and minimum quantity come from the Online Shah Alami catalog. Payment terms, credit limits, negotiated rates, delivery dates and supplier allocation are only confirmed after store review; this portal does not grant credit automatically.</p></div></section>'+
      '<section class="am-biz-section" id="am-w-catalog"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">SOURCING CATALOG</span><h3>Wholesale product catalog</h3><p>Search, filter, compare current retail/wholesale prices and prepare a bulk basket.</p></div><div class="am-biz-heading-actions"><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.exportWholesale()">Export price list</button><button class="btn sm" type="button" onclick="AMarketBusinessUI.addSelectedWholesale()">Add selected to cart</button></div></div><div class="am-biz-filterbar"><input id="am-ws-search" class="inp" type="search" placeholder="Search products, supplier or category…" oninput="AMarketBusinessUI.filterWholesale(this.value)"/><select id="am-ws-cat" class="inp" onchange="AMarketBusinessUI.filterWholesale()"><option value="">All categories</option>'+bizSelectOptions(cats,'')+'</select><select class="inp" id="am-ws-sort" onchange="AMarketBusinessUI.sortWholesale(this.value)"><option value="recommended">Recommended</option><option value="low">Lowest bulk price</option><option value="saving">Highest retail saving</option><option value="name">Product name</option></select></div><div id="am-ws-catalog" class="am-biz-product-grid">'+cards+'</div><div class="am-biz-cartbar" id="am-ws-cart-summary"><div><b>Wholesale basket</b><span>'+sum.qty+' units · '+money(sum.total)+'</span><small>Estimated savings: '+money(sum.saving)+'</small></div><div class="am-biz-heading-actions"><button type="button" class="btn ghost sm" onclick="AMarketBusinessUI.saveWholesaleList()">Save selected list</button><a class="btn sm" href="#/cart">Review cart &amp; checkout</a></div></div></section>'+
      '<section class="am-biz-section" id="am-w-quickorder"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">BULK ORDERING</span><h3>Quick order &amp; import list</h3><p>Paste one item per line as <code>product name, quantity</code>. Match is checked against products that have a wholesale price.</p></div></div><div class="am-biz-two-col"><form class="am-biz-form" onsubmit="AMarketBusinessUI.bulkPaste(event)"><div class="fld"><label>Product / quantity list</label><textarea name="bulkLines" rows="7" required placeholder="Classic Cotton T-Shirt, 50&#10;Wireless Earbuds, 20"></textarea></div><button class="btn" type="submit">Add matched lines to basket</button><p class="am-biz-form-note">Unmatched lines are reported; quantities below a product&#39;s minimum are raised to the listed minimum.</p><div id="am-ws-import-result" aria-live="polite"></div></form><div class="am-biz-panel"><h4>Order preparation</h4><div class="am-biz-check-row"><span>1</span><div><b>Confirm variants and quantities</b><small>Product options and availability are checked in the standard store flow.</small></div></div><div class="am-biz-check-row"><span>2</span><div><b>Review delivery and total</b><small>Delivery costs and actual payable amounts are confirmed at checkout.</small></div></div><div class="am-biz-check-row"><span>3</span><div><b>Submit the order through checkout</b><small>Only an order-confirmation result establishes that the order was placed.</small></div></div><a class="btn ghost" href="#/cart" style="margin-top:15px">Open wholesale basket</a></div></div></section>'+
      '<section class="am-biz-section" id="am-w-quotes"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">REQUEST FOR QUOTATION</span><h3>Custom quote &amp; sourcing requests</h3><p>Ask for a larger volume, a negotiated offer, a new product or clarification about lead time.</p></div></div><div class="am-biz-two-col"><form class="am-biz-form" onsubmit="AMarketBusinessUI.submitWholesaleQuote(event)"><div class="g2"><div class="fld"><label>Product / specification</label><input name="item" required placeholder="Product name or requirements" maxlength="180"/></div><div class="fld"><label>Quantity required</label><input name="qty" type="number" min="1" required placeholder="e.g. 250"/></div></div><div class="g2"><div class="fld"><label>Business name</label><input name="company" value="'+esc(co.companyName||'')+'" placeholder="Registered or trading name" maxlength="120"/></div><div class="fld"><label>Delivery city</label><input name="city" value="'+esc(co.city||'')+'" placeholder="e.g. Lahore" maxlength="100"/></div></div><div class="g2"><div class="fld"><label>Target unit price (optional, PKR)</label><input name="targetPrice" type="number" min="0" placeholder="Your target budget"/></div><div class="fld"><label>Preferred delivery date</label><input name="targetDate" type="date"/></div></div><div class="g2"><div class="fld"><label>Payment preference</label><select name="terms"><option>Use available checkout methods</option><option>Request bank transfer / advance payment</option><option>Request Cash on Delivery (if eligible)</option><option>Request Net 7 terms (review required)</option><option>Request Net 15 terms (review required)</option><option>Request Net 30 terms (review required)</option></select></div><div class="fld"><label>Preferred supplier / brand (optional)</label><input name="supplier" placeholder="Supplier, seller or brand" maxlength="120"/></div></div><div class="fld"><label>Specifications and notes</label><textarea name="note" rows="3" placeholder="Variants, packaging, delivery location, required documents, or other details"></textarea></div><button class="btn" type="submit">Submit quote request</button><small class="am-biz-form-note">The request uses Online Shah Alami&#39;s configured message workflow when Firebase is connected. Final prices, credit terms and availability require confirmation.</small></form><div class="am-biz-panel"><h4>How quote requests work</h4><div class="am-biz-check-row"><span>1</span><div><b>Send specification</b><small>Give the quantity, target price and delivery information if known.</small></div></div><div class="am-biz-check-row"><span>2</span><div><b>Store team reviews</b><small>Availability and the offer must be confirmed by Online Shah Alami.</small></div></div><div class="am-biz-check-row"><span>3</span><div><b>Place approved order</b><small>Use the store&#39;s approved checkout or payment instructions.</small></div></div><button class="btn ghost" type="button" onclick="AMarketBusinessUI.prefillTerms(&quot;Request Net 30 terms (review required)&quot;)">Ask about Net 30 terms</button></div></div><div class="am-biz-section-heading" style="margin-top:24px"><div><h4>Recent quote requests</h4><p>Browser-side history, not the authoritative status record.</p></div></div><div id="am-ws-quote-history">'+quoteHistoryHtml()+'</div></section>'+
      '<section class="am-biz-section" id="am-w-lists"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">REPEAT PURCHASING</span><h3>Saved purchase lists</h3><p>Save commonly ordered products and load the quantities next time. Lists are local to this browser.</p></div><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.saveWholesaleList()">+ Save selected products</button></div><div id="am-ws-saved-lists">'+savedWholesaleListsHtml()+'</div></section>'+
      '<section class="am-biz-section" id="am-w-company"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">COMPANY ACCOUNT</span><h3>Business profile &amp; delivery preferences</h3><p>Keep purchasing details ready for quote requests. This form is saved locally until a secure backend profile flow is connected.</p></div></div><form class="am-biz-form" onsubmit="AMarketBusinessUI.saveCompany(event)"><div class="g2"><div class="fld"><label>Business / store name</label><input name="companyName" value="'+esc(co.companyName||'')+'" required maxlength="120"/></div><div class="fld"><label>Buyer type</label><select name="buyerType">'+bizSelectOptions(['Retail shop','Online reseller','Distributor','Corporate buyer','Institution / organization','Other'],co.buyerType||'Retail shop')+'</select></div></div><div class="g2"><div class="fld"><label>Contact person</label><input name="contactName" value="'+esc(co.contactName||p.name||'')+'" maxlength="120"/></div><div class="fld"><label>Business phone</label><input name="phone" value="'+esc(co.phone||p.phone||'')+'" maxlength="50"/></div></div><div class="g2"><div class="fld"><label>Delivery city</label><input name="city" value="'+esc(co.city||'')+'" required maxlength="100"/></div><div class="fld"><label>Preferred payment method</label><select name="paymentPreference">'+bizSelectOptions(['Use available checkout methods','Bank transfer / advance payment','Cash on Delivery (if eligible)','Request credit terms (approval required)'],co.paymentPreference||'Use available checkout methods')+'</select></div></div><div class="fld"><label>Default delivery address</label><textarea name="address" rows="3" placeholder="Street, area, city and postal code">'+esc(co.address||'')+'</textarea></div><div class="fld"><label>Purchase order reference (optional)</label><input name="poPrefix" value="'+esc(co.poPrefix||'')+'" placeholder="e.g. AM-BUY-2026" maxlength="60"/></div><button class="btn" type="submit">Save local business profile</button><span id="am-ws-company-result" class="am-biz-form-note" aria-live="polite"></span></form><div class="am-biz-note"><b>Security reminder</b><p>Do not store CNIC images, bank passwords, card numbers or other sensitive documents in this local profile. Identity and business verification should be implemented through a secure authenticated backend.</p></div></section>'+
      '<section class="am-biz-section" id="am-w-orders"><div class="am-biz-section-heading"><div><span class="am-biz-eyebrow">ORDER MANAGEMENT</span><h3>Orders, invoices &amp; payment terms</h3><p>Open the connected Online Shah Alami wholesale account for actual order history, tracking and reorder tools.</p></div></div><div class="am-biz-finance-grid"><div class="am-biz-panel"><span class="am-biz-bigicon">📦</span><h4>Orders &amp; delivery tracking</h4><p>Review past wholesale orders and use the existing order tracking workflow.</p><button class="btn" type="button" onclick="AMarketBusinessUI.openWholesaleAccount()">Open my orders</button></div><div class="am-biz-panel"><span class="am-biz-bigicon">📄</span><h4>Wholesale price list</h4><p>Export available product wholesale prices and minimum quantities.</p><button class="btn ghost" type="button" onclick="AMarketBusinessUI.exportWholesale()">Export price list</button></div><div class="am-biz-panel"><span class="am-biz-bigicon">🧾</span><h4>Payment terms</h4><p>Available checkout methods depend on store configuration. Net payment terms are a request only until approved by the store.</p><button class="btn ghost" type="button" onclick="AMarketBusinessUI.prefillTerms(&quot;Request Net 15 terms (review required)&quot;)">Request review</button></div></div><div class="am-biz-note"><b>What this portal does not assume</b><p>It does not invent stock availability, confirmed delivery dates, invoices, tax exemptions, credit limits or payment settlements. Those must come from the connected store database and operational integrations.</p></div></section>';
    return frame('wholesale-center','Wholesale business centre','A B2B buying workspace for bulk sourcing, repeat orders, quote requests and company preferences.',pageWrap(html));
  }

  function sellerPage(){
    var u=API.currentUser(),p=API.profile(),logged=!!(u&&!u.isAnonymous),reseller=p.type==='reseller',wholesale=!!p.wholesale,req=p.requestedType;
    var status=!logged?'Sign in or create an Online Shah Alami account to request protected business access.':(reseller&&wholesale?'Your account has reseller and wholesale access.':(reseller?'Your reseller access is approved.':(wholesale?'Your wholesale access is approved.':(req==='reseller'?'Your reseller request is waiting for review.':(req==='business'?'Your wholesale request is waiting for review.':'Choose the seller or business path that fits you.')))));
    var rc=reseller?btn('#/reseller-center','Open reseller portal',''):'<button type="button" class="btn" onclick="AMarketUI.startAccess(\'reseller\')">Request reseller access</button>';
    var wc=wholesale?btn('#/wholesale-center','Open wholesale portal',''):'<button type="button" class="btn" onclick="AMarketUI.startAccess(\'business\')">Request wholesale access</button>';
    return frame('seller-center','Sell, resell & buy wholesale','Separate business workspaces for social sellers, product owners, retailers and bulk buyers.',pageWrap('<div class="am-biz-access '+((reseller||wholesale)?'am-biz-approved':'')+'"><span class="am-biz-access-icon">'+((reseller||wholesale)?'✓':'🔐')+'</span><div><b>Business account status</b><small>'+esc(status)+'</small></div></div><div class="am-biz-split-hero"><article class="am-biz-path-card am-biz-path-reseller"><span class="am-biz-path-icon">🤝</span><span class="am-biz-eyebrow">RESELLER & SOCIAL SELLING</span><h2>Sell and grow your audience</h2><p>Explore the catalog, calculate margins, prepare social campaigns, manage your own listings, review commissions and open payout tools.</p><div class="am-biz-path-points"><span>✓ Product discovery &amp; sharing</span><span>✓ Margin estimator &amp; campaign drafts</span><span>✓ Listing management &amp; statements</span></div>'+rc+' <a class="am-biz-text-link" href="#/reseller-center">View portal details →</a></article><article class="am-biz-path-card am-biz-path-wholesale"><span class="am-biz-path-icon">🏭</span><span class="am-biz-eyebrow">WHOLESALE & PROCUREMENT</span><h2>Buy in larger quantities</h2><p>Compare bulk prices and minimums, build purchase lists, submit quote requests, maintain business preferences, and track approved orders.</p><div class="am-biz-path-points"><span>✓ Bulk catalog &amp; quick order</span><span>✓ Request-for-quote workflow</span><span>✓ Company profile &amp; reorder lists</span></div>'+wc+' <a class="am-biz-text-link" href="#/wholesale-center">View portal details →</a></article></div><div class="am-biz-section"><div class="am-biz-section-heading"><div><h3>How access works</h3><p>Online Shah Alami keeps business-only actions behind administrator approval.</p></div></div><div class="am-market-steps"><div class="am-market-step"><span>1</span><h3>Create an account</h3><p>Use an email and phone number that the team can contact about orders and support.</p></div><div class="am-market-step"><span>2</span><h3>Submit a request</h3><p>Choose reseller access or wholesale business access. You can request both.</p></div><div class="am-market-step"><span>3</span><h3>Start after approval</h3><p>Protected actions are enabled after review. Admin approvals are managed from the customer and reseller settings areas.</p></div></div><div class="am-biz-note"><b>Built around real marketplace workflows</b><p>The portal adds the workspace and tools; real settlements, ads, delivery integrations, invoice generation and credit terms still depend on connected backend services and administrator configuration.</p><div class="row" style="margin-top:12px;gap:8px"><a class="btn ghost sm" href="#/help-center">Business help centre</a><a class="btn ghost sm" href="#/contact">Contact the team</a></div></div></div>'));
  }
  function wholesalePage(){
    var ps=bizWholesaleProducts(),cards=ps.map(function(p){return API.card(p)}).join(''),p=API.profile(),u=API.currentUser(),ok=!!(u&&!u.isAnonymous&&p.wholesale);
    return frame('wholesale','Wholesale buying','Explore bulk-priced products and use the dedicated Online Shah Alami business workspace.',pageWrap('<div class="card"><div class="am-market-statrow"><span>🏭 Bulk pricing</span><span>📦 Minimum quantities</span><span>🔁 Repeat order tools</span><span>🧾 Custom quotes</span></div><h2 style="color:var(--ink);margin-bottom:8px">A better way to purchase for your business</h2><p class="am-market-muted">'+(ok?'Your business account has wholesale access. The dedicated portal includes bulk catalog filters, quick order import, saved purchase lists, quote requests and company preferences.':'Wholesale prices and bulk checkout require approval. You can preview the buying workflow and request business access.')+'</p><div class="row" style="margin-top:16px;gap:10px"><a class="btn" href="#/wholesale-center">'+(ok?'Open wholesale business portal':'Preview wholesale portal')+'</a>'+(ok?btn('#/account','Open account orders','ghost'):'<button class="btn ghost" type="button" onclick="AMarketUI.startAccess(\'business\')">Request business access</button>')+btn('#/seller-center','Seller & reseller centre','ghost')+'</div></div><div class="am-biz-section-heading" style="margin-top:28px"><div><h2>Products with bulk pricing</h2><p class="am-market-muted">Current wholesale prices and minimum quantities are set per product in the Online Shah Alami catalog.</p></div><a class="am-market-link" href="#/wholesale-center">Open full sourcing tools →</a></div>'+(cards?'<div class="grid">'+cards+'</div>':'<div class="am-market-empty">No products with wholesale prices have been published yet. Request a custom quote from the wholesale portal.</div>')+'<div class="am-biz-note" style="margin-top:22px"><b>Business buyer features</b><p>Use the full portal to prepare purchase lists, request a quote, record preferred delivery details locally and open actual orders through your approved account. Payment terms and credit are never activated without store approval.</p></div>'));
  }
  function helpPage(){
    var sh=config().shop||{};
    return frame('help-center','Help centre','Find answers, order tracking and customer support.',pageWrap('<div class="am-market-grid"><a class="am-market-store" href="#/faq"><div class="am-market-store-icon">❓</div><h3>FAQs</h3><p class="am-market-muted">Answers about ordering, delivery, returns and payments.</p><span class="am-market-link">Read FAQs →</span></a><a class="am-market-store" href="#/account"><div class="am-market-store-icon">📦</div><h3>Orders &amp; tracking</h3><p class="am-market-muted">View order history, track an order and reorder available items.</p><span class="am-market-link">Open account →</span></a><a class="am-market-store" href="#/policies/returns"><div class="am-market-store-icon">🔄</div><h3>Returns &amp; refunds</h3><p class="am-market-muted">Read the policy and submit an eligible request from your orders.</p><span class="am-market-link">Read policy →</span></a><a class="am-market-store" href="#/contact"><div class="am-market-store-icon">✉️</div><h3>Contact support</h3><p class="am-market-muted">Send the Online Shah Alami team a message about an order or product.</p><span class="am-market-link">Contact us →</span></a></div><div class="card" style="margin-top:20px"><h3 style="color:var(--ink);margin-bottom:8px">Talk to the team</h3><p class="am-market-muted">Support: '+esc(sh.phone||'')+' · '+esc(sh.email||'')+'</p><div class="row" style="margin-top:12px"><a class="btn" href="https://wa.me/'+esc(sh.whatsapp||'')+'" target="_blank" rel="noopener">WhatsApp support</a><a class="btn ghost" href="tel:'+esc(sh.phone||'')+'">Call us</a></div></div>'));
  }
  function renderRoute(){
    addShortcutNav();
    var p=liveRoute(),r=p[0]||'home';
    if(CUSTOM.indexOf(r)>=0){
      var v=document.getElementById('view'); if(!v)return;
      var route=r; if(r==='store'){try{route+=':'+decodeURIComponent(p[1]||'')}catch(e){route+=':'+(p[1]||'')}}
      if(rootExists(route))return;
      var html=r==='deals'?dealsPage():r==='stores'?storesPage():r==='store'?storePage(p[1]||''):r==='vouchers'?vouchersPage():r==='seller-center'?sellerPage():r==='wholesale'?wholesalePage():r==='reseller-center'?resellerCenterPage():r==='wholesale-center'?wholesaleCenterPage():helpPage();
      v.innerHTML=html;
      window.scrollTo(0,0);
      return;
    }
    var root=document.getElementById('am-mkt-custom-root');if(root)root.remove();
    if(r==='home'||!r)homeModules();
    accountTools();
    var active=r==='store'?'stores':r;
    document.querySelectorAll('.am-market-quicknav a').forEach(function(a){var href=(a.getAttribute('href')||'').replace(/^#\//,'');a.classList.toggle('active',href===active||(active==='stores'&&href.indexOf('stores')===0))});
    consumeRegistrationType();
  }
  function accountTools(){
    if(location.hash.indexOf('#/account')!==0)return;
    var acc=document.getElementById('acc');if(!acc||document.getElementById('am-account-market-tools'))return;
    acc.insertAdjacentHTML('beforeend','<div class="card" id="am-account-market-tools"><h3 style="color:var(--ink)">Marketplace quick tools</h3><p class="am-market-muted" style="margin-top:5px">Shortcuts for everyday shopping and account support.</p><div class="am-market-toolgrid"><a href="#/account" onclick="AnasMartExtension.accountTab(\'orders\');return false">📦 My orders</a><a href="#/wishlist">♡ Wishlist</a><a href="#/cart">🛒 Shopping cart</a><a href="#/vouchers">🎟️ Vouchers</a><a href="#/wholesale-center">🏭 Wholesale portal</a><a href="#/reseller-center">🤝 Reseller portal</a><a href="#/help-center">💬 Help centre</a><a href="#/policies/privacy">🔒 Privacy &amp; security</a></div></div>');
  }
  function consumeRegistrationType(){
    if(location.hash.indexOf('#/login')!==0)return;
    var sel=document.querySelector('select[name="atype"]');if(!sel)return;
    try{var t=localStorage.getItem('am_selected_account_type');if(t){sel.value=t;localStorage.removeItem('am_selected_account_type')}}catch(e){}
  }
  window.AMarketUI={
    filterStores:function(q){q=String(q||'').toLowerCase();document.querySelectorAll('[data-am-store-card]').forEach(function(n){n.style.display=(n.getAttribute('data-store-search')||'').indexOf(q)>-1?'':'none'})},
    copyVoucher:function(code){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(String(code)).then(function(){var t=document.getElementById('toast');if(t){t.textContent='Voucher copied: '+code;t.className='show';setTimeout(function(){t.className=''},2500)}},function(){window.prompt('Copy this voucher code',code)});else window.prompt('Copy this voucher code',code)},
    startAccess:function(type){API.startAccess(type)}
  };
  var pending=false;
  function schedule(){if(pending)return;pending=true;setTimeout(function(){pending=false;try{renderRoute()}catch(e){console.warn('Online Shah Alami marketplace page:',e)}},35)}
  window.addEventListener('hashchange',schedule);
  document.addEventListener('DOMContentLoaded',schedule);
  var target=document.getElementById('view');if(target&&window.MutationObserver)new MutationObserver(schedule).observe(target,{childList:true,subtree:true});
  schedule();setTimeout(schedule,350);setTimeout(schedule,1100);
})();


/* ===== Extracted inline script 6 ===== */

/* AM_PRO_PORTALS_V1: professional admin/customer portal layout and tasteful 3D micro-interactions. */
(function(){
  'use strict';
  var API=window.AnasMartExtension||{};
  var debounce=0, reduced=!!(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function rolePills(){var p=API.profile?API.profile():{};var roles=['Customer'];if(p.type==='reseller')roles.push('Reseller');if(p.wholesale)roles.push('Wholesale');return roles.map(function(r){return '<span>'+esc(r)+'</span>';}).join('');}
  function activeAdminTitle(){var a=document.getElementById('atabs'),btn=a&&a.querySelector('button.on');return btn?(btn.textContent||'Admin workspace').trim():'Admin workspace';}
  function adminShortcuts(){
    var items=[
      ['📦','Orders','Review and update orders','orders'],['🛍️','Products','Edit catalog and stock','products'],['👥','Customers','Manage customer access','customers'],['📈','Revenue','Review sales performance','revenue'],
      ['💸','Payouts','Review reseller requests','payouts'],['🤝','Reseller rules','Commission and profit settings','resellerSettings'],['🏭','Business approvals','Approve wholesale access','customers'],['↩️','Returns','Handle return requests','returns'],['❓','Product Q&A','Answer product questions','productQA'],['⚙️','Store settings','Configure banners and delivery','site']
    ];
    return '<div class="am-pro-shortcuts">'+items.map(function(i){return '<button type="button" class="am-pro-shortcut" onclick="PH.tab(\''+i[3]+'\')"><span class="am-pro-icon">'+i[0]+'</span><span><b>'+i[1]+'</b><small>'+i[2]+'</small></span></button>';}).join('')+'</div>';
  }
  function adminIntro(adm){
    if(!adm||adm.querySelector('.am-pro-admin-intro'))return;
    var title=activeAdminTitle();
    var shortname=title==='Dashboard'?'Store performance, order flow and daily operations.':'Manage '+title.toLowerCase()+' with a focused Online Shah Alami workspace.';
    var intro=document.createElement('div');intro.className='am-pro-admin-intro';intro.innerHTML='<div><span class="am-pro-eyebrow">Online Shah Alami · ADMIN WORKSPACE</span><h2>'+esc(title==='Dashboard'?'Welcome to your control centre':title+' workspace')+'</h2><p>'+esc(shortname)+'</p></div><div class="am-pro-admin-status"><span class="am-pro-status-pill"><i></i> Admin session</span><span class="am-pro-status-pill">⌘ Store operations</span></div>';
    var tools=document.createElement('div');tools.className='am-pro-admin-tools';tools.innerHTML='<label class="am-pro-admin-search"><span>⌕</span><input type="search" aria-label="Search current admin section" placeholder="Search this section…" oninput="AMProUI.filterAdmin(this.value)"></label><span class="am-pro-admin-help">Tip: use the workspace menu to switch tools.</span>';
    adm.insertBefore(tools,adm.firstChild);adm.insertBefore(intro,adm.firstChild);
    if(title==='Dashboard'){
      var anchor=adm.querySelector('.stat-grid');
      var grid=document.createElement('div');grid.innerHTML=adminShortcuts();var shortcuts=grid.firstElementChild;
      if(anchor)adm.insertBefore(shortcuts,anchor);else adm.insertBefore(shortcuts,tools.nextSibling);
    }
    adm.querySelectorAll('.stat,.card,.am-pro-shortcut').forEach(function(el){el.setAttribute('data-am-pro-tilt','');});
  }
  function customerPortal(view){
    var tabs=document.getElementById('atabs2');if(!tabs||document.getElementById('am-pro-customer-welcome'))return;
    var u=API.currentUser?API.currentUser():null,p=API.profile?API.profile():{};
    var name=(p&&p.name)||(u&&u.displayName)||(u&&u.email?u.email.split('@')[0]:'there');
    var welcome=document.createElement('section');welcome.className='am-pro-customer-welcome';welcome.id='am-pro-customer-welcome';
    welcome.innerHTML='<div><span class="am-pro-eyebrow">YOUR Online Shah Alami ACCOUNT</span><h2>Welcome back, '+esc(name)+' 👋</h2><p>Your personal shopping space for orders, delivery updates, saved products, account details and seller tools.</p><div class="am-pro-role-pills">'+rolePills()+'</div></div><div class="am-pro-account-art" aria-hidden="true"><div class="am-pro-orbit"></div><div class="am-pro-cube"><i>🛍️</i><i>✦</i><i>📦</i><i>★</i><i>AM</i><i>✓</i></div></div>';
    var tiles=document.createElement('div');tiles.className='am-pro-customer-tiles';tiles.innerHTML=[
      ['📦','My orders','History & status','#/account','orders'],['📍','Track delivery','Follow an order','#/account','track'],['♡','Wishlist','Saved products','#/wishlist',''],['🎟️','Vouchers','Offers & codes','#/vouchers',''],['🛒','Shopping cart','Finish your order','#/cart',''],['🤝','Reseller portal','Sell & earn','#/reseller-center',''],['🏭','Wholesale portal','Bulk buying','#/wholesale-center',''],['💬','Help centre','Support & policies','#/help-center','']
    ].map(function(i){var act=i[4]? ' onclick="AnasMartExtension.accountTab(\''+i[4]+'\');return false"':'';return '<a class="am-pro-customer-tile" href="'+i[3]+'"'+act+'><span class="am-pro-icon">'+i[0]+'</span><span><b>'+i[1]+'</b><small>'+i[2]+'</small></span></a>';}).join('');
    tabs.parentNode.insertBefore(welcome,tabs);tabs.parentNode.insertBefore(tiles,tabs);
    view.querySelectorAll('#acc .stat,#acc .card').forEach(function(el){el.setAttribute('data-am-pro-tilt','');});
  }
  function filterAdmin(q){
    q=String(q||'').toLowerCase().trim();var root=document.getElementById('adm');if(!root)return;
    root.querySelectorAll('.tw tr').forEach(function(row){if(row.querySelector('th')){row.style.display='';return;}row.style.display=!q||row.textContent.toLowerCase().indexOf(q)>-1?'':'none';});
    root.querySelectorAll('.am-request-card').forEach(function(card){card.style.display=!q||card.textContent.toLowerCase().indexOf(q)>-1?'':'none';});
    root.querySelectorAll('[data-am-pro-filterable]').forEach(function(card){card.style.display=!q||card.textContent.toLowerCase().indexOf(q)>-1?'':'none';});
  }
  function attachTilt(root){
    if(reduced||!window.matchMedia||!window.matchMedia('(hover:hover) and (pointer:fine)').matches)return;
    (root||document).querySelectorAll('[data-am-pro-tilt]').forEach(function(el){if(el.getAttribute('data-am-pro-attached'))return;el.setAttribute('data-am-pro-attached','1');
      el.addEventListener('pointermove',function(e){if(e.pointerType==='touch')return;var r=el.getBoundingClientRect();if(!r.width||!r.height)return;var x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform='perspective(900px) rotateY('+(x*3.5).toFixed(2)+'deg) rotateX('+(-y*3.5).toFixed(2)+'deg) translateY(-2px)';});
      el.addEventListener('pointerleave',function(){el.style.transform='';});
    });
  }
  function upgrade(){
    document.body.classList.add('am-pro-site');
    var view=document.getElementById('view');if(!view)return;
    var hasAdmin=!!document.getElementById('atabs')&&!!document.getElementById('adm');
    var hasCustomer=location.hash.indexOf('#/account')===0&&!!document.getElementById('atabs2');
    document.body.classList.toggle('am-admin-route',hasAdmin);document.body.classList.toggle('am-customer-route',hasCustomer);
    if(hasAdmin){adminIntro(document.getElementById('adm'));attachTilt(document.getElementById('adm'));}
    if(hasCustomer){customerPortal(view);attachTilt(view);}
    attachTilt(view);
    view.querySelectorAll('.phead,main#view>section').forEach(function(el){if(!el.classList.contains('am-pro-enter')&&!el.closest('.am-market-overlay'))el.classList.add('am-pro-enter');});
  }
  window.AMProUI={filterAdmin:filterAdmin,refresh:upgrade};
  function schedule(){if(debounce)return;debounce=setTimeout(function(){debounce=0;try{upgrade();}catch(e){console.warn('Online Shah Alami portal enhancement:',e);}},40);}
  window.addEventListener('hashchange',schedule);document.addEventListener('DOMContentLoaded',schedule);
  var root=document.getElementById('view');if(root&&window.MutationObserver)new MutationObserver(schedule).observe(root,{childList:true,subtree:true});
  schedule();setTimeout(schedule,250);setTimeout(schedule,800);
})();


/* ===== Extracted inline script 7 ===== */

(function(){
  'use strict';
  var API=window.AnasMartExtension||{};
  function esc(v){return API.escape?API.escape(v==null?'':v):String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function currentUid(){var u=API.currentUser?API.currentUser():null;return u&&u.uid?String(u.uid):(u&&u.email?String(u.email):'guest');}
  function key(name){return 'am_biz_'+name+'_'+currentUid();}
  function read(name,fallback){try{var x=localStorage.getItem(key(name));return x?JSON.parse(x):fallback;}catch(e){return fallback;}}
  function write(name,value){try{localStorage.setItem(key(name),JSON.stringify(value));return true;}catch(e){return false;}}
  function allProducts(){return API.products?API.products().filter(function(p){return p&&p.active!==false;}):[];}
  function wsProducts(){return allProducts().filter(function(p){return Number(p.ws)>0;});}
  function money(n){return API.money?API.money(Number(n)||0):'PKR '+(Number(n)||0).toLocaleString();}
  function approved(type){var p=API.profile?API.profile():{};return type==='reseller'?p.type==='reseller':!!p.wholesale;}
  function showToast(msg){var t=document.getElementById('toast');if(t){t.textContent=msg;t.className='show';setTimeout(function(){t.className='';},2600);}else window.alert(msg);}
  function copy(text){if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(function(){showToast('Copied to clipboard');},function(){window.prompt('Copy this text',text);});}else window.prompt('Copy this text',text);}
  function domId(v){return String(v==null?'x':v).replace(/[^A-Za-z0-9_-]/g,'_');}
  function jsArg(v){return "'"+String(v==null?'':v).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/[\r\n]/g,'').replace(/</g,'\\x3c')+"'";}
  function filterCards(cardSelector,query,catSelector){var q=String(query||'').toLowerCase().trim(),catEl=catSelector?document.getElementById(catSelector):null,cat=catEl?catEl.value:'';document.querySelectorAll(cardSelector).forEach(function(n){var text=(n.getAttribute('data-search')||'').toLowerCase(),c=n.getAttribute('data-category')||'';n.style.display=(!q||text.indexOf(q)>-1)&&(!cat||cat===c)?'':'none';});}
  function scrollTo(id){var el=document.getElementById(id);if(el){el.scrollIntoView({behavior:window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});}return false;}
  function requestAccess(type){if(!API.startAccess){showToast('Account access flow is unavailable.');return;}API.startAccess(type==='business'?'business':'reseller');}
  function openResellerAccount(){if(API.accountTab)API.accountTab('reseller');else location.hash='#/account';}
  function openWholesaleAccount(){if(API.accountTab)API.accountTab('wholesale');else location.hash='#/account';}
  function openResellerProductEditor(){if(!approved('reseller')){requestAccess('reseller');return;}openResellerAccount();setTimeout(function(){if(window.PH&&PH.pform)PH.pform();},180);}
  function resellerShare(id,mode){if(!approved('reseller')){requestAccess('reseller');return;}if(!window.PH){showToast('Product sharing is currently unavailable.');return;}if(mode==='wa'&&PH.rwa)PH.rwa(id);else if(PH.rcopy)PH.rcopy(id);else {var base=location.href.split('#')[0]+'#/product/'+encodeURIComponent(id);copy(base);}}
  function resellerProfit(id,value){var p=allProducts().filter(function(x){return String(x.id)===String(id);})[0];var out=document.getElementById('am-rprofit-'+domId(id));if(!p||!out)return;var retail=Number(API.minPrice(p))||0,cost=Number(p.ws)>0?Number(p.ws):retail;if(value===''){out.textContent='Reference cost: '+money(cost)+' · Enter your price to estimate margin.';out.className='';return;}var v=Number(value),profit=v-cost;out.textContent='Reference cost: '+money(cost)+' · Estimated margin per unit: '+money(profit)+' ('+(v>0?Math.round(profit*100/v):0)+'% of your selling price).';out.className=profit<0?'am-biz-negative':'';}
  function campaigns(){return read('reseller-campaigns',[]);}
  function saveCampaign(e){e.preventDefault();var f=e.target,products=allProducts(),pid=f.productId.value,p=products.filter(function(x){return String(x.id)===String(pid);})[0];if(!p){showToast('Choose a product in the catalog first.');return;}var id='camp-'+Date.now(),link=location.href.split('#')[0]+'#/product/'+encodeURIComponent(p.id),name=f.campaignName.value.trim(),channel=f.channel.value,offer=f.offer.value.trim(),note=f.message.value.trim();var text=[name,offer||('Discover '+p.name),p.name+' — '+money(API.minPrice(p)),note,link].filter(Boolean).join('\n');var list=campaigns();list.push({id:id,name:name,productId:String(p.id),productName:p.name,channel:channel,offer:offer,message:note,text:text,link:link,createdMs:Date.now()});write('reseller-campaigns',list);var out=document.getElementById('am-r-campaign-output');if(out)out.innerHTML='<b>Prepared campaign copy</b><br/><span>'+esc(text).replace(/\n/g,'<br/>')+'</span><div class="am-biz-actions"><button type="button" class="btn sm" onclick="AMarketBusinessUI.copyCampaignText('+jsArg(id)+')">Copy message</button><button type="button" class="btn ghost sm" onclick="AMarketBusinessUI.campaignWhatsApp('+jsArg(id)+')">Open WhatsApp</button></div>';var box=document.getElementById('am-r-campaign-list');if(box)box.innerHTML=renderCampaigns(list);f.reset();showToast('Campaign draft saved on this device.');}
  function renderCampaigns(list){if(!list.length)return '<div class="am-biz-empty">No campaign drafts saved on this device yet. Create a campaign above to prepare product copy for your channels.</div>';return '<div class="am-biz-campaign-list">'+list.slice().reverse().map(function(c){return '<article class="am-biz-campaign"><div><span class="am-biz-tag">'+esc(c.channel||'Social')+'</span><h4>'+esc(c.name||'Campaign draft')+'</h4><p>'+esc(c.productName||'Product')+' · '+new Date(c.createdMs||Date.now()).toLocaleDateString()+'</p></div><div class="am-biz-campaign-actions"><button class="btn sm" type="button" onclick="AMarketBusinessUI.copyCampaignText('+jsArg(c.id)+')">Copy copy</button><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.campaignWhatsApp('+jsArg(c.id)+')">Open WhatsApp</button></div></article>';}).join('')+'</div>';}
  function findCampaign(id){return campaigns().filter(function(c){return String(c.id)===String(id);})[0];}
  function copyCampaignText(id){var c=findCampaign(id);if(c)copy(c.text||'');}
  function campaignWhatsApp(id){var c=findCampaign(id);if(c)window.open('https://wa.me/?text='+encodeURIComponent(c.text||''),'_blank','noopener');}
  function clearCampaigns(){if(!confirm('Clear saved campaign drafts for this account on this browser?'))return;write('reseller-campaigns',[]);var box=document.getElementById('am-r-campaign-list');if(box)box.innerHTML=renderCampaigns([]);var out=document.getElementById('am-r-campaign-output');if(out)out.textContent='Your generated campaign copy will appear here.';showToast('Campaign drafts cleared.');}
  function exportReseller(){if(!approved('reseller')){requestAccess('reseller');return;}if(window.PH&&PH.rexport)PH.rexport();else openResellerAccount();}
  function wholesaleAdd(id){if(!approved('wholesale')){requestAccess('business');return;}var inp=document.getElementById('wq_'+id),p=wsProducts().filter(function(x){return String(x.id)===String(id);})[0];if(!p){showToast('This product no longer has a wholesale price.');return;}var mn=Math.max(1,Number(p.wsMin)||10),n=inp?Math.floor(Number(inp.value)||mn):mn;if(n<mn){n=mn;if(inp)inp.value=String(mn);showToast('Minimum quantity for this item is '+mn+'.');}if(window.PH&&PH.wsAdd){if(inp)inp.value=String(n);PH.wsAdd(id);updateWholesaleSummary();}else showToast('Bulk cart is unavailable.');}
  function updateWholesaleSummary(){var cart=(window.S&&Array.isArray(S.cart))?S.cart:[],ps=wsProducts(),map={};ps.forEach(function(p){map[p.id]=p;});var qty=0,total=0,saving=0;cart.forEach(function(c){if(c.size!=='Wholesale'||!map[c.pid])return;var n=Number(c.qty)||0,p=map[c.pid];qty+=n;total+=n*(Number(p.ws)||0);saving+=n*Math.max(0,(Number(API.minPrice(p))||0)-(Number(p.ws)||0));});var bar=document.getElementById('am-ws-cart-summary');if(bar)bar.innerHTML='<div><b>Wholesale basket</b><span>'+qty+' units · '+money(total)+'</span><small>Estimated savings: '+money(saving)+'</small></div><div class="am-biz-heading-actions"><button type="button" class="btn ghost sm" onclick="AMarketBusinessUI.saveWholesaleList()">Save selected list</button><a class="btn sm" href="#/cart">Review cart &amp; checkout</a></div>';var stats=document.querySelectorAll('.am-biz-metric-grid .am-biz-metric');if(stats.length>=4){stats[1].querySelector('b').textContent=String(qty);stats[2].querySelector('b').textContent=money(saving);}}
  function filterWholesale(q){var inp=document.getElementById('am-ws-search');filterCards('[data-am-wholesale-card]',q==null?(inp?inp.value:''):q,'am-ws-cat');}
  function filterReseller(q){var inp=document.getElementById('am-reseller-search');filterCards('[data-am-reseller-card]',q==null?(inp?inp.value:''):q,'am-reseller-cat');}
  function addSelectedWholesale(){if(!approved('wholesale')){requestAccess('business');return;}var cards=[].slice.call(document.querySelectorAll('[data-am-wholesale-card]')),count=0;cards.forEach(function(card){var cb=card.querySelector('[data-am-ws-select]');if(cb&&cb.checked&&card.style.display!=='none'){var id=card.getAttribute('data-pid');if(id){wholesaleAdd(id);count++;}}});if(!count)showToast('Select one or more products first.');else showToast(count+' product line(s) added to the wholesale basket.');updateWholesaleSummary();}
  function sortWholesale(mode){var box=document.getElementById('am-ws-catalog');if(!box)return;var cards=[].slice.call(box.querySelectorAll('[data-am-wholesale-card]'));cards.sort(function(a,b){if(mode==='low')return (Number(a.getAttribute('data-price'))||0)-(Number(b.getAttribute('data-price'))||0);if(mode==='saving')return (Number(b.getAttribute('data-saving'))||0)-(Number(a.getAttribute('data-saving'))||0);if(mode==='name')return (a.querySelector('h3').textContent||'').localeCompare(b.querySelector('h3').textContent||'');return 0;});cards.forEach(function(c){box.appendChild(c);});}
  function bulkPaste(e){e.preventDefault();if(!approved('wholesale')){requestAccess('business');return;}var f=e.target,lines=String(f.bulkLines.value||'').split(/\r?\n/),all=wsProducts(),added=0,missing=[];lines.forEach(function(line){line=line.trim();if(!line)return;var m=line.match(/^(.*?)[\s,;:\t]+(\d+)\s*$/),name=(m?m[1]:line).trim().toLowerCase(),qty=m?Number(m[2]):0,p=all.filter(function(x){return String(x.name||'').toLowerCase()===name;})[0]||all.filter(function(x){return name&&String(x.name||'').toLowerCase().indexOf(name)>-1;})[0];if(!p){missing.push(line);return;}var inp=document.getElementById('wq_'+p.id);if(inp)inp.value=String(Math.max(Number(p.wsMin)||10,qty||Number(p.wsMin)||10));wholesaleAdd(p.id);added++;});var out=document.getElementById('am-ws-import-result');if(out)out.innerHTML='<div class="am-biz-output"><b>'+added+' matching product line(s) prepared.</b>'+(missing.length?'<br/>Not found: '+esc(missing.join(', ')):'')+'</div>';updateWholesaleSummary();if(added)showToast(added+' product line(s) added.');}
  function saveWholesaleList(){if(!approved('wholesale')){requestAccess('business');return;}var items=[];document.querySelectorAll('[data-am-wholesale-card]').forEach(function(card){var cb=card.querySelector('[data-am-ws-select]'),id=card.getAttribute('data-pid'),inp=card.querySelector('input[type=number]');if(cb&&cb.checked&&id){items.push({pid:id,qty:Math.max(1,Number(inp&&inp.value)||1)});}});if(!items.length){showToast('Tick “Select for list” on at least one product first.');return;}var name=window.prompt('Name this purchase list','Repeat purchase '+new Date().toLocaleDateString());if(!name)return;var lists=read('wholesale-lists',[]);lists.push({name:name.trim(),items:items,createdMs:Date.now()});write('wholesale-lists',lists);var box=document.getElementById('am-ws-saved-lists');if(box)box.innerHTML=renderSavedLists(lists);showToast('Purchase list saved in this browser.');}
  function renderSavedLists(lists){if(!lists.length)return '<div class="am-biz-empty">No saved purchase lists yet. Select products in the catalog and save a list to make reordering faster.</div>';return '<div class="am-biz-saved-lists">'+lists.map(function(l,i){return '<article class="am-biz-saved-list"><div><span class="am-biz-tag">'+(l.items||[]).length+' products</span><h4>'+esc(l.name||'Purchase list')+'</h4><small>Saved '+new Date(l.createdMs||Date.now()).toLocaleDateString()+'</small></div><div class="am-biz-campaign-actions"><button class="btn sm" type="button" onclick="AMarketBusinessUI.loadWholesaleList('+i+')">Load quantities</button><button class="btn ghost sm" type="button" onclick="AMarketBusinessUI.deleteWholesaleList('+i+')">Delete</button></div></article>';}).join('')+'</div>';}
  function loadWholesaleList(index){var lists=read('wholesale-lists',[]),l=lists[index];if(!l)return;var missing=[];(l.items||[]).forEach(function(it){var inp=document.getElementById('wq_'+it.pid),card=inp&&inp.closest('[data-am-wholesale-card]');if(inp&&card){inp.value=String(it.qty||1);var cb=card.querySelector('[data-am-ws-select]');if(cb)cb.checked=true;}else missing.push(it.pid);});scrollTo('am-w-catalog');showToast(missing.length?'Purchase list loaded, but some products are no longer listed.':'Purchase list quantities loaded. Review and add selected products to basket.');}
  function deleteWholesaleList(index){var lists=read('wholesale-lists',[]);lists.splice(index,1);write('wholesale-lists',lists);var box=document.getElementById('am-ws-saved-lists');if(box)box.innerHTML=renderSavedLists(lists);showToast('Saved list deleted.');}
  function submitWholesaleQuote(e){e.preventDefault();var f=e.target,item=f.item.value.trim(),qty=Number(f.qty.value)||0,co=f.company.value.trim(),city=f.city.value.trim(),target=f.targetPrice.value,dt=f.targetDate.value,terms=f.terms.value,supplier=f.supplier.value.trim(),userNote=f.note.value.trim();if(!item||qty<1){showToast('Enter the product specification and a quantity of at least one.');return;}var details=['Company: '+(co||'Not supplied'),'Delivery city: '+(city||'Not supplied'),'Target unit price: '+(target?money(target):'Not specified'),'Preferred date: '+(dt||'Not specified'),'Payment preference: '+terms,'Supplier/brand: '+(supplier||'No preference'),userNote].filter(Boolean).join(' | ');var reqs=read('wholesale-quotes',[]);reqs.push({item:item,qty:qty,company:co,city:city,targetPrice:target,targetDate:dt,terms:terms,supplier:supplier,note:userNote,createdMs:Date.now(),displayStatus:API.currentUser&&API.currentUser()&&!API.currentUser().isAnonymous?'Submission initiated; confirm with store':'Draft saved locally'});write('wholesale-quotes',reqs);var note=f.note;note.value=details;var hist=document.getElementById('am-ws-quote-history');if(hist)hist.innerHTML=renderQuoteHistory(reqs);if(!(API.currentUser&&API.currentUser()&&!API.currentUser().isAnonymous)){showToast('Quote draft saved in this browser. Sign in to send it to Online Shah Alami.');requestAccess('business');return;}if(window.PH&&PH.wsQuote)PH.wsQuote(e);else showToast('Quote saved locally. The store message workflow is unavailable.');}
  function renderQuoteHistory(reqs){if(!reqs.length)return '<div class="am-biz-empty">No quote drafts have been submitted from this browser yet.</div>';return '<div class="am-biz-table-wrap"><table class="am-biz-table"><thead><tr><th>Request</th><th>Quantity</th><th>City</th><th>Requested</th><th>Local status</th></tr></thead><tbody>'+reqs.slice().reverse().slice(0,10).map(function(x){return '<tr><td><b>'+esc(x.item||'Quote')+'</b><small>'+esc(x.company||'Business buyer')+'</small></td><td>'+esc(x.qty||'—')+'</td><td>'+esc(x.city||'—')+'</td><td>'+new Date(x.createdMs||Date.now()).toLocaleDateString()+'</td><td><span class="am-biz-tag">'+esc(x.displayStatus||'Request sent')+'</span></td></tr>';}).join('')+'</tbody></table><p class="am-biz-form-note">This history is a browser-side convenience record; check with Online Shah Alami for the authoritative quote status.</p></div>';}
  function saveCompany(e){e.preventDefault();var f=e.target,data={companyName:f.companyName.value.trim(),buyerType:f.buyerType.value,contactName:f.contactName.value.trim(),phone:f.phone.value.trim(),city:f.city.value.trim(),paymentPreference:f.paymentPreference.value,address:f.address.value.trim(),poPrefix:f.poPrefix.value.trim(),updatedMs:Date.now()};if(!data.companyName||!data.city){showToast('Add the business name and delivery city.');return;}write('company-profile',data);var node=document.getElementById('am-ws-company-result');if(node)node.textContent='Saved locally on this device. Connect a secure account backend to sync these details across devices.';var metric=document.querySelector('.am-biz-metric-grid .am-biz-metric:last-child b');if(metric)metric.textContent=data.companyName;showToast('Business profile saved on this device.');}
  function exportWholesale(){if(window.PH&&PH.wsExport)PH.wsExport();else{var rows=wsProducts().map(function(p){return [p.name||'',p.cat||'',API.minPrice(p),p.ws,p.wsMin||10].map(function(x){return '"'+String(x==null?'':x).replace(/"/g,'""')+'"';}).join(',');});var csv=['Product,Category,Retail price,Wholesale price,Minimum quantity'].concat(rows).join('\r\n');var blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='AnasMart_Wholesale_Prices.csv';a.click();URL.revokeObjectURL(url);}}
  function prefillTerms(term){var sel=document.querySelector('#am-w-quotes select[name="terms"]');if(sel){var found=[].slice.call(sel.options).filter(function(o){return o.text===term;})[0];if(found)sel.value=found.value;else sel.value=term;}scrollTo('am-w-quotes');}
  window.AMarketBusinessUI={scrollTo:scrollTo,requestAccess:requestAccess,openResellerAccount:openResellerAccount,openWholesaleAccount:openWholesaleAccount,openResellerProductEditor:openResellerProductEditor,resellerShare:resellerShare,resellerProfit:resellerProfit,filterReseller:filterReseller,saveCampaign:saveCampaign,campaignCopy:copyCampaignText,campaignWhatsApp:campaignWhatsApp,clearCampaigns:clearCampaigns,exportReseller:exportReseller,wholesaleAdd:wholesaleAdd,filterWholesale:filterWholesale,sortWholesale:sortWholesale,addSelectedWholesale:addSelectedWholesale,bulkPaste:bulkPaste,saveWholesaleList:saveWholesaleList,loadWholesaleList:loadWholesaleList,deleteWholesaleList:deleteWholesaleList,submitWholesaleQuote:submitWholesaleQuote,saveCompany:saveCompany,exportWholesale:exportWholesale,prefillTerms:prefillTerms,copyCampaignText:copyCampaignText};
  window.addEventListener('hashchange',function(){if(location.hash.indexOf('#/wholesale-center')===0)setTimeout(updateWholesaleSummary,120);});
  document.addEventListener('DOMContentLoaded',function(){if(location.hash.indexOf('#/wholesale-center')===0)setTimeout(updateWholesaleSummary,180);});
})();
