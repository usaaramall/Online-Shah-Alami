/* Online Shah Alami configuration. Fill in your NEW project's values before deployment. */
var CONFIG = {
  /* 1) FIREBASE: Firebase Console > Project settings > General > Your apps > Web app > SDK config */
  firebase: {
    apiKey: "YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_FIREBASE_APP_ID",
    measurementId: ""
  },
  /* 2) EMAILJS: emailjs.com > Account (Public Key), Email Services (Service ID), Email Templates (Template ID) */
  emailjs: {
    publicKey: "YOUR_EMAILJS_PUBLIC_KEY",
    serviceId: "YOUR_EMAILJS_SERVICE_ID",
    templateId: "YOUR_EMAILJS_TEMPLATE_ID",
    messageTemplateId: "",   /* optional: EmailJS template made from message-template.html (contact notices + replies). Leave "" to reuse the order template */
    replyTemplateId: ""      /* optional: same template ID as above is fine */
  },
  /* 3) ADMIN: only these emails can open the Admin Panel (create the account first from Login > Register) */
  adminEmails: ["YOUR_ADMIN_EMAIL@example.com"],
  /* 3b) CATEGORIES: add/remove freely. The emoji is shown when a product has no photo. */
  categories: ["Fashion","Electronics","Home & Kitchen","Beauty","Grocery","Toys","Sports","Accessories"],
  catEmoji: {"Fashion":"👕","Electronics":"🎧","Home & Kitchen":"🍳","Beauty":"🧴","Grocery":"🛒","Toys":"🧸","Sports":"⚽","Accessories":"👜","General":"🛍️"},
  /* 4) IMAGES: false = images are compressed and saved inside Firestore (100% free, no Storage needed).
        true  = images are saved in Firebase Storage (Storage now needs the Blaze plan in new projects). */
  useStorage: false,
  removeBgKey: "",   /* optional: remove.bg API key (AI background removal) */
  cloudinary: { cloud: "", preset: "" },   /* optional: free video upload (Cloudinary unsigned preset) */
  commissionPct: 10,   /* fallback reseller commission % */
  resellerDefaults: { commissionPct: 10, minProfit: 0, maxProfit: 100000, rules: "Use Copy link or Share to promote a live product. Add clear photos and accurate product details. Commission is payable after delivery." },
  /* SERVER ORDERS: false = orders are saved straight from the browser (works with no Cloud Function).
     true = orders go through the placeOrder Cloud Function, which re-checks prices, stock, delivery and discount on the server.
     Turn this on ONLY after you deploy functions (see the notes) and then lock the Firestore orders rule as described in firestore.rules. */
  serverOrders: false,
  /* 4b) REVIEWS: false = a customer can review a product once they have ordered it. true = only after the order is marked Delivered. */
  reviewNeedsDelivery: false,
  /* 5) SHOP DETAILS */
  deliveryFee: 0,
  codFee: 80,
  wholesale: { threshold: 50000, enabled: true, fee: 200, perKg: 100, cityRates: {} },
  /* AUTOMATIC DELIVERY: used until you save your own prices in Admin > Delivery. first kg = fee, each extra kg = perKg, freeAbove 0 = no free delivery */
  deliveryDefaults: { fee: 200, perKg: 100, freeAbove: 5000, auto: true },
  shop: {
    name: "Online Shah Alami",
    phone: "",
    whatsapp: "",
    email: "",
    accountName: "",
    bankName: "", bankNo: "",
    jazzcash: "",
    easypaisa: "",
    hours: "Open 24/7"
  },
  /* 6) POLICY VALUES (used inside the Policies page - change them to match your real service) */
  policy: {
    deliveryTime: "2 to 5 working days",
    returnWindow: "48 hours",
    refundTime: "3 to 5 working days",
    updated: "October 2026"
  }
};

var DEFAULTS = [
  {id:"d1",name:"Men's Cotton T-Shirt",desc:"Soft cotton t-shirt for everyday wear. Edit or delete this sample from Admin > Products.",badge:"Best Seller",cat:"Fashion",image:"",order:1,active:true,variants:[{size:"Small",price:1200},{size:"Medium",price:1200},{size:"Large",price:1300}]},
  {id:"d2",name:"Wireless Earbuds",desc:"Bluetooth earbuds with charging case. Sample product: edit it from Admin > Products.",badge:"New",cat:"Electronics",image:"",order:2,active:true,variants:[{size:"Standard",price:3999}]},
  {id:"d3",name:"Non-stick Fry Pan",desc:"Durable non-stick pan for daily cooking. Sample product: edit it from Admin > Products.",badge:"",cat:"Home & Kitchen",image:"",order:3,active:true,variants:[{size:"Standard",price:1799}]}
];

